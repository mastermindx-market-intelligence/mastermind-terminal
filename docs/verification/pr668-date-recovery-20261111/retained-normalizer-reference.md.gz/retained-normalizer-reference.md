## Packet A reference-repair return — tested contract patch, still unapplied

Packet `oa-prophet-ux-architecture-20260919-a`; parent #599 / `options-alpha-product-integration-20260917-sol-001`. Current Chairman continuation remains architecture/conformance work, not Packet C source custody. Protected procedure: `Mastermind@c49956d14878bd7b9c001258855e12d547596f13`, Skillpack 1.0.1/bootstrap 1.

This is a concrete reference repair of previously recorded R1–R3 and R5, not another report of the same unchanged defects. Target semantic head remains `d25e8ee1ea0b06878e479135678e926515e1ab6b`. No branch was changed. The patch is preserved below so recovery does not depend on the chat attachment. It is a candidate for the incumbent owner to adopt, not independent approval or a lifecycle/release command.

### Actual isolated results

- Original parser: 14/36 conformance cases; reference: **36/36**. The 22 original nonconformities are discriminated, with valid/null/stale/NO_ENTRY controls retained.
- Actual native Python reader + producer -> compiled reference normalizer: **328/328 admissions**, comprising **164 synthetic fixture sets x two producer variants**, not 328 independent market observations. The variants are unchanged #7399 and its paired provenance/source proposal. Seed 20260921; ordinary input bytes and all pre-existing producer payload fields remain unchanged.
- Provenance/clock/correction/omission/error checks: **23/23**. In particular, omitting optional summary provenance cannot disable checks on present row correction references.
- Strict standalone TypeScript compile passed; both source patches pass `git apply --check` on their exact source copies. No full React/Next typecheck, hosted integration, or browser result is claimed.

The parser validates published statistics; it does not grade prices or create a score. The arithmetic tolerance is half of the producer's four-decimal last unit plus binary-roundoff slack. It accepts either nearest value at an exact rounding tie and leaves Python's emitted statistic untouched; it is not bit-exact Python decimal emulation or a universal finite-magnitude proof.

The proposed provenance DTO is additive and requires incumbent contract adoption. Reconstruction uses the existing Python owner; no TypeScript prefix policy. Effective dates are not an invented original/before-after archive. Missing provenance remains unknown. Correction totals may include excluded rows, so visible refs give lower bounds, not a false equality.

### R4 interaction ruling: narrow the prior generic failure-retention suggestion

The existing helper collapses transport errors and access refusal to null. Therefore retain an admitted authorized `stale:true` snapshot with a conspicuous last-known label, and retain values while checking, but **withhold old private values on an unclassified null/invalid/throw**. Do not infer that a failed refresh was harmless. This supersedes the earlier unqualified retain-on-refresh-failure recommendation. A richer typed transient-error contract belongs to the existing cache/authorization owner.

Use existing `flowGetFresh`; manual Refresh can use existing `flowInvalidate` only when no component-local read is in flight. Client freshness does not remove server SWR: `stale:true` still needs visible treatment. Coalesce visible-only refresh/focus/visibility events; guard completion with mounted/generation refs; clear timers/listeners on unmount and handle Strict Mode replay. A proposed 30-second visible refresh is a UI read cadence, not a source heartbeat. No new store, bus, loader service or durable watcher.

The companion screen specification calls for response-state labels above statistics, native reconstruction/effective-correction labels, separate signal-date basis, and plan-clock elapsed rather than universal Held wording. It includes four authored Playwright cases (stale->fresh, 403/503 withhold-old-data, unsupported benchmark refusal), **NOT RUN**. Package dependency retrieval failed with registry DNS `EAI_AGAIN`; exact React/ReactDOM were not available in this sandbox. Hook/fetch test doubles are not React/browser evidence and are excluded from these acceptance totals.

### Patch identity / remaining owner action

`terminal-contract.patch` SHA-256: `adfe0d4e42409c73982f2d8ebe190f21655a6a1416c48824218a4836563b8ca7`. Original normalizer Git blob: `a55fb70bcf10082a903afadf05c9b267ae21f7c1`.

The report `prophet_perf_reference_repair/REPORT.md` SHA-256 is `28e7f8441a82c71b05073a9445ac4fc9ae278ff3304173ff0fe7aa644766763e`. The returned kit has original snapshots, proposal files, patches, runnable no-network tests, results and the unrun screen acceptance contract.

This consolidated patch **includes and replaces** the earlier one-predicate R1 proposal; do not stack both blindly. Incumbent Packet C should integrate the behaviors on this same PR, complete R4/R5 panel/copy rendering and real app verification, then return an immutable repaired head. Keep #7399 and #6872 producer/restart gates and #691's separate later Signals/BEST scope. This return creates no new source writer or release authority.

<details>
<summary>Unapplied exact-source Terminal reference patch</summary>

```diff
--- a/terminal/components/prophet/prophetPerfTypes.ts
+++ b/terminal/components/prophet/prophetPerfTypes.ts
@@ -11,7 +11,28 @@
 
 export type ProphetPerfOutcome = (typeof PROPHET_PERF_OUTCOMES)[number];
 
+export interface ProphetPerfProvenance {
+  origination_mode: string | null;
+  backfill_executed_at: string | null;
+  reconstructed: boolean;
+  formation_date: string | null;
+  signal_date_basis: "tier_event_date" | "tier_observation" | "legacy_formation_alias" | null;
+  observed_date: string | null;
+  confirmed_date: string | null;
+  price_basis_date: string | null;
+  recorded_at: string | null;
+  correction_ids: string[];
+}
+export interface ProphetPerfProvenanceCounts {
+  known_terminal_count: number;
+  unknown_terminal_count: number;
+  reconstructed_terminal_count: number;
+  known_raw_return_count: number;
+  reconstructed_raw_return_count: number;
+}
+
 export interface ProphetPerfPlan {
+  provenance: ProphetPerfProvenance | null;
   id: string;
   ticker: string;
   direction: "BULL" | "BEAR";
@@ -42,6 +63,7 @@
     freshness_unavailable_reason: string | null;
   };
   summary: {
+    provenance: ProphetPerfProvenanceCounts | null;
     terminal_plan_count: number;
     closed_plan_count: number;
     no_entry_count: number;
@@ -106,7 +128,7 @@
 }
 
 function count(value: unknown): number | null {
-  return Number.isInteger(value) && (value as number) >= 0 ? value as number : null;
+  return Number.isSafeInteger(value) && (value as number) >= 0 ? value as number : null;
 }
 
 function hasExplicitAvailability<T>(
@@ -118,10 +140,79 @@
     : unavailableReason === null;
 }
 
+
+/** Calendar validation only: no cross-family chronology or inferred dates. */
+function isCanonicalDate(value: string | null): boolean {
+  if (value === null) return true;
+  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
+  if (!match) return false;
+  const year = Number(match[1]), month = Number(match[2]), day = Number(match[3]);
+  if (year < 1 || month < 1 || month > 12) return false;
+  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
+  return day >= 1 && day <= [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
+}
+
+function stableSum(values: number[]): number {
+  let sum = 0, compensation = 0;
+  for (const value of values) {
+    const next = sum + value;
+    compensation += Math.abs(sum) >= Math.abs(value) ? (sum - next) + value : (value - next) + sum;
+    sum = next;
+  }
+  return sum + compensation;
+}
+
+/** Validation tolerance, NOT a replacement for the producer's published statistic.
+ * Four-decimal rounding: half a last-decimal unit plus binary-roundoff slack.
+ * Both nearest ties are accepted at the representational boundary; Python's
+ * source rounding is unchanged. Values returned to the UI remain the wire values.
+ */
+function agreesAtPublishedPrecision(actual: number, expected: number): boolean {
+  if (!Number.isFinite(expected)) return false;
+  return Math.abs(actual - expected) <= 0.00005 + 8 * Number.EPSILON * Math.max(1, Math.abs(expected))
+    && actual === Number(actual.toFixed(4));
+}
+
+
+function parseProvenance(value: unknown): ProphetPerfProvenance | null | undefined {
+  // Old transport omitted these facts: unknown, never "all records were live".
+  if (value === undefined || value === null) return null;
+  const p = record(value);
+  if (!p || typeof p.reconstructed !== "boolean") return undefined;
+  for (const field of ["formation_date", "observed_date", "confirmed_date", "price_basis_date", "recorded_at"]) {
+    const date = nullableString(p[field]);
+    if (date === undefined || !isCanonicalDate(date)) return undefined;
+  }
+  for (const field of ["origination_mode", "backfill_executed_at"]) {
+    const text = nullableString(p[field]);
+    if (text === undefined || (text !== null && (!text.trim() || text !== text.trim()))) return undefined;
+  }
+  if (p.reconstructed && p.origination_mode === null) return undefined;
+  const backfill = p.backfill_executed_at as string | null;
+  if (backfill !== null) {
+    const match = /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.exec(backfill);
+    if (!match || !isCanonicalDate(match[1]) || Number(match[2]) > 23 || Number(match[3]) > 59 ||
+        Number(match[4]) > 59 || !Number.isFinite(Date.parse(backfill))) return undefined;
+  }
+  if (p.signal_date_basis !== null && !["tier_event_date", "tier_observation", "legacy_formation_alias"].includes(p.signal_date_basis as string)) return undefined;
+  if (!Array.isArray(p.correction_ids) || p.correction_ids.some((id) => typeof id !== "string" || !id.trim() || id !== id.trim()) ||
+      new Set(p.correction_ids).size !== p.correction_ids.length) return undefined;
+  return {
+    origination_mode: p.origination_mode as string | null, backfill_executed_at: backfill,
+    reconstructed: p.reconstructed, formation_date: p.formation_date as string | null,
+    signal_date_basis: p.signal_date_basis as ProphetPerfProvenance["signal_date_basis"],
+    observed_date: p.observed_date as string | null, confirmed_date: p.confirmed_date as string | null,
+    price_basis_date: p.price_basis_date as string | null, recorded_at: p.recorded_at as string | null,
+    correction_ids: [...p.correction_ids] as string[],
+  };
+}
+
 function parsePlan(value: unknown): ProphetPerfPlan | null {
   const row = record(value);
   if (!row) return null;
 
+  const provenance = parseProvenance(row.provenance);
+  if (provenance === undefined) return null;
   const id = stringValue(row.id);
   const ticker = stringValue(row.ticker);
   const direction = row.direction;
@@ -152,6 +243,8 @@
     !asof
   ) return null;
 
+  if (![signalDate, entryDate, closeDate, asof].every(isCanonicalDate)) return null;
+
   if (
     !hasExplicitAvailability(signalDate, signalReason) ||
     !hasExplicitAvailability(entryDate, entryReason) ||
@@ -162,7 +255,6 @@
   if (
     outcome === "NO_ENTRY" &&
     (
-      entryDate !== null ||
       stockResult !== null ||
       optionResult !== null ||
       stockReason !== "no_entry_no_position" ||
@@ -171,6 +263,7 @@
   ) return null;
 
   return {
+    provenance,
     id,
     ticker,
     direction,
@@ -207,13 +300,15 @@
   const sourceLatestClose = nullableString(source.latest_close_date);
   const sourceFreshnessReason = nullableString(source.freshness_unavailable_reason);
   if (
-    !sourcePath ||
+    sourcePath !== "data/prophet/ledger.jsonl" ||
     source.schema !== "prophet.ledger/v1" ||
     source.projection !== "canonical_effective_ledger" ||
     sourceLatestAsof === undefined ||
     sourceLatestClose === undefined ||
     sourceFreshnessReason === undefined
   ) return null;
+
+  if (![sourceLatestAsof, sourceLatestClose].every(isCanonicalDate)) return null;
 
   const terminalCount = count(summary.terminal_plan_count);
   const closedCount = count(summary.closed_plan_count);
@@ -273,18 +368,8 @@
   const excessReturn = finiteNumber(benchmark.excess_return_pct);
   const benchmarkReason = nullableString(benchmark.unavailable_reason);
   if (benchmarkReturn === undefined || excessReturn === undefined || benchmarkReason === undefined) return null;
-  if (
-    (!benchmark.available && (
-      benchmarkReturn !== null ||
-      excessReturn !== null ||
-      !benchmarkReason
-    )) ||
-    (benchmark.available && (
-      benchmarkReturn === null ||
-      excessReturn === null ||
-      benchmarkReason !== null
-    ))
-  ) return null;
+  // This v1 has no accepted benchmark identity, population, ruler or authority.
+  if (benchmark.available !== false || benchmarkReturn !== null || excessReturn !== null || !benchmarkReason) return null;
 
   const canonicalRows = count(integrity.canonical_row_count);
   const effectiveRows = count(integrity.effective_row_count);
@@ -299,7 +384,9 @@
   if (
     canonicalRows < effectiveRows ||
     effectiveRows !== terminalCount ||
-    canonicalRows - effectiveRows !== quarantinedExcluded
+    canonicalRows - effectiveRows !== quarantinedExcluded ||
+    quarantinedExcluded > quarantinedIds || correctedRows > canonicalRows ||
+    correctionApps < correctedRows || (correctedRows === 0 && correctionApps !== 0)
   ) return null;
 
   const outcomeBasis = stringValue(semantics.outcome_count_basis);
@@ -335,6 +422,49 @@
         sourceFreshnessReason !== null
       )
   ) return null;
+
+  const actualOutcomes = Object.fromEntries(PROPHET_PERF_OUTCOMES.map((key) => [key, 0])) as Record<ProphetPerfOutcome, number>;
+  for (const plan of plans) actualOutcomes[plan.outcome] += 1;
+  if (PROPHET_PERF_OUTCOMES.some((key) => outcomeCounts[key] !== actualOutcomes[key])) return null;
+  const values = plans.filter((plan) => plan.outcome !== "NO_ENTRY" && plan.stock_result_pct !== null)
+    .map((plan) => plan.stock_result_pct as number).sort((a, b) => a - b);
+  if (values.length !== rawAvailable || rawPositive !== values.filter((v) => v > 0).length ||
+      rawNegative !== values.filter((v) => v < 0).length || rawZero !== values.filter((v) => v === 0).length) return null;
+  if (!values.length) {
+    if ([rawMean, rawMedian, rawMin, rawMax].some((value) => value !== null)) return null;
+  } else {
+    const mid = Math.floor(values.length / 2);
+    const median = values.length % 2 ? values[mid] : (values[mid - 1] + values[mid]) / 2;
+    if (rawMean === null || rawMedian === null || rawMin === null || rawMax === null ||
+        !agreesAtPublishedPrecision(rawMean, stableSum(values) / values.length) ||
+        !agreesAtPublishedPrecision(rawMedian, median) || !agreesAtPublishedPrecision(rawMin, values[0]) ||
+        !agreesAtPublishedPrecision(rawMax, values[values.length - 1])) return null;
+  }
+  const latest = (key: "asof" | "close_date"): string | null => plans.length
+    ? plans.reduce((max, plan) => plan[key] > max ? plan[key] : max, plans[0][key]) : null;
+  if (sourceLatestAsof !== latest("asof") || sourceLatestClose !== latest("close_date")) return null;
+
+  let provenanceCounts: ProphetPerfProvenanceCounts | null = null;
+  const known = plans.filter((plan) => plan.provenance !== null);
+  // Optional summary omission cannot disable checks on present per-row references.
+  // Aggregate correction counts also cover excluded rows, so compare lower bounds.
+  if (known.filter((plan) => plan.provenance!.correction_ids.length > 0).length > correctedRows ||
+      known.reduce((n, plan) => n + plan.provenance!.correction_ids.length, 0) > correctionApps) return null;
+  if (summary.provenance !== undefined && summary.provenance !== null) {
+    const wire = record(summary.provenance);
+    if (!wire) return null;
+    const reconstructed = known.filter((plan) => plan.provenance!.reconstructed);
+    const hasRaw = (plan: ProphetPerfPlan) => plan.outcome !== "NO_ENTRY" && plan.stock_result_pct !== null;
+    const counts: ProphetPerfProvenanceCounts = {
+      known_terminal_count: known.length, unknown_terminal_count: plans.length - known.length,
+      reconstructed_terminal_count: reconstructed.length, known_raw_return_count: known.filter(hasRaw).length,
+      reconstructed_raw_return_count: reconstructed.filter(hasRaw).length,
+    };
+    for (const key of Object.keys(counts) as (keyof ProphetPerfProvenanceCounts)[]) {
+      if (count(wire[key]) !== counts[key]) return null;
+    }
+    provenanceCounts = counts;
+  }
 
   return {
     schema: PROPHET_PERF_SCHEMA,
@@ -348,6 +478,7 @@
       freshness_unavailable_reason: sourceFreshnessReason,
     },
     summary: {
+      provenance: provenanceCounts,
       terminal_plan_count: terminalCount,
       closed_plan_count: closedCount,
       no_entry_count: noEntryCount,
```

</details>