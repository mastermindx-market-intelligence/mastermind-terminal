import { defineConfig } from "vitest/config";
import path from "path";

export default defineConfig({
  test: {
    // Fixture-only opt-in for the Investigation API admission gate
    // (lib/investigationApiAdmission.ts): the suites below drive the real route
    // handlers, which need the exact literal "open" to reach their existing
    // paths, and the closed-mode assertions stub the variable back over this
    // default. Production never receives this value — the unset default there
    // stays closed, and the gate module itself has no test bypass.
    env: {
      INVESTIGATION_API_ADMISSION: "open",
    },
    // Only include files using the vitest describe/it API.
    // The .mjs files in components/__tests__/ and tests/ use a custom console runner
    // and are not vitest suites — exclude them to avoid "no test suite found" failures.
    // .tsx is included alongside .ts for component tests that render JSX (each such file
    // opts into a DOM with a `// @vitest-environment jsdom` pragma — the suite default
    // stays plain Node, unchanged for every existing .ts test).
    include: [
      "lib/__tests__/**/*.test.ts",
      "lib/__tests__/**/*.test.tsx",
      // B-F08-6: section tests live next to the settings components they mount.
      "components/settings/__tests__/**/*.test.tsx",
      // IDR W1: Dislocations screen component tests (screen lane S2).
      "components/dislocations/__tests__/**/*.test.tsx",
    ],
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "."),
      // `server-only` ships a module that THROWS unless the bundler applies the `react-server`
      // export condition. That throw is exactly the protection we want from `next build`, but
      // vitest resolves plain Node conditions, so without this alias every suite that
      // transitively reaches lib/flowScore.ts (14 of them, via lib/flowSource.ts) would die on
      // import. Node IS a server, so satisfying the marker here is honest rather than a bypass —
      // and the build-time fence is untouched.
      "server-only": path.resolve(__dirname, "lib/__tests__/stubs/serverOnly.ts"),
    },
  },
});
