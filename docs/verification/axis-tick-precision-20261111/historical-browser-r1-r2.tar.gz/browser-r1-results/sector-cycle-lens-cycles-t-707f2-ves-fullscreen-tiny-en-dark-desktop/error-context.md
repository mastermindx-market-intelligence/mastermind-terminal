# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: sector-cycle-lens.spec.ts >> cycles tick precision survives fullscreen tiny en dark
- Location: e2e/sector-cycle-lens.spec.ts:110:9

# Error details

```
Error: SVG coordinates must follow the current measured content width

SVG coordinates must follow the current measured content width

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 1
Received:    1120

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]:
      - strong [ref=e4]: DEV harness · SectorCycleLens
      - generic [ref=e5]: Fixture data — not live evidence
      - generic [ref=e6]:
        - radio "EN" [checked] [ref=e7]
        - text: EN
      - generic [ref=e8]:
        - radio "ZH" [ref=e9]
        - text: ZH
      - generic [ref=e10]:
        - radio "Dark" [checked] [ref=e11]
        - text: Dark
      - generic [ref=e12]:
        - radio "Light" [ref=e13]
        - text: Light
      - generic [ref=e14]:
        - text: Axis fixture
        - combobox "Axis fixture" [ref=e15]:
          - option "Standard history"
          - option "Tiny values (0 to 0.01)" [selected]
          - option "Fractional ticks (-4 to 4)"
      - generic [ref=e16]:
        - radio "Generation current" [checked] [ref=e17]
        - text: Generation current
      - generic [ref=e18]:
        - radio "Generation replaced" [ref=e19]
        - text: Generation replaced
      - generic [ref=e20]:
        - radio "Heads today" [checked] [ref=e21]
        - text: Heads today
      - generic [ref=e22]:
        - radio "One head withdrawn" [ref=e23]
        - text: One head withdrawn
      - generic [ref=e24]:
        - radio "Heads absent" [ref=e25]
        - text: Heads absent
    - generic [ref=e26]:
      - generic [ref=e28]:
        - heading "Sector cycles" [level=2] [ref=e29]
        - paragraph [ref=e30]: Technology XLK · As of 2026-10-30 · Sector ETFs vs SPY · reconstructed price history
      - generic [ref=e31]:
        - complementary "Sectors by phase" [ref=e32]:
          - heading "Sectors by phase" [level=3] [ref=e33]
          - paragraph [ref=e34]: 5 of 5 measured · Sector ETFs vs SPY
          - tablist "Sectors by phase" [ref=e35]:
            - tab "Sector ETFs vs SPY" [selected] [ref=e36] [cursor=pointer]
            - tab "Thematic Baskets vs SPY" [ref=e37] [cursor=pointer]
          - generic [ref=e38]:
            - generic [ref=e39]: Filter series
            - searchbox "Filter series" [ref=e40]
          - generic [ref=e41]:
            - heading "Bottoming 1" [level=4] [ref=e42]:
              - text: Bottoming
              - generic [ref=e43]: "1"
            - button "Energy XLE" [ref=e44] [cursor=pointer]:
              - generic [ref=e45]: Energy
              - generic [ref=e46]: XLE
          - generic [ref=e47]:
            - heading "Prime entry 1" [level=4] [ref=e48]:
              - text: Prime entry
              - generic [ref=e49]: "1"
            - button "Financials XLF" [ref=e50] [cursor=pointer]:
              - generic [ref=e51]: Financials
              - generic [ref=e52]: XLF
          - generic [ref=e53]:
            - heading "Trending 1" [level=4] [ref=e54]:
              - text: Trending
              - generic [ref=e55]: "1"
            - button "Technology XLK" [pressed] [ref=e56] [cursor=pointer]:
              - generic [ref=e57]: Technology
              - generic [ref=e58]: XLK
          - generic [ref=e59]:
            - heading "Topping · late 1" [level=4] [ref=e60]:
              - text: Topping · late
              - generic [ref=e61]: "1"
            - button "Health Care XLV" [ref=e62] [cursor=pointer]:
              - generic [ref=e63]: Health Care
              - generic [ref=e64]: XLV
          - generic [ref=e65]:
            - heading "Rolling over 1" [level=4] [ref=e66]:
              - text: Rolling over
              - generic [ref=e67]: "1"
            - button "Cons Discretionary XLY" [ref=e68] [cursor=pointer]:
              - generic [ref=e69]: Cons Discretionary
              - generic [ref=e70]: XLY
          - group [ref=e71]:
            - generic "Method" [ref=e72] [cursor=pointer]
        - generic [ref=e73]:
          - generic [ref=e74]:
            - generic [ref=e75]:
              - heading "Technology XLK" [level=3] [ref=e76]
              - generic [ref=e77]:
                - generic [ref=e78]: "Cycle phase · ontology: Expansion"
                - generic [ref=e79]: Position · ontology 72
                - generic [ref=e80]:
                  - text: Price vs 200-session average
                  - generic [ref=e81]: Above
              - paragraph [ref=e82]: 0–100 scale. Not a probability.
            - button "Open sector dossier" [ref=e84] [cursor=pointer]
          - generic [ref=e85]:
            - heading "Clocks" [level=4] [ref=e86]
            - generic [ref=e87]:
              - generic [ref=e88]: phase clock
              - generic [ref=e89]: timing ladder
              - generic [ref=e90]: hazard clock
              - generic "Each disagreeing clock's own values are kept in the provenance drawer." [ref=e91]: rhythm clock ⚠
              - generic [ref=e92]: cycle read
            - paragraph [ref=e93]: Each disagreeing clock's own values are kept in the provenance drawer.
          - generic [ref=e94]:
            - heading "Strength vs SPY" [level=3] [ref=e96]
            - generic [ref=e97]:
              - button "Series (5)" [ref=e98] [cursor=pointer]: Series (5)＋
              - generic [ref=e99]:
                - text: Chart range
                - combobox "Chart range" [ref=e100]:
                  - option "21 sessions"
                  - option "63 sessions"
                  - option "252 sessions"
                  - option "All" [selected]
              - generic [ref=e101]:
                - text: Scale
                - combobox "Scale" [ref=e102]:
                  - option "Linear" [selected]
                  - option "Log" [disabled]
              - group "Strength vs SPY" [ref=e103]:
                - button "Chart" [pressed] [ref=e104] [cursor=pointer]
                - button "Data table" [ref=e105] [cursor=pointer]
              - button "Full screen" [ref=e106] [cursor=pointer]: Full screen⤢
            - generic [ref=e107]:
              - generic [ref=e108]:
                - text: XLK · 21 sessions
                - generic [ref=e110]: total return
              - generic [ref=e111]:
                - text: XLK · 63 sessions
                - generic [ref=e113]: total return
            - generic [ref=e114]:
              - generic [ref=e115]:
                - generic [ref=e116]:
                  - text: XLK · 21 sessions
                  - strong [ref=e117]: +0.0%
                - generic [ref=e118]:
                  - text: XLK · 63 sessions
                  - strong [ref=e119]: +0.0%
                - time [ref=e120]: 2026-05-02
              - img "Strength vs SPY" [ref=e122]:
                - generic [ref=e124]: "0.000"
                - generic [ref=e126]: "0.005"
                - generic [ref=e128]: "0.010"
                - generic "2025-09-13 · trough" [ref=e131]
                - generic "2025-11-12 · peak" [ref=e133]
                - generic "2026-01-21 · trough" [ref=e135]
                - generic "2026-03-12 · peak · Provisional" [ref=e137]
                - generic [ref=e139]: trough 2025-09-13
                - generic [ref=e140]: peak 2025-11-12
                - generic [ref=e141]: trough 2026-01-21
                - generic [ref=e142]: peak 2026-03-12
                - generic [ref=e145]: 2025-08-24
                - generic [ref=e146]: 2025-09-10
                - generic [ref=e147]: 2025-09-27
                - generic [ref=e148]: 2025-10-14
                - generic [ref=e149]: 2025-10-31
                - generic [ref=e150]: 2025-11-17
                - generic [ref=e151]: 2025-12-04
                - generic [ref=e152]: 2025-12-21
                - generic [ref=e153]: 2026-01-07
                - generic [ref=e154]: 2026-01-24
                - generic [ref=e155]: 2026-02-10
                - generic [ref=e156]: 2026-02-27
                - generic [ref=e157]: 2026-03-16
                - generic [ref=e158]: 2026-04-02
                - generic [ref=e159]: 2026-05-02
              - slider "Observation date" [ref=e160]: "251"
              - generic [ref=e161]:
                - generic [ref=e162]: 2025-08-24
                - generic [ref=e163]: 2026-05-02
            - generic [ref=e164]:
              - heading "Price turns" [level=4] [ref=e165]
              - paragraph [ref=e166]: Turn dates are pivot dates. A turn becomes known only at confirmation — the two dates are kept distinct.
              - generic [ref=e167]:
                - time [ref=e168]: 2026-03-12
                - generic [ref=e169]: Peak
                - emphasis [ref=e170]: Provisional
              - generic [ref=e171]:
                - time [ref=e172]: 2026-01-21
                - generic [ref=e173]: Trough
                - emphasis [ref=e174]: Confirmed
                - emphasis [ref=e175]: · first known 2026-01-24
              - generic [ref=e176]:
                - time [ref=e177]: 2025-11-12
                - generic [ref=e178]: Peak
                - emphasis [ref=e179]: Confirmed
                - emphasis [ref=e180]: · first known 2025-11-15
            - group [ref=e181]:
              - generic "Exact values" [ref=e182] [cursor=pointer]
            - group [ref=e183]:
              - generic "Method" [ref=e184]
          - generic [ref=e185]:
            - heading "Leg timeline" [level=3] [ref=e186]
            - list [ref=e188]:
              - listitem [ref=e189]:
                - button "2025-09-13 → 2025-11-12" [ref=e190] [cursor=pointer]:
                  - generic [ref=e191]: 2025-09-13 → 2025-11-12
                  - generic [ref=e192]: ▲
              - listitem [ref=e193]:
                - button "2025-11-12 → 2026-01-21" [ref=e194] [cursor=pointer]:
                  - generic [ref=e195]: 2025-11-12 → 2026-01-21
                  - generic [ref=e196]: ▼
              - listitem [ref=e197]:
                - button "2026-01-21 → 2026-03-12 · Provisional" [ref=e198] [cursor=pointer]:
                  - generic [ref=e199]: 2026-01-21 → 2026-03-12 · Provisional
                  - generic [ref=e200]: ▲
              - listitem [ref=e201]:
                - button "2026-03-12 · Open leg · Open · 51 sessions" [ref=e202] [cursor=pointer]:
                  - generic [ref=e203]: 2026-03-12 · Open leg · Open · 51 sessions
                  - generic [ref=e204]: ▼
          - generic [ref=e205]:
            - generic [ref=e206]:
              - heading "The read" [level=3] [ref=e207]
              - paragraph [ref=e208]: The production read names a different phase family than the phase clock; it is kept verbatim in the provenance drawer and is not drawn as the current read.
            - generic [ref=e209]:
              - heading "Rotation events" [level=3] [ref=e210]
              - paragraph [ref=e211]: No closed rotation episodes in this window
          - generic [ref=e212]:
            - generic [ref=e213]:
              - heading "Turn estimate & priors" [level=3] [ref=e214]
              - group "Turn hazard (historical qualification only)" [ref=e215]:
                - heading "Turn hazard (historical qualification only)" [level=4] [ref=e216]
                - generic [ref=e217]:
                  - generic [ref=e218]: P(turn ≤ 1m)
                  - generic [ref=e219]: ≤3m
                  - generic [ref=e220]: ≤6m
                  - generic [ref=e221]: an up leg · peak
                  - generic [ref=e222]:
                    - generic [ref=e223]: 18%
                    - generic [ref=e224]: MODEL
                  - generic [ref=e225]:
                    - generic [ref=e226]: 34%
                    - generic [ref=e227]: PRIOR
                  - generic [ref=e228]:
                    - generic [ref=e229]: 41%
                    - generic [ref=e230]: MODEL
                - paragraph [ref=e231]: "PRIOR: historical base rate, not a model"
            - generic [ref=e232]:
              - generic [ref=e233]:
                - heading "Methods and limits" [level=3] [ref=e234]
                - list [ref=e235]:
                  - listitem [ref=e236]: "Position sizing: none. The conviction multiplier is held at 1.0 and is not a size."
                  - listitem [ref=e237]: Own rhythm, descriptive. Not a model.
                  - listitem [ref=e238]: "Lead-lag: no claim. The lead-lag study stopped; nothing here orders sectors in time."
                  - listitem [ref=e239]: Source parity holds; model qualifications remain separate
                - group [ref=e240]:
                  - generic "Evidence details" [ref=e241] [cursor=pointer]
              - generic [ref=e242]:
                - paragraph [ref=e243]: Conviction-call grader
                - 'heading "Conviction-call grader: measured hit rate" [level=3] [ref=e244]'
                - paragraph [ref=e245]: Conviction-call hit rate over all resolved calls, Neutral included. Not a win rate.
                - paragraph [ref=e246]: Realized directional hit-rate, cross-sectional rank-IC and excess-vs-SPY of the conviction calls, by horizon. Sparse until it accrues; never fed back into the live score.
                - paragraph [ref=e247]: Grader unavailable in this generation
            - generic [ref=e248]:
              - heading "Timing & projection" [level=3] [ref=e249]
              - paragraph [ref=e250]: ◷18 sessions in this phase
              - paragraph [ref=e251]:
                - text: Price vs 200-session average Above
                - generic [ref=e252]: UPTREND
              - paragraph [ref=e253]: Time in phase is a measured historical fact — not remaining upside, and not a time limit.
              - generic [ref=e254]:
                - generic [ref=e255]:
                  - generic [ref=e256]: Descriptive rhythm
                  - generic [ref=e257]: Window has not opened
                - paragraph [ref=e258]: Next trough ≈ Feb ’27
                - generic [ref=e259]:
                  - generic [ref=e260]:
                    - term [ref=e261]: earliest
                    - definition [ref=e262]: Dec ’26
                  - generic [ref=e263]:
                    - term [ref=e264]: central
                    - definition [ref=e265]: Feb ’27
                  - generic [ref=e266]:
                    - term [ref=e267]: latest
                    - definition [ref=e268]: Apr ’27
                - paragraph [ref=e269]: "Projected next trough ≈ Feb ’27 (Dec ’26–Apr ’27), from this sector's own median half-cycle: a descriptive rhythm, not a model, and a timing window, not a guarantee."
          - generic [ref=e270]:
            - heading "Remaining-opportunity forecasts" [level=3] [ref=e271]
            - list [ref=e272]:
              - listitem [ref=e273]:
                - generic [ref=e274]: Remaining return
                - generic [ref=e275]: Withheld
                - generic [ref=e276]: "Withheld: the research test failed this forecast on current data"
                - generic [ref=e277]: "Horizon: 20 completed sessions"
                - group [ref=e278]:
                  - generic "Evidence" [ref=e279]
              - listitem [ref=e280]:
                - generic [ref=e281]: Adverse tail
                - generic [ref=e282]: Withheld
                - generic [ref=e283]: "Withheld: live cycle state does not match the research protocol's turn epoch"
                - generic [ref=e284]: "Horizon: 20 completed sessions"
                - group [ref=e285]:
                  - generic "Evidence" [ref=e286]
              - listitem [ref=e287]:
                - generic [ref=e288]: Target before invalidation
                - generic [ref=e289]: Withheld
                - generic [ref=e290]: "Withheld: live cycle state does not match the research protocol's turn epoch"
                - generic [ref=e291]: "Horizon: 20 completed sessions"
                - generic [ref=e292]: "Leg-direction fact: what the current up/down leg tends to reach, not a cycle-timing edge."
                - group [ref=e293]:
                  - generic "Evidence" [ref=e294]
              - listitem [ref=e295]:
                - generic [ref=e296]: Transition time
                - generic [ref=e297]: Withheld
                - generic [ref=e298]: "Withheld: live cycle state does not match the research protocol's turn epoch"
                - generic [ref=e299]: "Horizon: 20 completed sessions"
                - group [ref=e300]:
                  - generic "Evidence" [ref=e301]
            - paragraph [ref=e302]: No estimate is shown for a withheld forecast.
            - paragraph [ref=e303]: Each forecast is withheld on its own; the observed cycle facts above are unaffected.
          - paragraph [ref=e304]: Descriptive evidence. No stock recommendation, sizing or execution authority.
      - dialog "Cycles fullscreen" [active] [ref=e306]:
        - generic [ref=e307]:
          - paragraph [ref=e308]: Strength vs SPY
          - generic [ref=e309]:
            - group "Strength vs SPY" [ref=e310]:
              - button "Chart" [pressed] [ref=e311] [cursor=pointer]
              - button "Data table" [ref=e312] [cursor=pointer]
            - button "Close fullscreen" [ref=e313] [cursor=pointer]: ✕
        - img "Strength vs SPY" [ref=e314]:
          - generic [ref=e316]: "0.0000"
          - generic [ref=e318]: "0.0025"
          - generic [ref=e320]: "0.0050"
          - generic [ref=e322]: "0.0075"
          - generic [ref=e324]: "0.0100"
          - generic "2025-09-13 · trough · first known 2025-09-16" [ref=e327]
          - generic "2025-11-12 · peak · first known 2025-11-15" [ref=e328]
          - generic "2026-01-21 · trough · first known 2026-01-24" [ref=e329]
          - generic "2026-03-12 · peak · Provisional" [ref=e330]
          - generic [ref=e331]: trough 2025-09-13
          - generic [ref=e332]: peak 2026-03-12
        - generic [ref=e335]:
          - time [ref=e336]: 2026-05-02
          - generic [ref=e337]:
            - text: XLK · 21 sessions
            - strong [ref=e338]: +0.0%
          - generic [ref=e339]:
            - text: XLK · 63 sessions
            - strong [ref=e340]: +0.0%
  - alert [ref=e341]
```

# Test source

```ts
  1   | import { test, expect, type Locator } from "@playwright/test";
  2   | 
  3   | /* Cycles lane e2e — the /dev/sector-cycles harness (deterministic inline
  4   |  * fixtures, no network, clearly labelled as fixture data on the page itself).
  5   |  *
  6   |  * Charter gate 4: keyboard and touch through family/phase/range/scale/leg
  7   |  * selection, chart↔table equivalence, capture→navigate→apply return, at
  8   |  * 1440×900, 820×1180 and 390×844 (desktop/tablet/mobile), light+dark, EN+ZH.
  9   |  * The self-bound return router is exercised for real: leaving a subject
  10  |  * pushes its captured view onto the history entry being left; the browser
  11  |  * back button rebinds that subject (donor #10707 host contract) and the
  12  |  * two-phase codec restores the captured fields. */
  13  | 
  14  | const cases = [
  15  |   ["en", "dark"],
  16  |   ["zh", "light"],
  17  | ] as const;
  18  | 
  19  | const T = (lang: "en" | "zh") => ({
  20  |   chart: lang === "zh" ? "图表" : "Chart",
  21  |   table: lang === "zh" ? "数据表" : "Data table",
  22  |   range: lang === "zh" ? "图表范围" : "Chart range",
  23  |   log: lang === "zh" ? "对数" : "Log",
  24  |   series: lang === "zh" ? "序列" : "Series",
  25  |   obs: lang === "zh" ? "观测日期" : "Observation date",
  26  |   exact: lang === "zh" ? "精确数值" : "Exact values",
  27  |   baskets: lang === "zh" ? "主题组合对比 SPY" : "Thematic Baskets vs SPY",
  28  |   sectorsTab: lang === "zh" ? "板块 ETF 对比 SPY" : "Sector ETFs vs SPY",
  29  |   apply: lang === "zh" ? "应用" : "Apply",
  30  |   legDetails: lang === "zh" ? "周期段详情" : "Leg details",
  31  |   fullscreen: lang === "zh" ? "周期全屏" : "Cycles fullscreen",
  32  |   openFullscreen: lang === "zh" ? "打开全屏" : "Open fullscreen",
  33  |   fullscreenBtn: lang === "zh" ? "全屏" : "Full screen",
  34  |   changeSeries: lang === "zh" ? "更换序列" : "Change series",
  35  |   phaseAll: lang === "zh" ? "全部阶段" : "All phases",
  36  |   expansion: lang === "zh" ? "扩张" : "Expansion",
  37  |   selectedFoot: lang === "zh" ? "已选" : "Selected",
  38  |   troughWord: lang === "zh" ? "底部" : "trough",
  39  |   prov: lang === "zh" ? "暂定" : "Provisional",
  40  |   rs63: lang === "zh" ? "63个交易日" : "63 sessions",
  41  |   trough: lang === "zh" ? "底部" : "Trough",
  42  |   recovery: lang === "zh" ? "复苏" : "Recovery",
  43  |   energy: lang === "zh" ? "能源" : "Energy",
  44  |   financials: lang === "zh" ? "金融" : "Financials",
  45  |   aiInfra: lang === "zh" ? "AI 基础设施" : "AI Infrastructure",
  46  |   story: lang === "zh" ? "趋成熟" : "matured",
  47  |   mismatch: lang === "zh" ? "快照版本不一致" : "Snapshots do not match",
  48  |   /* v1.1 per-head forecast capabilities + SP11 dates + honest windows */
  49  |   range21: lang === "zh" ? "21个交易日" : "21 sessions",
  50  |   range252: lang === "zh" ? "252个交易日" : "252 sessions",
  51  |   range1mWord: lang === "zh" ? "1个月" : "1 month",
  52  |   durationWord: lang === "zh" ? "并非剩余上行空间" : "not remaining upside",
  53  |   firstKnown: lang === "zh" ? "最早可知" : "first known",
  54  |   pivotNote: lang === "zh" ? "转折日期为拐点日期" : "Turn dates are pivot dates",
  55  |   headWithheld: lang === "zh" ? "暂缓显示" : "Withheld",
  56  |   headWithdrawnWord: lang === "zh" ? "已撤回" : "Withdrawn",
  57  |   reasonUnknown: lang === "zh" ? "因未说明的原因暂缓显示" : "Withheld for an unstated reason",
  58  |   reasonFailed: lang === "zh" ? "研究检验未通过" : "research test failed",
  59  |   reasonEpoch: lang === "zh" ? "与研究协议的转折口径不一致" : "does not match the research protocol",
  60  |   horizon20: lang === "zh" ? "20 个已完结交易日" : "20 completed sessions",
  61  |   directional: lang === "zh" ? "周期段方向事实" : "Leg-direction fact",
  62  |   headsAbsent: lang === "zh" ? "未附带预测能力分块" : "No forecast capability block",
  63  | });
  64  | 
  65  | 
  66  | async function expectMeasuredPlot(svg: Locator) {
  67  |   await expect(svg).toBeVisible();
  68  |   const geometry = () => svg.evaluate((element) => {
  69  |     const chart = element as SVGSVGElement;
  70  |     return {
  71  |       container: chart.parentElement!.clientWidth,
  72  |       width: Number(chart.getAttribute("width")),
  73  |       viewBox: chart.viewBox.baseVal.width,
  74  |       rendered: chart.getBoundingClientRect().width,
  75  |     };
  76  |   });
  77  |   expect((await geometry()).container).toBeGreaterThanOrEqual(240);
  78  |   await expect.poll(async () => {
  79  |     const value = await geometry();
  80  |     return Math.max(
  81  |       Math.abs(value.width - value.container),
  82  |       Math.abs(value.viewBox - value.container),
  83  |       Math.abs(value.rendered - value.container),
  84  |     );
> 85  |   }, { message: "SVG coordinates must follow the current measured content width" }).toBeLessThanOrEqual(1);
      |                                                                                     ^ Error: SVG coordinates must follow the current measured content width
  86  |   return geometry();
  87  | }
  88  | 
  89  | async function expectAxisLabels(svg: Locator, expected: string[]) {
  90  |   await expectMeasuredPlot(svg);
  91  |   // Tick labels belong to grid groups; date/turn labels use other anchors.
  92  |   const ticks = svg.locator('g > text[text-anchor="end"]');
  93  |   await expect(ticks).toHaveText(expected);
  94  |   expect(new Set(await ticks.allTextContents()).size).toBe(expected.length);
  95  |   const bounds = await ticks.evaluateAll(elements => elements.map(element => {
  96  |     const label = element.getBoundingClientRect();
  97  |     const chart = (element as SVGElement).ownerSVGElement!.getBoundingClientRect();
  98  |     return { left: label.left - chart.left, right: chart.right - label.right };
  99  |   }));
  100 |   for (const bound of bounds) {
  101 |     expect(bound.left).toBeGreaterThanOrEqual(-1);
  102 |     expect(bound.right).toBeGreaterThanOrEqual(-1);
  103 |   }
  104 | }
  105 | 
  106 | for (const [lang, theme] of cases) {
  107 |   const L = T(lang);
  108 | 
  109 |   for (const axisFixture of ["tiny", "fractional"] as const) {
  110 |     test(`cycles tick precision survives fullscreen ${axisFixture} ${lang} ${theme}`, async ({ page }, info) => {
  111 |       await page.goto("/dev/sector-cycles");
  112 |       await page.getByRole("radio", { name: lang === "zh" ? "ZH" : "EN", exact: true }).check();
  113 |       await page.getByRole("radio", { name: theme === "light" ? "Light" : "Dark", exact: true }).check();
  114 |       await page.getByLabel("Axis fixture").selectOption(axisFixture);
  115 |       await expect(page.getByText("Fixture data — not live evidence")).toBeVisible();
  116 |       await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
  117 | 
  118 |       const panel = page.getByTestId("cycle-chart-panel");
  119 |       await panel.getByLabel(L.range).selectOption("0");
  120 |       const inlineLabels = axisFixture === "tiny"
  121 |         ? ["0.000", "0.005", "0.010"] : ["-2.5", "0.0", "2.5"];
  122 |       const fullscreenLabels = axisFixture === "tiny"
  123 |         ? ["0.0000", "0.0025", "0.0050", "0.0075", "0.0100"]
  124 |         : ["-4", "-2", "0", "2", "4"];
  125 |       await expectAxisLabels(panel.locator("svg"), inlineLabels);
  126 |       await panel.screenshot({
  127 |         path: info.outputPath(`cycles-precision-${axisFixture}-inline-${lang}-${info.project.name}.png`),
  128 |         animations: "disabled",
  129 |       });
  130 | 
  131 |       await panel.getByRole("button", { name: new RegExp(L.fullscreenBtn) }).click();
  132 |       const dialog = page.getByRole("dialog", { name: L.fullscreen });
  133 |       await expect(dialog).toBeVisible();
  134 |       await expectAxisLabels(dialog.locator("svg"), fullscreenLabels);
  135 |       await dialog.screenshot({
  136 |         path: info.outputPath(`cycles-precision-${axisFixture}-fullscreen-${lang}-${info.project.name}.png`),
  137 |         animations: "disabled",
  138 |       });
  139 |       await page.keyboard.press("Escape");
  140 |       await expect(dialog).toBeHidden();
  141 |       await expectAxisLabels(panel.locator("svg"), inlineLabels);
  142 |       expect(await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)).toBeLessThanOrEqual(1);
  143 |     });
  144 |   }
  145 | 
  146 |   for (const transition of ["table", "empty"] as const) {
  147 |     test(`cycles chart measurement survives ${transition} transitions ${lang} ${theme}`, async ({ page }, info) => {
  148 |       await page.goto("/dev/sector-cycles");
  149 |       await page.getByRole("radio", { name: lang === "zh" ? "ZH" : "EN", exact: true }).check();
  150 |       await page.getByRole("radio", { name: theme === "light" ? "Light" : "Dark", exact: true }).check();
  151 | 
  152 |       const initialViewport = page.viewportSize()!;
  153 |       // Remain in the same responsive band, so a remounted panel cannot hide
  154 |       // the lost observer. The final capture returns to the contract viewport.
  155 |       const widths = initialViewport.width >= 981 ? [1100, 1280]
  156 |         : initialViewport.width >= 641 ? [700, 900] : [510, 430];
  157 |       const panel = page.getByTestId("cycle-chart-panel");
  158 |       const svg = panel.locator("svg");
  159 |       const expectThemePaint = async (selected: "light" | "dark") => {
  160 |         await expect.poll(() => panel.evaluate(element => {
  161 |           const root = document.documentElement;
  162 |           const tokens = getComputedStyle(root);
  163 |           const paint = getComputedStyle(element);
  164 |           return {
  165 |             theme: root.dataset.theme,
  166 |             appearance: root.dataset.terminalAppearance,
  167 |             sharedShell: root.dataset.mmxSharedShell ?? null,
  168 |             backgroundToken: tokens.getPropertyValue("--bg").trim(),
  169 |             secondaryPanelToken: tokens.getPropertyValue("--panel-2").trim(),
  170 |             textToken: tokens.getPropertyValue("--text").trim(),
  171 |             background: paint.backgroundColor,
  172 |             foreground: paint.color,
  173 |           };
  174 |         })).toEqual({
  175 |           theme: selected, appearance: "1", sharedShell: null,
  176 |           backgroundToken: selected === "light" ? "#f7f8fa" : "#0a0b0e",
  177 |           secondaryPanelToken: selected === "light" ? "#eef1f6" : "#15171d",
  178 |           textToken: selected === "light" ? "#202632" : "#d6dae3",
  179 |           background: selected === "light" ? "rgb(255, 255, 255)" : "rgb(13, 15, 19)",
  180 |           foreground: selected === "light" ? "rgb(32, 38, 50)" : "rgb(214, 218, 227)",
  181 |         });
  182 |       };
  183 |       await expectThemePaint(theme);
  184 |       const otherTheme = theme === "light" ? "dark" : "light";
  185 |       await page.getByRole("radio", { name: otherTheme === "light" ? "Light" : "Dark", exact: true }).check();
```