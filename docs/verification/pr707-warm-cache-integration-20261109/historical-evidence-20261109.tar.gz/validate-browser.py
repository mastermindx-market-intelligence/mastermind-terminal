from pathlib import Path
import subprocess,json,hashlib,os,time,datetime,shutil,stat
repo=Path(__file__).resolve().parents[3];t=repo/'terminal';proof=Path(__file__).resolve().parent;out=proof;port=3908
head='0b48ac7f699b99fce10fd76d64d7c278cd23e9d2';base='156c4b3ecfa27b9137c64068b3ed969e07efbe49';dependency='0fd27ff1dfb7e031457a4ffe4c05458587c4eb81'
def git(*a):return subprocess.run(['git','-C',str(repo),*a],capture_output=True,text=True,check=True).stdout.strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def inspect(args):
 r=subprocess.run(args,capture_output=True,text=True);return {'command':args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'observedAt':now()}
def port_closed(port):
 r=inspect(['lsof','-nP','-iTCP:'+str(port),'-sTCP:LISTEN']);assert r['exit'] in [0,1] and not r['stderr'].strip();return r['exit']==1
def reconcile_lock(port,label,extraPids=[]):
 lock=t/'.next/dev/lock'
 for _ in range(40):
  if port_closed(port):break
  time.sleep(.25)
 assert port_closed(port),'Owned listener remains live'
 if not lock.exists():return {'initialLockPresent':False,'serverAbsenceVerifiedAt':now()}
 def identity():
  st=lock.lstat();assert stat.S_ISREG(st.st_mode) and st.st_uid==501
  return {'dev':st.st_dev,'ino':st.st_ino,'size':st.st_size,'mtimeNs':st.st_mtime_ns,'sha256':sha(lock),'content':json.loads(lock.read_text())}
 initial=identity();assert initial['content']['port']==port
 pids=[initial['content']['pid'],*extraPids]
 def observations(withFd):
  checks={}
  for name,args in [('listener',['lsof','-nP','-iTCP:'+str(port),'-sTCP:LISTEN']),('recordedProcesses',['ps','-p',','.join(str(x) for x in pids),'-o','pid=,ppid=,comm='])]:
   r=inspect(args);checks[name]=r;assert r['exit']==1 and not r['stdout'].strip() and not r['stderr'].strip(),checks
  if withFd:
   r=inspect(['lsof',str(lock)]);checks['lockDescriptors']=r;assert r['exit']==1 and not r['stdout'].strip() and not r['stderr'].strip()
  else:assert not lock.exists();checks['lockDescriptors']={'state':'fileAbsent','observedAt':now()}
  r=inspect(['lsof','-a','-u','chriswong','-d','cwd','-F','pcn']);cur=[];records=[]
  for line in r['stdout'].splitlines():
   if line.startswith('p'):
    if any(x.startswith('n'+str(repo)) for x in cur):records.append(cur)
    cur=[line]
   else:cur.append(line)
  if any(x.startswith('n'+str(repo)) for x in cur):records.append(cur)
  checks['ownedWorkspaceCwds']={k:v for k,v in r.items() if k!='stdout'};checks['ownedWorkspaceCwds']['records']=records
  assert r['exit']==0 and not r['stderr'].strip() and not records
  return checks
 receipt={'schema':'terminal_pr707_browser_lifecycle_reconciliation.v1','label':label,'startedAt':now(),'initialLockPresent':True,'initialLock':initial,'before':observations(True),'state':'ABSENCE_VERIFIED_PENDING_UNLINK'}
 file=out/(label+'-lifecycle.json');assert not file.exists();put(file,receipt)
 assert identity()==initial;receipt['immediatelyBeforeUnlink']=observations(True);assert identity()==initial;put(file,receipt)
 lock.unlink();assert not lock.exists();receipt['after']=observations(False);receipt['state']='STALE_OWNED_LOCK_REMOVED_SERVER_ABSENCE_VERIFIED';receipt['completedAt']=now();put(file,receipt)
 return {'initialLockPresent':True,'reconciliation':str(file.relative_to(repo)),'sha256':sha(file),'serverAbsenceVerifiedAt':receipt['completedAt']}


assert git('rev-parse','HEAD')==head and git('rev-parse','MERGE_HEAD')==dependency and not git('diff','--name-only','--diff-filter=U')
assert all(json.loads((proof/p/'execution.json').read_text())['state']=='QUALIFIED' for p in ['screener-ordering-r6','heatmap-ordering-r7','watchlist-observer-r8','generation-fence-r9'])
deps=json.loads((proof/'dependencies.json').read_text());assert deps['state']=='EXACT_DEPENDENCIES_READY'
assert port_closed(port) and not(t/'.next/dev/lock').exists()
run=proof/'current-browser-r1';assert not run.exists();run.mkdir()
packet=t/'docs/pr-crops/warm-symbol-picker-20260921';prior=proof/'prior-warm-picker-packet';assert not prior.exists();shutil.copytree(packet,prior)
priorFiles={str(p.relative_to(packet)):sha(p) for p in packet.rglob('*') if p.is_file()};assert priorFiles=={str(p.relative_to(prior)):sha(p) for p in prior.rglob('*') if p.is_file()}
put(run/'prior-warm-picker-packet.json',priorFiles)
env=os.environ.copy()
for k in ['TERMINAL_EVIDENCE_MODE','TERMINAL_EVIDENCE_COMPOSITION','TERMINAL_CROPS','TERMINAL_VISUAL_EVIDENCE_OPERATION','TERMINAL_EVIDENCE_UPDATE','PLAYWRIGHT_JSON_OUTPUT_FILE']:env.pop(k,None)
env.update({'CI':'1','TERMINAL_E2E_PORT':str(port),'PLAYWRIGHT_BROWSERS_PATH':deps['browserCache'],'MMX_SHARED_SHELL':'0','MMX_INVESTOR_SHELL_PREVIEW':'0'})
def cases(data):
 values=[]
 def walk(s):
  for spec in s.get('specs',[]):
   for v in spec.get('tests',[]):values.append({'key':v['projectName']+'|'+spec['file']+'|'+spec['title'],'file':spec['file'],'line':spec.get('line'),'project':v['projectName'],'title':spec['title'],'expectedStatus':v.get('expectedStatus'),'results':[{'status':a.get('status'),'retry':a.get('retry'),'error':a.get('error')} for a in v.get('results',[])]})
  for child in s.get('suites',[]):walk(child)
 walk(data);return values
touch=subprocess.run(['node','node_modules/@playwright/test/cli.js','test','e2e/marker-tooltip.spec.ts','--project=desktop','--project=tablet','--project=mobile','--grep','^(?:tapping a marker opens|a pane relayout|a tap still opens|a touch press that travels)','--list','--reporter=json'],cwd=t,env=env,capture_output=True,text=True,check=True)
touchListing=json.loads(touch.stdout);put(run/'touch-selection.json',touchListing);touchCases=cases(touchListing);assert len(touchCases)==15
lines=sorted(set(c['line'] for c in touchCases));assert len(lines)==5
specs=['e2e/warm-symbol-picker.spec.ts','e2e/chart-settings-ux.spec.ts','e2e/chart-view-reset.spec.ts','e2e/cache-invalidation-epoch.spec.ts']+['e2e/marker-tooltip.spec.ts:'+str(line) for line in lines]
listed=subprocess.run(['node','node_modules/@playwright/test/cli.js','test',*specs,'--project=desktop','--project=tablet','--project=mobile','--list','--reporter=json'],cwd=t,env=env,capture_output=True,text=True,check=True)
listing=json.loads(listed.stdout);put(run/'listed-cases.json',listing);expected=sorted(c['key'] for c in cases(listing));assert 39<len(expected)<200 and len(expected)==len(set(expected))
paths=set(json.loads(subprocess.run(['node','-e',"console.log(JSON.stringify(require('./terminal/e2e/tools/visualEvidence.cjs').sourceSnapshot(process.cwd())))"],cwd=repo,capture_output=True,text=True,check=True).stdout))
def snapshot():return {p:sha(repo/p) for p in sorted(paths)}
before=snapshot();put(run/'source-before.json',before)
report=run/'browser-report.json';env['PLAYWRIGHT_JSON_OUTPUT_FILE']=str(report)
output=t/'test-results/pr707-current-browser-r1';assert not output.exists()
command=['node','node_modules/@playwright/test/cli.js','test',*specs,'--project=desktop','--project=tablet','--project=mobile','--workers=1','--retries=0','--max-failures=1','--reporter=list,json','--output='+str(output)]
record={'schema':'terminal_pr707_current_warm_cache_browser.v1','state':'RUNNING','head':head,'protectedMaster':base,'integratedDependency':dependency,'startedAt':now(),'command':command,'port':port,'sourceEntries':len(before),'selectedCaseCount':len(expected),'retainedOriginalSuites':['warm-symbol-picker','chart-settings-ux','chart-view-reset'],'currentCompatibility':['cache-invalidation-epoch','five marker touch cases'],'fixture':True,'productionProof':False}
def save():put(run/'execution.json',record)
save();print(json.dumps({'starting':'original warm-picker/chart acceptance plus current invalidation and touch compatibility','selectedCases':len(expected),'port':port,'sourceEntries':len(before)}),flush=True)
start=time.monotonic();startNs=time.time_ns();log=run/'browser.log'
with log.open('x') as h:r=subprocess.run(command,cwd=t,env=env,stdout=h,stderr=subprocess.STDOUT)
after=snapshot();put(run/'source-after.json',after);result=json.loads(report.read_text()) if report.exists() else {'errors':['missing report'],'stats':{}};stats=result.get('stats',{});actual=cases(result)
record.update({'exit':r.returncode,'seconds':round(time.monotonic()-start,2),'sourceStable':before==after,'stats':stats,'cases':actual,'reportErrors':result.get('errors',[]),'logSha256':sha(log)})
if output.exists():
 shutil.copytree(output,run/'artifacts');record['artifacts']={str(p.relative_to(run/'artifacts')):sha(p) for p in (run/'artifacts').rglob('*') if p.is_file()}
fresh=run/'current-warm-images';fresh.mkdir();images={}
for name in ['cached-while-refreshing.png','corrected-after-refresh.png']:
 p=packet/name
 if p.exists() and p.stat().st_mtime_ns>=startNs:
  shutil.copy2(p,fresh/name);images[name]={'sha256':sha(p),'bytes':p.stat().st_size}
record['freshWarmImages']=images
for rel,h in priorFiles.items():
 p=packet/rel
 if not p.exists() or sha(p)!=h:
  p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(prior/rel,p)
assert {str(p.relative_to(packet)):sha(p) for p in packet.rglob('*') if p.is_file()}==priorFiles
record['historicalWarmPacketRestoredPendingQualification']=True
record['lifecycle']=reconcile_lock(port,'warm-current-r1');record['ownedPortClosed']=port_closed(port);record['nextLockAbsent']=not(t/'.next/dev/lock').exists()
warm=[c for c in actual if c['file'].endswith('warm-symbol-picker.spec.ts')];cache=[c for c in actual if c['file'].endswith('cache-invalidation-epoch.spec.ts')];touch=[c for c in actual if c['file'].endswith('marker-tooltip.spec.ts')]
good=r.returncode==0 and before==after and not result.get('errors') and stats.get('unexpected')==0 and stats.get('flaky')==0 and sorted(c['key'] for c in actual)==expected and all(len(c['results'])==1 and c['results'][0]['retry']==0 and c['results'][0]['status'] in ['passed','skipped'] and (c['results'][0]['status']!='skipped' or c['expectedStatus']=='skipped') for c in actual) and len(images)==2 and record['ownedPortClosed'] and record['nextLockAbsent'] and len(warm)==3 and sum(c['results'][0]['status']=='passed' for c in warm)==1 and len(cache)==21 and all(c['results'][0]['status']=='passed' for c in cache) and len(touch)==15 and sum(c['results'][0]['status']=='passed' for c in touch)==10
record.update({'state':'QUALIFIED' if good else 'FAILED','completedAt':now()});save();print(json.dumps({'state':record['state'],'seconds':record['seconds'],'stats':stats,'sourceStable':before==after,'freshWarmImages':len(images),'portsClosed':record['ownedPortClosed']}),flush=True)
if not good:print(log.read_text()[-12000:],flush=True)
raise SystemExit(0 if good else 1)
