#!/usr/bin/env python3
"""Merge explicitly armed pull requests only after the current head is truly green.

Terminal protects master with the same three required checks and supports native
auto-merge as the fastest server-side path. This controller is the fallback for a
ready pull request that was labelled but never natively armed. It only considers
same-repository, non-draft pull requests carrying the
``merge-on-green`` label; requires the latest trusted instance of all three CI jobs
to have completed successfully; and pins every state-changing action to the head SHA
it evaluated. When GitHub's native merge queue is enabled for master, the controller
verifies every eligible green head (including a head that is merely behind master)
against the queue and reports it ready, but never enqueues: this workflow holds
the repository GITHUB_TOKEN, whose enqueue return cannot establish downstream
merge-group event delivery. Admission is left to the already-supported native-user
route, with an expected-head pin. Without
a merge queue it retains the historical refresh-then-SHA-pinned-squash fallback.

The controller is deliberately label-gated. ``hold`` and ``do-not-merge`` are hard
vetoes. A genuine trusted red or conflict is labelled ``merge-blocked`` with one
comment; pending, missing, or wrong-App evidence simply waits. One sweep may merge
a green pull request and then update the next stale one, but it never merges two
pull requests against the same base snapshot.

An explicitly dispatched run may carry a ``target_pr`` pull request number. It is
validated before any API client is built, and it only ever narrows the candidate
list to that one pull request -- every guard below still applies to it, and no
other pull request is considered, merged or refreshed as a fallback.

A branch update written with GITHUB_TOKEN makes GitHub create the head's
``pull_request`` CI run already completed as ``action_required``: held, with no
jobs. That held suite is the one the pull request's required-check rollup reads, so
green checks from any other run on the same commit leave the pull request BLOCKED
(#874, 2026-10-13). The controller therefore re-runs that exact held run. Measured
on 2026-10-13 (throwaway probe PR #988): a GITHUB_TOKEN ``POST /actions/runs/{id}/rerun``
answers 201 and attempt 2 executes every job (runs 38378802229 and 38379271205), and
its checks appear in the pull request's rollup as required contexts. Every held run
seen (those two and #874's 38370600573) has ``actor.login == github-actions[bot]``.
"""
from __future__ import annotations

import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Iterable, Protocol


ARM_LABEL = "merge-on-green"
BLOCK_LABEL = "merge-blocked"
HOLD_LABELS = frozenset({"hold", "do-not-merge"})
REQUIRED_CHECKS = (
    "Quote Hub tests",
    "Terminal typecheck + tests",
    "Ingest + signal-layer tests",
)
# Native master protection binds every required context to the GitHub Actions App.
# The fallback must mirror that authority rather than accepting same-named checks
# from another App.
REQUIRED_CHECK_APP_ID = 15368
BLOCK_MARKER = "<!-- mastermind-terminal-merge-sweeper -->"
# The only actor whose held pull_request run the controller releases: the
# repository's own workflow token. A run held for anyone else is a human decision.
HELD_RUN_ACTOR = "github-actions[bot]"
# After update-branch answers 202 the new head and its pull_request run appear a few
# seconds later. Look for that run this many times, this far apart, before falling
# back to an explicit dispatch.
REFRESH_RUN_POLLS = 12
REFRESH_RUN_POLL_SECONDS = 5
# Bound the accepted controller input to a positive 32-bit integer. Wider,
# signed or otherwise malformed values are configuration errors, refused before
# any API client exists.
MAX_PULL_REQUEST_NUMBER = 2**31 - 1


class ApiError(RuntimeError):
    def __init__(self, status: int, message: str):
        super().__init__(f"GitHub API {status}: {message}")
        self.status = status


class GitHubApi:
    def __init__(self, repo: str, token: str):
        self.repo = repo
        self.base = f"https://api.github.com/repos/{repo}"
        self.token = token

    def request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> Any:
        body = json.dumps(payload).encode() if payload is not None else None
        req = urllib.request.Request(
            f"{self.base}{path}",
            data=body,
            method=method,
            headers={
                "Accept": "application/vnd.github+json",
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "X-GitHub-Api-Version": "2022-11-28",
                "User-Agent": "mastermind-terminal-merge-sweeper",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                raw = response.read()
                return json.loads(raw) if raw else None
        except urllib.error.HTTPError as error:
            raw = error.read().decode(errors="replace")
            try:
                message = json.loads(raw).get("message", raw)
            except json.JSONDecodeError:
                message = raw
            raise ApiError(error.code, str(message)) from error

    def graphql_request(self, query: str, variables: dict[str, Any]) -> dict[str, Any]:
        body = json.dumps({"query": query, "variables": variables}).encode()
        req = urllib.request.Request(
            "https://api.github.com/graphql",
            data=body,
            method="POST",
            headers={
                "Accept": "application/vnd.github+json",
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "User-Agent": "mastermind-terminal-merge-sweeper",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                raw = response.read()
        except urllib.error.HTTPError as error:
            raw = error.read().decode(errors="replace")
            try:
                message = json.loads(raw).get("message", raw)
            except json.JSONDecodeError:
                message = raw
            raise ApiError(error.code, str(message)) from error

        try:
            payload = json.loads(raw) if raw else {}
        except json.JSONDecodeError as error:
            raise ApiError(502, "GraphQL response was not valid JSON") from error
        if not isinstance(payload, dict):
            raise ApiError(502, "GraphQL response was not an object")
        errors = payload.get("errors")
        if errors:
            messages = []
            for item in errors if isinstance(errors, list) else [errors]:
                if isinstance(item, dict):
                    messages.append(str(item.get("message") or "unknown GraphQL error"))
                else:
                    messages.append(str(item))
            raise ApiError(422, "GraphQL: " + "; ".join(messages))
        data = payload.get("data")
        if not isinstance(data, dict):
            raise ApiError(502, "GraphQL response did not contain a data object")
        return data

    def merge_queue_enabled(self, base_ref: str) -> bool:
        owner, name = self.repo.split("/", 1)
        data = self.graphql_request(
            """
            query($owner: String!, $name: String!, $branch: String!) {
              repository(owner: $owner, name: $name) {
                mergeQueue(branch: $branch) { id }
              }
            }
            """,
            {"owner": owner, "name": name, "branch": base_ref},
        )
        repository = data.get("repository")
        return isinstance(repository, dict) and isinstance(repository.get("mergeQueue"), dict)

    def queue_entry(self, pull_request_id: str) -> str | None:
        data = self.graphql_request(
            """
            query($id: ID!) {
              node(id: $id) {
                ... on PullRequest {
                  mergeQueueEntry { id }
                }
              }
            }
            """,
            {"id": pull_request_id},
        )
        node = data.get("node")
        entry = node.get("mergeQueueEntry") if isinstance(node, dict) else None
        if not isinstance(entry, dict):
            return None
        entry_id = entry.get("id")
        return str(entry_id) if entry_id else None

    def native_enqueue_api(self) -> GitHubApi:
        """Qualify the distinct user credential at the native mutation boundary.

        The repository job token remains the incumbent read/legacy credential.
        It cannot be a fallback here: its enqueue event need not start group CI.
        Configuration is a prospective enrollment, never proof of the identity.
        """
        token = os.environ.get("NATIVE_ENQUEUE_TOKEN", "").strip()
        login = os.environ.get("NATIVE_ENQUEUE_ISSUER_LOGIN", "").strip()
        issuer_id = os.environ.get("NATIVE_ENQUEUE_ISSUER_ID", "").strip()
        repository_id = os.environ.get("GITHUB_REPOSITORY_ID", "").strip()
        if (
            self.repo != "mastermindx-market-intelligence/mastermind-terminal"
            or not token
            or token in {self.token, os.environ.get("GITHUB_TOKEN", "").strip()}
            or not login
            or login.casefold() == "github-actions[bot]"
            or not issuer_id.isascii() or not issuer_id.isdecimal() or int(issuer_id) <= 0
            or not repository_id.isascii() or not repository_id.isdecimal() or int(repository_id) <= 0
        ):
            raise ApiError(412, "native enqueue issuer enrollment unavailable")
        client = GitHubApi(self.repo, token)
        identity = client.graphql_request(
            """
            query($owner: String!, $name: String!) {
              viewer { __typename login databaseId }
              repository(owner: $owner, name: $name) {
                nameWithOwner databaseId viewerPermission
              }
            }
            """,
            {"owner": "mastermindx-market-intelligence", "name": "mastermind-terminal"},
        )
        viewer = identity.get("viewer") if isinstance(identity, dict) else None
        repository = identity.get("repository") if isinstance(identity, dict) else None
        if (
            not isinstance(viewer, dict) or not isinstance(repository, dict)
            or viewer.get("__typename") != "User"
            or viewer.get("login") != login
            or type(viewer.get("databaseId")) is not int
            or viewer["databaseId"] != int(issuer_id)
            or repository.get("nameWithOwner") != self.repo
            or type(repository.get("databaseId")) is not int
            or repository["databaseId"] != int(repository_id)
            or repository.get("viewerPermission") not in {"WRITE", "MAINTAIN", "ADMIN"}
        ):
            raise ApiError(412, "native enqueue issuer identity or repository grant unqualified")
        return client

    def enqueue(self, pull_request_id: str, head_sha: str) -> str:
        # Explicit caller primitive only: the reporting sweep never calls this.
        # Fresh user qualification precedes its single expected-head mutation;
        # never cache identity or retry an ambiguous response here.
        client = self.native_enqueue_api()
        data = client.graphql_request(
            """
            mutation($pullRequestId: ID!, $expectedHeadOid: GitObjectID!) {
              enqueuePullRequest(
                input: {
                  pullRequestId: $pullRequestId
                  expectedHeadOid: $expectedHeadOid
                }
              ) {
                mergeQueueEntry { id }
              }
            }
            """,
            {"pullRequestId": pull_request_id, "expectedHeadOid": head_sha},
        )
        payload = data.get("enqueuePullRequest")
        entry = payload.get("mergeQueueEntry") if isinstance(payload, dict) else None
        if not isinstance(entry, dict) or not entry.get("id"):
            raise ApiError(422, "enqueuePullRequest returned no merge queue entry")
        return str(entry["id"])

    def list_pulls(self) -> list[dict[str, Any]]:
        pulls: list[dict[str, Any]] = []
        page = 1
        while True:
            batch = self.request("GET", f"/pulls?state=open&per_page=100&sort=created&direction=asc&page={page}")
            pulls.extend(batch)
            if len(batch) < 100:
                return pulls
            page += 1

    def pull(self, number: int) -> dict[str, Any]:
        return self.request("GET", f"/pulls/{number}")

    def check_runs(self, sha: str) -> list[dict[str, Any]]:
        quoted = urllib.parse.quote(sha, safe="")
        data = self.request("GET", f"/commits/{quoted}/check-runs?per_page=100")
        return data.get("check_runs", [])

    def pull_request_ci_runs(self, sha: str) -> list[dict[str, Any]]:
        quoted = urllib.parse.quote(sha, safe="")
        data = self.request(
            "GET",
            f"/actions/workflows/ci.yml/runs?event=pull_request&head_sha={quoted}&per_page=20",
        )
        return data.get("workflow_runs", [])

    def rerun_workflow_run(self, run_id: int) -> None:
        self.request("POST", f"/actions/runs/{int(run_id)}/rerun")

    def update_branch(self, number: int, head_sha: str) -> None:
        self.request("PUT", f"/pulls/{number}/update-branch", {"expected_head_sha": head_sha})

    def dispatch_ci(self, branch: str, pr_number: int | None = None) -> None:
        # Fallback only. The refresh path first re-runs the held pull_request run,
        # which is the run the pull request's rollup reads. A dispatched run's
        # checks land on the same commit but do NOT satisfy that rollup (#874), so
        # this is ordered only when no pull_request run appeared for the new head.
        #
        # On that path the dispatched run may be the only CI run that has executed
        # for the sha, and on a workflow_dispatch `github.event.pull_request.number`
        # is empty -- so the migration-namespace guard fell to its LENIENT rule set
        # in it (round 4, MAJOR 2). ci.yml now takes a `pr_number` input and the
        # number is passed here. The merge itself still waits for the pull_request
        # run's required checks.
        payload: dict[str, Any] = {"ref": branch}
        if pr_number is not None:
            payload["inputs"] = {"pr_number": str(pr_number)}
        try:
            self.request("POST", "/actions/workflows/ci.yml/dispatches", payload)
            return
        except ApiError as error:
            # A branch whose ci.yml predates the input answers 422 ("Unexpected
            # inputs provided"). Ordering the proof matters more than proving it
            # in the stricter mode, so retry once without inputs -- and say out
            # loud that the run will be LENIENT rather than let a reader assume
            # the pull-request rule ran.
            if error.status != 422 or "inputs" not in payload:
                raise
        print(
            f"::warning::ci.yml on {branch} does not accept the pr_number input (422); "
            "re-dispatched without it. That run resolves to LENIENT mode, so the "
            "migration-namespace open-while-present rule is not asserted on it.",
            flush=True,
        )
        self.request("POST", "/actions/workflows/ci.yml/dispatches", {"ref": branch})

    def merge(self, number: int, head_sha: str) -> dict[str, Any]:
        return self.request(
            "PUT",
            f"/pulls/{number}/merge",
            {"merge_method": "squash", "sha": head_sha},
        )

    def add_labels(self, number: int, labels: list[str]) -> None:
        self.request("POST", f"/issues/{number}/labels", {"labels": labels})

    def remove_label(self, number: int, label: str) -> None:
        encoded = urllib.parse.quote(label, safe="")
        try:
            self.request("DELETE", f"/issues/{number}/labels/{encoded}")
        except ApiError as error:
            if error.status != 404:
                raise

    def comment(self, number: int, body: str) -> None:
        self.request("POST", f"/issues/{number}/comments", {"body": body})

    def delete_branch(self, branch: str) -> None:
        encoded = urllib.parse.quote(f"heads/{branch}", safe="/")
        try:
            self.request("DELETE", f"/git/refs/{encoded}")
        except ApiError as error:
            if error.status not in {404, 422}:  # already absent
                raise


class MergeApi(Protocol):
    repo: str

    def list_pulls(self) -> list[dict[str, Any]]: ...
    def pull(self, number: int) -> dict[str, Any]: ...
    def check_runs(self, sha: str) -> list[dict[str, Any]]: ...
    def pull_request_ci_runs(self, sha: str) -> list[dict[str, Any]]: ...
    def rerun_workflow_run(self, run_id: int) -> None: ...
    def update_branch(self, number: int, head_sha: str) -> None: ...
    def dispatch_ci(self, branch: str, pr_number: int | None = None) -> None: ...
    def merge_queue_enabled(self, base_ref: str) -> bool: ...
    def queue_entry(self, pull_request_id: str) -> str | None: ...
    def enqueue(self, pull_request_id: str, head_sha: str) -> str: ...
    def merge(self, number: int, head_sha: str) -> dict[str, Any]: ...
    def add_labels(self, number: int, labels: list[str]) -> None: ...
    def remove_label(self, number: int, label: str) -> None: ...
    def comment(self, number: int, body: str) -> None: ...
    def delete_branch(self, branch: str) -> None: ...


@dataclass(frozen=True)
class CheckVerdict:
    state: str
    detail: str


def label_names(pull: dict[str, Any]) -> set[str]:
    return {str(label.get("name", "")) for label in pull.get("labels", [])}


def trusted_check_app_id(run: dict[str, Any]) -> int | None:
    app = run.get("app")
    if not isinstance(app, dict):
        return None
    app_id = app.get("id")
    # bool is an int subclass, so require the exact response type GitHub emits.
    return app_id if type(app_id) is int else None


def latest_named_checks(check_runs: Iterable[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    latest: dict[str, dict[str, Any]] = {}
    for run in check_runs:
        name = str(run.get("name", ""))
        if name not in REQUIRED_CHECKS:
            continue
        if trusted_check_app_id(run) != REQUIRED_CHECK_APP_ID:
            continue
        prior = latest.get(name)
        if prior is None or int(run.get("id", 0)) > int(prior.get("id", 0)):
            latest[name] = run
    return latest


def check_verdict(check_runs: Iterable[dict[str, Any]]) -> CheckVerdict:
    latest = latest_named_checks(check_runs)
    missing = [name for name in REQUIRED_CHECKS if name not in latest]
    if missing:
        return CheckVerdict(
            "pending",
            f"missing trusted App {REQUIRED_CHECK_APP_ID} checks: {', '.join(missing)}",
        )

    waiting = [name for name, run in latest.items() if run.get("status") != "completed"]
    if waiting:
        return CheckVerdict("pending", f"pending: {', '.join(waiting)}")

    red = [
        f"{name}={latest[name].get('conclusion') or 'unknown'}"
        for name in REQUIRED_CHECKS
        if latest[name].get("conclusion") != "success"
    ]
    if red:
        return CheckVerdict("red", ", ".join(red))
    return CheckVerdict("green", "all required checks completed successfully")


def is_armed_candidate(pull: dict[str, Any], repo: str) -> bool:
    labels = label_names(pull)
    return (
        ARM_LABEL in labels
        and not pull.get("draft", False)
        and not labels.intersection(HOLD_LABELS)
        and pull.get("head", {}).get("repo", {}).get("full_name") == repo
        and pull.get("base", {}).get("ref") == "master"
    )


def mark_blocked(api: MergeApi, pull: dict[str, Any], reason: str) -> None:
    number = int(pull["number"])
    if BLOCK_LABEL in label_names(pull):
        return
    api.add_labels(number, [BLOCK_LABEL])
    api.comment(
        number,
        f"{BLOCK_MARKER}\nAutomatic merge paused: {reason}. Fix the branch or rerun CI; "
        f"the sweeper will re-evaluate the latest head without an admin bypass.",
    )


def newest_pull_request_run(
    runs: Iterable[dict[str, Any]], head_sha: str, repo: str
) -> dict[str, Any] | None:
    """The newest same-repository ``pull_request`` CI run for exactly this head."""
    matching = [
        run
        for run in runs
        if run.get("event") == "pull_request"
        and str(run.get("head_sha", "")) == head_sha
        and (run.get("head_repository") or {}).get("full_name") == repo
    ]
    if not matching:
        return None
    return max(matching, key=lambda run: int(run.get("id", 0)))


def is_held(run: dict[str, Any]) -> bool:
    # GitHub records a run it will not start until someone approves it as already
    # completed with conclusion action_required, and creates no jobs for it.
    return run.get("status") == "completed" and run.get("conclusion") == "action_required"


def held_pull_request_run(api: MergeApi, head_sha: str) -> dict[str, Any] | None:
    run = newest_pull_request_run(api.pull_request_ci_runs(head_sha), head_sha, api.repo)
    return run if run is not None and is_held(run) else None


def release_held_run(api: MergeApi, run: dict[str, Any]) -> str:
    """Re-run one held pull_request CI run and say what happened.

    This only starts the repository's own CI for a head that is already on the
    pull request. The merge still waits for those required checks to pass.
    """
    run_id = int(run["id"])
    actor = str((run.get("actor") or {}).get("login") or "unknown")
    if actor != HELD_RUN_ACTOR:
        return f"pull_request CI run {run_id} is waiting for a maintainer to approve {actor}'s run"
    attempt = int(run.get("run_attempt") or 1)
    if attempt > 1:
        # A re-run the controller already ordered came back held again. Doing it
        # again every sweep would loop, so leave it to a person.
        return (
            f"pull_request CI run {run_id} is still held after {attempt} attempts; "
            "a maintainer must re-run it"
        )
    try:
        api.rerun_workflow_run(run_id)
    except ApiError as error:
        if not (400 <= error.status < 500):
            raise
        return f"declined: re-run of held pull_request CI run {run_id}: {error}"
    return f"re-ran held pull_request CI run {run_id} for {run.get('head_sha')}; awaiting PR-linked CI"


def start_refreshed_ci(
    api: MergeApi, number: int, branch: str, old_head: str, wait
) -> str:
    """Start the pull-request CI for the head update-branch has just written.

    update-branch answers 202 before the merge commit exists, so look for the new
    head and its pull_request run a bounded number of times. A held run is re-run;
    a run that is already queued or running needs nothing.
    """
    advanced = False
    for attempt in range(REFRESH_RUN_POLLS):
        if attempt:
            wait(REFRESH_RUN_POLL_SECONDS)
        new_head = str(api.pull(number)["head"]["sha"])
        if new_head == old_head:
            continue
        advanced = True
        run = newest_pull_request_run(api.pull_request_ci_runs(new_head), new_head, api.repo)
        if run is None:
            continue
        if is_held(run):
            return release_held_run(api, run)
        return f"pull_request CI run {run['id']} is {run.get('status')}; awaiting PR-linked CI"
    if not advanced:
        # Dispatching now would only prove the old head. A later sweep sees either
        # the new head (and releases its held run) or a still-behind branch.
        return "update-branch has not written a new head yet; a later sweep re-checks it"
    # No pull_request run appeared in time. Order the checks explicitly so the head
    # is not left without any. If a held run appears later, a later sweep re-runs it.
    api.dispatch_ci(branch, number)
    return "no pull_request CI run appeared for the new head; dispatched CI; awaiting fresh CI"


def parse_target_pr(raw: str | None) -> int | None:
    """Validate the optional ``target_pr`` workflow_dispatch input.

    ``None`` (absent or empty) keeps the normal all-candidates sweep. Anything
    else must already be a canonical ASCII decimal pull request number:
    whitespace, signs, zero, Unicode digits and values beyond the controller's bounded
    range are configuration errors, never a silent fallback to the unrelated
    armed queue.
    """
    value = raw or ""
    if value == "":
        return None
    if not value.isascii() or not all(character in "0123456789" for character in value):
        raise ValueError(
            f"target_pr must be a plain ASCII decimal pull request number, got {raw!r}"
        )
    number = int(value)
    if number == 0:
        raise ValueError("target_pr must be a positive pull request number, not 0")
    if number > MAX_PULL_REQUEST_NUMBER:
        raise ValueError(
            f"target_pr {number} exceeds the maximum pull request number "
            f"{MAX_PULL_REQUEST_NUMBER}"
        )
    return number


def sweep(
    api: MergeApi,
    trigger_number: int | None = None,
    *,
    target_number: int | None = None,
    wait=time.sleep,
) -> list[str]:
    pulls = [pull for pull in api.list_pulls() if is_armed_candidate(pull, api.repo)]
    if target_number is not None:
        # An explicit target_pr dispatch reconciles exactly that pull request:
        # never fall back to the unrelated armed queue, and never act on any
        # other pull request even if the target turns out not to be a candidate.
        pulls = [pull for pull in pulls if int(pull["number"]) == target_number]
    if trigger_number is not None:
        pulls.sort(key=lambda pull: (int(pull["number"]) != trigger_number, pull.get("created_at", "")))
    else:
        pulls.sort(key=lambda pull: pull.get("created_at", ""))

    actions: list[str] = []
    queue_enabled = api.merge_queue_enabled("master") if pulls else False
    merged_this_sweep = False
    first_pass_size = len(pulls)
    pending_mergeability = False
    for position, listed in enumerate(pulls):
        if position == first_pass_size and pending_mergeability:
            # Revisit the fixed first-pass pending/refresh set once. Only pending
            # mergeability needs the shared short wait. Every proof is read again; no prior
            # mutation or refused API request is queued for retry.
            wait(2)
        number = int(listed["number"])
        pull = api.pull(number)  # refresh head/base after any earlier merge in this sweep
        if not is_armed_candidate(pull, api.repo):
            continue

        if pull.get("mergeable") is False or pull.get("mergeable_state") == "dirty":
            mark_blocked(api, pull, "the head conflicts with current master")
            actions.append(f"#{number}: conflict")
            continue
        if pull.get("mergeable") is None:
            if position < first_pass_size:
                pending_mergeability = True
                pulls.append(listed)
            else:
                actions.append(f"#{number}: mergeability pending")
            continue


        head_sha = str(pull["head"]["sha"])
        verdict = check_verdict(api.check_runs(head_sha))
        if verdict.state == "pending":
            # Nothing may ever start for a head whose pull_request run is held, so
            # release it instead of waiting on checks that cannot arrive.
            held = held_pull_request_run(api, head_sha)
            actions.append(f"#{number}: {release_held_run(api, held) if held else verdict.detail}")
            continue
        if verdict.state == "red":
            mark_blocked(api, pull, f"the latest required CI is red ({verdict.detail})")
            actions.append(f"#{number}: red")
            continue

        if BLOCK_LABEL in label_names(pull):
            api.remove_label(number, BLOCK_LABEL)

        # `pull["base"]["sha"]` on this same payload is the base ref position at
        # the moment the PR was last synced by GitHub and can sit many commits
        # behind the live branch tip (measured on #422: base.sha was stale while
        # master had moved on). `mergeable_state` is GitHub's own live relation to
        # the CURRENT base branch, so the refresh-vs-merge decision reads that
        # field instead of comparing against the stale sha.
        mergeable_state = str(pull.get("mergeable_state") or "unknown")
        if queue_enabled:
            if mergeable_state not in {"clean", "behind"}:
                held = held_pull_request_run(api, head_sha)
                waiting = f"waiting (mergeable_state={mergeable_state})"
                actions.append(f"#{number}: {release_held_run(api, held) if held else waiting}")
                continue
            pull_request_id = str(pull.get("node_id") or "")
            if not pull_request_id:
                actions.append(f"#{number}: waiting (missing pull request node_id)")
                continue
            existing_entry = api.queue_entry(pull_request_id)
            if existing_entry is not None:
                actions.append(f"#{number}: already queued ({existing_entry})")
                continue
            # A GITHUB_TOKEN enqueue return does not prove downstream merge_group
            # event delivery. Keep this workflow read-only at the admission seam;
            # a maintainer uses the existing native-user path with the verified
            # head pinned. This is not a finding about every missing event.
            # Admission, ordering and revalidation then belong to the queue.
            actions.append(
                f"#{number}: ready for the merge queue; native user admission required "
                f"(gh pr merge {number} --auto --match-head-commit {head_sha}); "
                f"head {head_sha} verified green by this sweep"
            )
            continue
        if mergeable_state == "behind":
            if position < first_pass_size:
                # Give already-ready heads their turn before spending this
                # sweep's refresh. Re-read every gate on the deferred visit.
                pulls.append(listed)
                continue
            branch = str(pull["head"]["ref"])
            api.update_branch(number, head_sha)
            # This GITHUB_TOKEN write leaves the new head's pull_request run held.
            # Re-run that run: it is the one the pull request's rollup reads. The
            # number is passed to the fallback dispatch so the namespace guard can
            # still earn PULL_REQUEST mode if that path is taken.
            started = start_refreshed_ci(api, number, branch, head_sha, wait)
            actions.append(f"#{number}: updated onto current master; {started}")
            # An update creates the next safe wake-up. Stop so no other green is
            # judged against a base snapshot this mutation just invalidated.
            break
        if mergeable_state != "clean":
            # blocked/unstable/unknown/has_hooks: GitHub has not (yet) confirmed a
            # clean merge against the current base. Wait for the next sweep
            # rather than attempting a merge GitHub has not settled on, or that a
            # strict-protection 405 would only refuse anyway. The exception is a
            # held pull_request run: green checks from another run on this commit
            # never satisfy the rollup, so waiting alone would never end (#874).
            held = held_pull_request_run(api, head_sha)
            waiting = f"waiting (mergeable_state={mergeable_state})"
            actions.append(f"#{number}: {release_held_run(api, held) if held else waiting}")
            continue

        try:
            result = api.merge(number, head_sha)
        except ApiError as error:
            # GitHub itself refusing the merge call (405 under strict
            # required-status protection when its own view of the PR is still
            # settling, or any other 4xx) is this PR's own wait, never a reason
            # to stop evaluating the rest of the sweep. A 5xx/429/other
            # non-4xx is NOT GitHub declining the merge on the merits -- it is
            # the API itself failing -- so it is reraised and still aborts the
            # sweep via main()'s existing handler rather than being recorded as
            # a per-PR "declined" outcome that word does not honestly describe.
            if not (400 <= error.status < 500):
                raise
            actions.append(f"#{number}: declined: {error}")
            continue
        if not result.get("merged"):
            # The head/base may have moved between proof and the SHA-pinned write.
            # That is a wait, not permission to force an admin merge.
            actions.append(f"#{number}: merge declined ({result.get('message', 'state changed')})")
            continue

        branch = str(pull["head"]["ref"])
        if branch != "master":
            api.delete_branch(branch)
        actions.append(f"#{number}: merged and deleted {branch}")
        merged_this_sweep = True
        # Continue only to refresh the next stale green branch. It cannot merge
        # against the pre-merge base because api.pull() is re-read above.

    if merged_this_sweep and not any("updated onto" in action for action in actions):
        actions.append("no additional armed green branch required a base refresh")
    return actions


def main() -> int:
    repo = os.environ.get("GH_REPO", "").strip()
    token = (os.environ.get("MERGE_TOKEN") or os.environ.get("GITHUB_TOKEN") or "").strip()
    if not repo or not token:
        print("::error::GH_REPO and MERGE_TOKEN or GITHUB_TOKEN are required", file=sys.stderr)
        return 2
    event_name = os.environ.get("GITHUB_EVENT_NAME", "").strip()
    trigger_raw = os.environ.get("TRIGGER_PR_NUMBER", "").strip()
    trigger = int(trigger_raw) if trigger_raw.isdigit() else None
    # The optional target is validated -- and any trigger conflict rejected --
    # before the API client is constructed: a mistyped or misplaced target_pr
    # must fail the run without touching GitHub at all.
    try:
        target = parse_target_pr(os.environ.get("TARGET_PR"))
    except ValueError as error:
        print(f"::error::{error}", file=sys.stderr)
        return 2
    if target is not None and event_name != "workflow_dispatch":
        print(
            "::error::target_pr is only honored on workflow_dispatch; this run is "
            f"{event_name or 'an unknown event'}",
            file=sys.stderr,
        )
        return 2
    if target is not None and trigger is not None:
        print(
            f"::error::target_pr {target} conflicts with the pull request #{trigger} "
            "this event is itself about",
            file=sys.stderr,
        )
        return 2
    try:
        if target is None:
            actions = sweep(GitHubApi(repo, token), trigger)
        else:
            actions = sweep(GitHubApi(repo, token), trigger, target_number=target)
    except (ApiError, KeyError, TypeError, ValueError) as error:
        print(f"::error::{error}", file=sys.stderr)
        return 1
    if not actions:
        if target is not None:
            print(
                f"::notice::Target pull request #{target} is not an armed {ARM_LABEL} "
                "candidate; no other pull request was considered"
            )
        else:
            print(f"::notice::No open pull request is armed with {ARM_LABEL}")
    else:
        for action in actions:
            print(f"::notice::{action}")
    # A declined merge (e.g. GitHub 405s a merge attempt) is reported only after
    # every armed pull request has been evaluated (never mid-sweep, unlike the
    # unhandled-exception path above that aborted the whole sweep on the first
    # such PR); exiting non-zero here still surfaces it to the workflow run
    # without having skipped any other armed pull request.
    # "declined:" also covers a refused re-run reported inside a refresh line
    # ("#7: updated onto current master; declined: ...").
    if any("declined:" in action for action in actions):
        print(
            "::error::one or more armed pull requests were declined by GitHub this sweep; see notices above",
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
