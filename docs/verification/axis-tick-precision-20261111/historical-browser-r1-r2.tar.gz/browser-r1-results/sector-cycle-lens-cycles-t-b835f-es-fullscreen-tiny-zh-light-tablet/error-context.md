# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: sector-cycle-lens.spec.ts >> cycles tick precision survives fullscreen tiny zh light
- Location: e2e/sector-cycle-lens.spec.ts:110:9

# Error details

```
Error: SVG coordinates must follow the current measured content width

SVG coordinates must follow the current measured content width

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 1
Received:    500

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]:
      - strong [ref=e4]: DEV harness · SectorCycleLens
      - generic [ref=e5]: Fixture data — not live evidence
      - generic [ref=e6]:
        - radio "EN" [ref=e7]
        - text: EN
      - generic [ref=e8]:
        - radio "ZH" [checked] [ref=e9]
        - text: ZH
      - generic [ref=e10]:
        - radio "Dark" [ref=e11]
        - text: Dark
      - generic [ref=e12]:
        - radio "Light" [checked] [ref=e13]
        - text: Light
      - generic [ref=e14]:
        - text: Axis fixture
        - combobox "Axis fixture" [ref=e15]:
          - option "Standard history"
          - option "Tiny values (0 to 0.01)" [selected]
          - option "Fractional ticks (-4 to 4)"
      - generic [ref=e16]:
        - radio "Generation current" [checked] [ref=e17]
        - text: Generation current
      - generic [ref=e18]:
        - radio "Generation replaced" [ref=e19]
        - text: Generation replaced
      - generic [ref=e20]:
        - radio "Heads today" [checked] [ref=e21]
        - text: Heads today
      - generic [ref=e22]:
        - radio "One head withdrawn" [ref=e23]
        - text: One head withdrawn
      - generic [ref=e24]:
        - radio "Heads absent" [ref=e25]
        - text: Heads absent
    - generic [ref=e26]:
      - generic [ref=e28]:
        - heading "板块周期" [level=2] [ref=e29]
        - paragraph [ref=e30]: 科技 XLK · 截至 2026-10-30 · 板块 ETF 对比 SPY · 重构价格历史
      - generic [ref=e32]:
        - generic [ref=e33]:
          - generic [ref=e34]:
            - heading "科技 XLK" [level=3] [ref=e35]
            - generic [ref=e36]:
              - generic [ref=e37]: "周期阶段 · 本体框架: 扩张"
              - generic [ref=e38]: 位置 · 本体框架 72
              - generic [ref=e39]:
                - text: 价格与200日均线
                - generic [ref=e40]: 高于
            - paragraph [ref=e41]: 0–100刻度，并非概率。
          - generic [ref=e42]:
            - button "更换序列" [ref=e43] [cursor=pointer]
            - button "查看板块档案" [ref=e44] [cursor=pointer]
        - generic [ref=e45]:
          - heading "时钟" [level=4] [ref=e46]
          - generic [ref=e47]:
            - generic [ref=e48]: 阶段时钟
            - generic [ref=e49]: 时序阶梯
            - generic [ref=e50]: 风险时钟
            - generic "各分歧时钟自身的数值保留于来源抽屉。" [ref=e51]: 节律时钟 ⚠
            - generic [ref=e52]: 周期读数
          - paragraph [ref=e53]: 各分歧时钟自身的数值保留于来源抽屉。
        - generic [ref=e54]:
          - heading "相对 SPY 强弱" [level=3] [ref=e56]
          - generic [ref=e57]:
            - button "序列（5）" [ref=e58] [cursor=pointer]: 序列（5）＋
            - generic [ref=e59]:
              - text: 图表范围
              - combobox "图表范围" [ref=e60]:
                - option "21个交易日"
                - option "63个交易日"
                - option "252个交易日"
                - option "全部" [selected]
            - generic [ref=e61]:
              - text: 刻度
              - combobox "刻度" [ref=e62]:
                - option "线性" [selected]
                - option "对数" [disabled]
            - group "相对 SPY 强弱" [ref=e63]:
              - button "图表" [pressed] [ref=e64] [cursor=pointer]
              - button "数据表" [ref=e65] [cursor=pointer]
            - button "全屏" [ref=e66] [cursor=pointer]: 全屏⤢
          - generic [ref=e67]:
            - generic [ref=e68]:
              - text: XLK · 21个交易日
              - generic [ref=e70]: 总回报
            - generic [ref=e71]:
              - text: XLK · 63个交易日
              - generic [ref=e73]: 总回报
          - generic [ref=e74]:
            - generic [ref=e75]:
              - generic [ref=e76]:
                - text: XLK · 21个交易日
                - strong [ref=e77]: +0.0%
              - generic [ref=e78]:
                - text: XLK · 63个交易日
                - strong [ref=e79]: +0.0%
              - time [ref=e80]: 2026-05-02
            - img "相对 SPY 强弱" [ref=e82]:
              - generic [ref=e84]: "0.000"
              - generic [ref=e86]: "0.005"
              - generic [ref=e88]: "0.010"
              - generic "2025-09-13 · trough" [ref=e91]
              - generic "2025-11-12 · peak" [ref=e93]
              - generic "2026-01-21 · trough" [ref=e95]
              - generic "2026-03-12 · peak · 暂定" [ref=e97]
              - generic [ref=e99]: 底部 2025-09-13
              - generic [ref=e100]: 顶部 2025-11-12
              - generic [ref=e101]: 底部 2026-01-21
              - generic [ref=e102]: 顶部 2026-03-12
              - generic [ref=e105]: 2025-08-24
              - generic [ref=e106]: 2025-09-17
              - generic [ref=e107]: 2025-10-11
              - generic [ref=e108]: 2025-11-04
              - generic [ref=e109]: 2025-11-28
              - generic [ref=e110]: 2025-12-22
              - generic [ref=e111]: 2026-01-15
              - generic [ref=e112]: 2026-02-08
              - generic [ref=e113]: 2026-03-04
              - generic [ref=e114]: 2026-03-28
              - generic [ref=e115]: 2026-05-02
            - slider "观测日期" [ref=e116]: "251"
            - generic [ref=e117]:
              - generic [ref=e118]: 2025-08-24
              - generic [ref=e119]: 2026-05-02
          - generic [ref=e120]:
            - heading "价格转折" [level=4] [ref=e121]
            - paragraph [ref=e122]: 转折日期为拐点日期。拐点仅在确认后才可知 — 两种日期严格区分。
            - generic [ref=e123]:
              - time [ref=e124]: 2026-03-12
              - generic [ref=e125]: 高点
              - emphasis [ref=e126]: 暂定
            - generic [ref=e127]:
              - time [ref=e128]: 2026-01-21
              - generic [ref=e129]: 低点
              - emphasis [ref=e130]: 已确认
              - emphasis [ref=e131]: · 最早可知 2026-01-24
            - generic [ref=e132]:
              - time [ref=e133]: 2025-11-12
              - generic [ref=e134]: 高点
              - emphasis [ref=e135]: 已确认
              - emphasis [ref=e136]: · 最早可知 2025-11-15
          - group [ref=e137]:
            - generic "精确数值" [ref=e138] [cursor=pointer]
          - group [ref=e139]:
            - generic "计算方法" [ref=e140]
        - generic [ref=e141]:
          - heading "周期段 timeline" [level=3] [ref=e142]
          - list [ref=e144]:
            - listitem [ref=e145]:
              - button "2025-09-13 → 2025-11-12" [ref=e146] [cursor=pointer]:
                - generic [ref=e147]: 2025-09-13 → 2025-11-12
                - generic [ref=e148]: ▲
            - listitem [ref=e149]:
              - button "2025-11-12 → 2026-01-21" [ref=e150] [cursor=pointer]:
                - generic [ref=e151]: 2025-11-12 → 2026-01-21
                - generic [ref=e152]: ▼
            - listitem [ref=e153]:
              - button "2026-01-21 → 2026-03-12 · 暂定" [ref=e154] [cursor=pointer]:
                - generic [ref=e155]: 2026-01-21 → 2026-03-12 · 暂定
                - generic [ref=e156]: ▲
            - listitem [ref=e157]:
              - button "2026-03-12 · 开放段 · 开放 · 51 个交易日" [ref=e158] [cursor=pointer]:
                - generic [ref=e159]: 2026-03-12 · 开放段 · 开放 · 51 个交易日
                - generic [ref=e160]: ▼
        - generic [ref=e161]:
          - generic [ref=e162]:
            - heading "解读" [level=3] [ref=e163]
            - paragraph [ref=e164]: 生产解读所指阶段族与阶段时钟不同；原文保留于来源抽屉，不作为当前读数显示。
          - generic [ref=e165]:
            - heading "轮动事件" [level=3] [ref=e166]
            - paragraph [ref=e167]: 该窗口内没有已结束的轮动事件
        - generic [ref=e168]:
          - generic [ref=e169]:
            - heading "拐点估计与先验" [level=3] [ref=e170]
            - group "转折风险（仅历史校验）" [ref=e171]:
              - heading "转折风险（仅历史校验）" [level=4] [ref=e172]
              - generic [ref=e173]:
                - generic [ref=e174]: 转折≤1月
                - generic [ref=e175]: ≤3月
                - generic [ref=e176]: ≤6月
                - generic [ref=e177]: 向上段 · 顶部
                - generic [ref=e178]:
                  - generic [ref=e179]: 18%
                  - generic [ref=e180]: 模型
                - generic [ref=e181]:
                  - generic [ref=e182]: 34%
                  - generic [ref=e183]: 先验
                - generic [ref=e184]:
                  - generic [ref=e185]: 41%
                  - generic [ref=e186]: 模型
              - paragraph [ref=e187]: 先验：历史基准率，并非模型
          - generic [ref=e188]:
            - generic [ref=e189]:
              - heading "方法与限制" [level=3] [ref=e190]
              - list [ref=e191]:
                - listitem [ref=e192]: 仓位规模：无。信念倍数固定为 1.0，并非仓位大小。
                - listitem [ref=e193]: 自身节律，描述性，非模型。
                - listitem [ref=e194]: 领先滞后：不作声明。领先滞后研究已停止；此处不对板块作时间排序。
                - listitem [ref=e195]: 源数据一致性核验通过，模型资格仍需单独判断
              - group [ref=e196]:
                - generic "证据详情" [ref=e197] [cursor=pointer]
            - generic [ref=e198]:
              - paragraph [ref=e199]: 判断评分器
              - heading "判断评分器：已衡量命中率" [level=3] [ref=e200]
              - paragraph [ref=e201]: 全部已结算判断（含中性）的条件命中率，并非胜率。
              - paragraph [ref=e202]: 按时间跨度衡量信念判断的已实现方向命中率、横截面秩相关与超越SPY的超额收益。数据累积前较稀疏；绝不回灌入实时评分。
              - paragraph [ref=e203]: 本生成版本暂无评分器
          - generic [ref=e204]:
            - heading "时机与推演" [level=3] [ref=e205]
            - paragraph [ref=e206]: ◷本阶段已持续 18 个交易日
            - paragraph [ref=e207]:
              - text: 价格与200日均线 高于
              - generic [ref=e208]: 上涨趋势
            - paragraph [ref=e209]: 阶段时长是已测量的历史事实 — 并非剩余上行空间，也不是时间限制。
            - generic [ref=e210]:
              - generic [ref=e211]:
                - generic [ref=e212]: 描述性节律
                - generic [ref=e213]: 时间窗尚未开启
              - paragraph [ref=e214]: 下次底部 ≈ 2027年2月
              - generic [ref=e215]:
                - generic [ref=e216]:
                  - term [ref=e217]: 最早
                  - definition [ref=e218]: 2026年12月
                - generic [ref=e219]:
                  - term [ref=e220]: 中位
                  - definition [ref=e221]: 2027年2月
                - generic [ref=e222]:
                  - term [ref=e223]: 最晚
                  - definition [ref=e224]: 2027年4月
              - paragraph [ref=e225]: 预计下次底部约在 2027年2月（2026年12月–2027年4月），基于该板块自身的中位半周期：描述性节律而非模型，仅为时间窗口。
        - generic [ref=e226]:
          - heading "剩余机会预测" [level=3] [ref=e227]
          - list [ref=e228]:
            - listitem [ref=e229]:
              - generic [ref=e230]: 剩余回报
              - generic [ref=e231]: 暂缓显示
              - generic [ref=e232]: 暂缓：该预测在当前数据上的研究检验未通过
              - generic [ref=e233]: 时间跨度：20 个已完结交易日
              - group [ref=e234]:
                - generic "证据" [ref=e235]
            - listitem [ref=e236]:
              - generic [ref=e237]: 不利尾部
              - generic [ref=e238]: 暂缓显示
              - generic [ref=e239]: 暂缓：实时周期状态与研究协议的转折口径不一致
              - generic [ref=e240]: 时间跨度：20 个已完结交易日
              - group [ref=e241]:
                - generic "证据" [ref=e242]
            - listitem [ref=e243]:
              - generic [ref=e244]: 先达目标还是先失效
              - generic [ref=e245]: 暂缓显示
              - generic [ref=e246]: 暂缓：实时周期状态与研究协议的转折口径不一致
              - generic [ref=e247]: 时间跨度：20 个已完结交易日
              - generic [ref=e248]: 周期段方向事实：描述当前上行/下行段的倾向，并非周期择时边界。
              - group [ref=e249]:
                - generic "证据" [ref=e250]
            - listitem [ref=e251]:
              - generic [ref=e252]: 转折确认时间
              - generic [ref=e253]: 暂缓显示
              - generic [ref=e254]: 暂缓：实时周期状态与研究协议的转折口径不一致
              - generic [ref=e255]: 时间跨度：20 个已完结交易日
              - group [ref=e256]:
                - generic "证据" [ref=e257]
          - paragraph [ref=e258]: 暂缓显示的预测不展示任何数值。
          - paragraph [ref=e259]: 每项预测单独判断是否暂缓显示；上方已观测的周期事实不受影响。
        - paragraph [ref=e260]: 描述性证据，不构成个股建议、仓位建议或执行授权。
      - dialog "周期全屏" [active] [ref=e262]:
        - generic [ref=e263]:
          - paragraph [ref=e264]: 相对 SPY 强弱
          - generic [ref=e265]:
            - group "相对 SPY 强弱" [ref=e266]:
              - button "图表" [pressed] [ref=e267] [cursor=pointer]
              - button "数据表" [ref=e268] [cursor=pointer]
            - button "关闭全屏" [ref=e269] [cursor=pointer]: ✕
        - img "相对 SPY 强弱" [ref=e270]:
          - generic [ref=e272]: "0.0000"
          - generic [ref=e274]: "0.0025"
          - generic [ref=e276]: "0.0050"
          - generic [ref=e278]: "0.0075"
          - generic [ref=e280]: "0.0100"
          - generic "2025-09-13 · trough · 最早可知 2025-09-16" [ref=e283]
          - generic "2025-11-12 · peak · 最早可知 2025-11-15" [ref=e284]
          - generic "2026-01-21 · trough · 最早可知 2026-01-24" [ref=e285]
          - generic "2026-03-12 · peak · 暂定" [ref=e286]
          - generic [ref=e287]: 底部 2025-09-13
          - generic [ref=e288]: 顶部 2026-03-12
        - generic [ref=e291]:
          - time [ref=e292]: 2026-05-02
          - generic [ref=e293]:
            - text: XLK · 21个交易日
            - strong [ref=e294]: +0.0%
          - generic [ref=e295]:
            - text: XLK · 63个交易日
            - strong [ref=e296]: +0.0%
  - alert [ref=e297]
```

# Test source

```ts
  1   | import { test, expect, type Locator } from "@playwright/test";
  2   | 
  3   | /* Cycles lane e2e — the /dev/sector-cycles harness (deterministic inline
  4   |  * fixtures, no network, clearly labelled as fixture data on the page itself).
  5   |  *
  6   |  * Charter gate 4: keyboard and touch through family/phase/range/scale/leg
  7   |  * selection, chart↔table equivalence, capture→navigate→apply return, at
  8   |  * 1440×900, 820×1180 and 390×844 (desktop/tablet/mobile), light+dark, EN+ZH.
  9   |  * The self-bound return router is exercised for real: leaving a subject
  10  |  * pushes its captured view onto the history entry being left; the browser
  11  |  * back button rebinds that subject (donor #10707 host contract) and the
  12  |  * two-phase codec restores the captured fields. */
  13  | 
  14  | const cases = [
  15  |   ["en", "dark"],
  16  |   ["zh", "light"],
  17  | ] as const;
  18  | 
  19  | const T = (lang: "en" | "zh") => ({
  20  |   chart: lang === "zh" ? "图表" : "Chart",
  21  |   table: lang === "zh" ? "数据表" : "Data table",
  22  |   range: lang === "zh" ? "图表范围" : "Chart range",
  23  |   log: lang === "zh" ? "对数" : "Log",
  24  |   series: lang === "zh" ? "序列" : "Series",
  25  |   obs: lang === "zh" ? "观测日期" : "Observation date",
  26  |   exact: lang === "zh" ? "精确数值" : "Exact values",
  27  |   baskets: lang === "zh" ? "主题组合对比 SPY" : "Thematic Baskets vs SPY",
  28  |   sectorsTab: lang === "zh" ? "板块 ETF 对比 SPY" : "Sector ETFs vs SPY",
  29  |   apply: lang === "zh" ? "应用" : "Apply",
  30  |   legDetails: lang === "zh" ? "周期段详情" : "Leg details",
  31  |   fullscreen: lang === "zh" ? "周期全屏" : "Cycles fullscreen",
  32  |   openFullscreen: lang === "zh" ? "打开全屏" : "Open fullscreen",
  33  |   fullscreenBtn: lang === "zh" ? "全屏" : "Full screen",
  34  |   changeSeries: lang === "zh" ? "更换序列" : "Change series",
  35  |   phaseAll: lang === "zh" ? "全部阶段" : "All phases",
  36  |   expansion: lang === "zh" ? "扩张" : "Expansion",
  37  |   selectedFoot: lang === "zh" ? "已选" : "Selected",
  38  |   troughWord: lang === "zh" ? "底部" : "trough",
  39  |   prov: lang === "zh" ? "暂定" : "Provisional",
  40  |   rs63: lang === "zh" ? "63个交易日" : "63 sessions",
  41  |   trough: lang === "zh" ? "底部" : "Trough",
  42  |   recovery: lang === "zh" ? "复苏" : "Recovery",
  43  |   energy: lang === "zh" ? "能源" : "Energy",
  44  |   financials: lang === "zh" ? "金融" : "Financials",
  45  |   aiInfra: lang === "zh" ? "AI 基础设施" : "AI Infrastructure",
  46  |   story: lang === "zh" ? "趋成熟" : "matured",
  47  |   mismatch: lang === "zh" ? "快照版本不一致" : "Snapshots do not match",
  48  |   /* v1.1 per-head forecast capabilities + SP11 dates + honest windows */
  49  |   range21: lang === "zh" ? "21个交易日" : "21 sessions",
  50  |   range252: lang === "zh" ? "252个交易日" : "252 sessions",
  51  |   range1mWord: lang === "zh" ? "1个月" : "1 month",
  52  |   durationWord: lang === "zh" ? "并非剩余上行空间" : "not remaining upside",
  53  |   firstKnown: lang === "zh" ? "最早可知" : "first known",
  54  |   pivotNote: lang === "zh" ? "转折日期为拐点日期" : "Turn dates are pivot dates",
  55  |   headWithheld: lang === "zh" ? "暂缓显示" : "Withheld",
  56  |   headWithdrawnWord: lang === "zh" ? "已撤回" : "Withdrawn",
  57  |   reasonUnknown: lang === "zh" ? "因未说明的原因暂缓显示" : "Withheld for an unstated reason",
  58  |   reasonFailed: lang === "zh" ? "研究检验未通过" : "research test failed",
  59  |   reasonEpoch: lang === "zh" ? "与研究协议的转折口径不一致" : "does not match the research protocol",
  60  |   horizon20: lang === "zh" ? "20 个已完结交易日" : "20 completed sessions",
  61  |   directional: lang === "zh" ? "周期段方向事实" : "Leg-direction fact",
  62  |   headsAbsent: lang === "zh" ? "未附带预测能力分块" : "No forecast capability block",
  63  | });
  64  | 
  65  | 
  66  | async function expectMeasuredPlot(svg: Locator) {
  67  |   await expect(svg).toBeVisible();
  68  |   const geometry = () => svg.evaluate((element) => {
  69  |     const chart = element as SVGSVGElement;
  70  |     return {
  71  |       container: chart.parentElement!.clientWidth,
  72  |       width: Number(chart.getAttribute("width")),
  73  |       viewBox: chart.viewBox.baseVal.width,
  74  |       rendered: chart.getBoundingClientRect().width,
  75  |     };
  76  |   });
  77  |   expect((await geometry()).container).toBeGreaterThanOrEqual(240);
  78  |   await expect.poll(async () => {
  79  |     const value = await geometry();
  80  |     return Math.max(
  81  |       Math.abs(value.width - value.container),
  82  |       Math.abs(value.viewBox - value.container),
  83  |       Math.abs(value.rendered - value.container),
  84  |     );
> 85  |   }, { message: "SVG coordinates must follow the current measured content width" }).toBeLessThanOrEqual(1);
      |                                                                                     ^ Error: SVG coordinates must follow the current measured content width
  86  |   return geometry();
  87  | }
  88  | 
  89  | async function expectAxisLabels(svg: Locator, expected: string[]) {
  90  |   await expectMeasuredPlot(svg);
  91  |   // Tick labels belong to grid groups; date/turn labels use other anchors.
  92  |   const ticks = svg.locator('g > text[text-anchor="end"]');
  93  |   await expect(ticks).toHaveText(expected);
  94  |   expect(new Set(await ticks.allTextContents()).size).toBe(expected.length);
  95  |   const bounds = await ticks.evaluateAll(elements => elements.map(element => {
  96  |     const label = element.getBoundingClientRect();
  97  |     const chart = (element as SVGElement).ownerSVGElement!.getBoundingClientRect();
  98  |     return { left: label.left - chart.left, right: chart.right - label.right };
  99  |   }));
  100 |   for (const bound of bounds) {
  101 |     expect(bound.left).toBeGreaterThanOrEqual(-1);
  102 |     expect(bound.right).toBeGreaterThanOrEqual(-1);
  103 |   }
  104 | }
  105 | 
  106 | for (const [lang, theme] of cases) {
  107 |   const L = T(lang);
  108 | 
  109 |   for (const axisFixture of ["tiny", "fractional"] as const) {
  110 |     test(`cycles tick precision survives fullscreen ${axisFixture} ${lang} ${theme}`, async ({ page }, info) => {
  111 |       await page.goto("/dev/sector-cycles");
  112 |       await page.getByRole("radio", { name: lang === "zh" ? "ZH" : "EN", exact: true }).check();
  113 |       await page.getByRole("radio", { name: theme === "light" ? "Light" : "Dark", exact: true }).check();
  114 |       await page.getByLabel("Axis fixture").selectOption(axisFixture);
  115 |       await expect(page.getByText("Fixture data — not live evidence")).toBeVisible();
  116 |       await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
  117 | 
  118 |       const panel = page.getByTestId("cycle-chart-panel");
  119 |       await panel.getByLabel(L.range).selectOption("0");
  120 |       const inlineLabels = axisFixture === "tiny"
  121 |         ? ["0.000", "0.005", "0.010"] : ["-2.5", "0.0", "2.5"];
  122 |       const fullscreenLabels = axisFixture === "tiny"
  123 |         ? ["0.0000", "0.0025", "0.0050", "0.0075", "0.0100"]
  124 |         : ["-4", "-2", "0", "2", "4"];
  125 |       await expectAxisLabels(panel.locator("svg"), inlineLabels);
  126 |       await panel.screenshot({
  127 |         path: info.outputPath(`cycles-precision-${axisFixture}-inline-${lang}-${info.project.name}.png`),
  128 |         animations: "disabled",
  129 |       });
  130 | 
  131 |       await panel.getByRole("button", { name: new RegExp(L.fullscreenBtn) }).click();
  132 |       const dialog = page.getByRole("dialog", { name: L.fullscreen });
  133 |       await expect(dialog).toBeVisible();
  134 |       await expectAxisLabels(dialog.locator("svg"), fullscreenLabels);
  135 |       await dialog.screenshot({
  136 |         path: info.outputPath(`cycles-precision-${axisFixture}-fullscreen-${lang}-${info.project.name}.png`),
  137 |         animations: "disabled",
  138 |       });
  139 |       await page.keyboard.press("Escape");
  140 |       await expect(dialog).toBeHidden();
  141 |       await expectAxisLabels(panel.locator("svg"), inlineLabels);
  142 |       expect(await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)).toBeLessThanOrEqual(1);
  143 |     });
  144 |   }
  145 | 
  146 |   for (const transition of ["table", "empty"] as const) {
  147 |     test(`cycles chart measurement survives ${transition} transitions ${lang} ${theme}`, async ({ page }, info) => {
  148 |       await page.goto("/dev/sector-cycles");
  149 |       await page.getByRole("radio", { name: lang === "zh" ? "ZH" : "EN", exact: true }).check();
  150 |       await page.getByRole("radio", { name: theme === "light" ? "Light" : "Dark", exact: true }).check();
  151 | 
  152 |       const initialViewport = page.viewportSize()!;
  153 |       // Remain in the same responsive band, so a remounted panel cannot hide
  154 |       // the lost observer. The final capture returns to the contract viewport.
  155 |       const widths = initialViewport.width >= 981 ? [1100, 1280]
  156 |         : initialViewport.width >= 641 ? [700, 900] : [510, 430];
  157 |       const panel = page.getByTestId("cycle-chart-panel");
  158 |       const svg = panel.locator("svg");
  159 |       const expectThemePaint = async (selected: "light" | "dark") => {
  160 |         await expect.poll(() => panel.evaluate(element => {
  161 |           const root = document.documentElement;
  162 |           const tokens = getComputedStyle(root);
  163 |           const paint = getComputedStyle(element);
  164 |           return {
  165 |             theme: root.dataset.theme,
  166 |             appearance: root.dataset.terminalAppearance,
  167 |             sharedShell: root.dataset.mmxSharedShell ?? null,
  168 |             backgroundToken: tokens.getPropertyValue("--bg").trim(),
  169 |             secondaryPanelToken: tokens.getPropertyValue("--panel-2").trim(),
  170 |             textToken: tokens.getPropertyValue("--text").trim(),
  171 |             background: paint.backgroundColor,
  172 |             foreground: paint.color,
  173 |           };
  174 |         })).toEqual({
  175 |           theme: selected, appearance: "1", sharedShell: null,
  176 |           backgroundToken: selected === "light" ? "#f7f8fa" : "#0a0b0e",
  177 |           secondaryPanelToken: selected === "light" ? "#eef1f6" : "#15171d",
  178 |           textToken: selected === "light" ? "#202632" : "#d6dae3",
  179 |           background: selected === "light" ? "rgb(255, 255, 255)" : "rgb(13, 15, 19)",
  180 |           foreground: selected === "light" ? "rgb(32, 38, 50)" : "rgb(214, 218, 227)",
  181 |         });
  182 |       };
  183 |       await expectThemePaint(theme);
  184 |       const otherTheme = theme === "light" ? "dark" : "light";
  185 |       await page.getByRole("radio", { name: otherTheme === "light" ? "Light" : "Dark", exact: true }).check();
```