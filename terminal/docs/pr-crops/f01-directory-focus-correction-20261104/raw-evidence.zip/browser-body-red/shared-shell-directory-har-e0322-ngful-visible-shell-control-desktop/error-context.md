# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: shared-shell-directory-hardening.spec.ts >> shortcut from BODY returns to a meaningful visible shell control
- Location: e2e/shared-shell-directory-hardening.spec.ts:139:5

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('.topbar .shared-shell-directory-trigger')
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" with timeout 5000ms
  - waiting for locator('.topbar .shared-shell-directory-trigger')
    14 × locator resolved to <button type="button" aria-haspopup="dialog" aria-label="All tools" class="shared-shell-directory-trigger">…</button>
       - unexpected value "inactive"

```

```yaml
- button "All tools": All tools ⌘ K
```

# Test source

```ts
  55  |   expect(box!.x).toBeGreaterThanOrEqual(0);
  56  |   expect(box!.x + box!.width).toBeLessThanOrEqual(page.viewportSize()!.width + 1);
  57  |   expect(box!.y).toBeGreaterThanOrEqual(0);
  58  |   expect(box!.y + box!.height).toBeLessThanOrEqual(page.viewportSize()!.height + 1);
  59  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  60  | }
  61  | 
  62  | test("query-wide recovery is distinct from category scope in the real catalogue", async ({ page }, info) => {
  63  |   await open(page);
  64  |   const dialog = directory(page);
  65  |   await dialog.getByRole("searchbox").fill("options");
  66  |   await expect(dialog.locator(".shared-directory-link")).toHaveCount(12);
  67  |   const before = await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")));
  68  |   expect(before).toEqual(expect.arrayContaining(["/options", "/options.html", "/options_screener.html", "/options/futures"]));
  69  |   await dialog.getByRole("button", { name: "Workspaces", exact: true }).click();
  70  |   await expect(dialog.getByRole("status")).toHaveText("2 in this category");
  71  |   await expect(dialog.locator(".shared-directory-link")).toHaveCount(2);
  72  |   const recovery = dialog.getByRole("button", { name: "Show all 12 matches", exact: true });
  73  |   expect((await recovery.boundingBox())!.height).toBeGreaterThanOrEqual(44);
  74  |   await contained(page);
  75  |   await page.screenshot({ animations: "disabled", path: info.outputPath("category-recovery-dark-en.png") });
  76  |   await recovery.focus(); await page.keyboard.press("Enter");
  77  |   await expect(dialog.getByRole("button", { name: "All", exact: true })).toBeFocused();
  78  |   await expect(dialog.getByRole("searchbox")).toHaveValue("options");
  79  |   expect(await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")))).toEqual(before);
  80  |   await dialog.getByRole("button", { name: "Research", exact: true }).click();
  81  |   await expect(dialog.getByRole("heading", { name: "No matches in this category", exact: true })).toBeVisible();
  82  |   await expect(dialog.getByRole("status")).toHaveText("0 in this category");
  83  |   await expect(dialog.getByRole("button", { name: "Show all 12 matches", exact: true })).toBeVisible();
  84  |   await page.screenshot({ animations: "disabled", path: info.outputPath("empty-category-dark-en.png") });
  85  | });
  86  | 
  87  | test("clear query, batching and same-instance reopen retain the correct state", async ({ page }) => {
  88  |   await open(page); const dialog = directory(page);
  89  |   await dialog.getByRole("button", { name: "Show more", exact: true }).click();
  90  |   await expect(dialog.locator(".shared-directory-link")).toHaveCount(96);
  91  |   await page.keyboard.press("Escape"); await open(page);
  92  |   await expect(dialog.locator(".shared-directory-link")).toHaveCount(96);
  93  |   await dialog.getByRole("searchbox").fill("no-such-directory-destination-20261104");
  94  |   await expect(dialog.getByRole("heading", { name: "No pages found", exact: true })).toBeVisible();
  95  |   await dialog.getByRole("button", { name: "Tools", exact: true }).click();
  96  |   await dialog.getByRole("button", { name: "Clear search", exact: true }).click();
  97  |   await expect(dialog.getByRole("searchbox")).toHaveValue("");
  98  |   await expect(dialog.getByRole("searchbox")).toBeFocused();
  99  |   await expect(dialog.getByRole("button", { name: "Tools", exact: true })).toHaveAttribute("aria-pressed", "true");
  100 |   await expect(dialog.locator(".shared-directory-results")).not.toHaveAttribute("aria-live", /.+/);
  101 |   await expect(dialog.getByRole("status")).toHaveAttribute("aria-atomic", "true");
  102 | });
  103 | 
  104 | test("actual locale/theme controls preserve a filtered directory across reopen", async ({ page }, info) => {
  105 |   await open(page); let dialog = directory(page);
  106 |   await dialog.getByRole("searchbox").fill("options");
  107 |   await dialog.getByRole("button", { name: "Workspaces", exact: true }).click();
  108 |   const identities = await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")));
  109 |   await page.keyboard.press("Escape");
  110 |   await page.getByRole("button", { name: "Light theme", exact: true }).click();
  111 |   await page.getByRole("button", { name: "Chinese language", exact: true }).click();
  112 |   await expect(page.locator("html")).toHaveAttribute("data-lang", "zh");
  113 |   await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
  114 |   // Keyboard invocation uses the existing shell listener after the old modal closed.
  115 |   await page.locator("main").first().click({ position: { x: 5, y: 5 } });
  116 |   await page.keyboard.press("ControlOrMeta+k"); dialog = directory(page);
  117 |   await expect(dialog).toBeVisible(); await expect(dialog.getByRole("searchbox")).toHaveValue("options");
  118 |   await expect(dialog.getByRole("button", { name: "工作区", exact: true })).toHaveAttribute("aria-pressed", "true");
  119 |   expect(await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")))).toEqual(identities);
  120 |   await expect(dialog.getByRole("button", { name: "查看全部 12 个匹配结果", exact: true })).toBeVisible();
  121 |   await contained(page);
  122 |   await page.screenshot({ animations: "disabled", path: info.outputPath("category-recovery-light-zh.png") });
  123 |   await page.setViewportSize({ width: 320, height: 420 });
  124 |   await contained(page); await expect(dialog.getByRole("button", { name: "关闭", exact: true })).toBeVisible();
  125 |   await expect(dialog.getByRole("searchbox")).toBeVisible();
  126 |   await page.screenshot({ animations: "disabled", path: info.outputPath("short-320-light-zh.png") });
  127 | });
  128 | 
  129 | test("drawer-to-directory and resize close return to a visible persistent control", async ({ page }, info) => {
  130 |   await open(page); await directory(page).getByRole("searchbox").fill("options");
  131 |   if (info.project.name === "desktop") await page.setViewportSize({ width: 320, height: 844 });
  132 |   await page.keyboard.press("Escape");
  133 |   await expect(page.getByRole("dialog")).toHaveCount(0);
  134 |   await expect(page.getByRole("button", { name: "Open navigation", exact: true })).toBeFocused();
  135 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  136 |   await page.screenshot({ animations: "disabled", path: info.outputPath("visible-focus-return.png") });
  137 | });
  138 | 
  139 | test("shortcut from BODY returns to a meaningful visible shell control", async ({ page }, info) => {
  140 |   // Establish the mounted shell through its actual UI before testing its global
  141 |   // listener; an SSR heading alone does not prove that listener is installed.
  142 |   await open(page); await page.keyboard.press("Escape");
  143 |   await expect(directory(page)).toHaveCount(0);
  144 |   await page.evaluate(() => { if (document.activeElement instanceof HTMLElement) document.activeElement.blur(); });
  145 |   expect(await page.evaluate(() => document.activeElement === document.body)).toBe(true);
  146 |   const before = await page.evaluate(() => ({ tabIndex: document.body.getAttribute("tabindex"), x: scrollX, y: scrollY }));
  147 |   await page.keyboard.press("ControlOrMeta+k");
  148 |   await expect(directory(page)).toBeVisible();
  149 |   await expect(directory(page).getByRole("searchbox")).toBeFocused();
  150 |   await page.keyboard.press("Escape");
  151 |   await expect(directory(page)).toHaveCount(0);
  152 |   const returnTarget = page.viewportSize()!.width <= 860
  153 |     ? page.getByRole("button", { name: "Open navigation", exact: true })
  154 |     : page.locator(".topbar .shared-shell-directory-trigger");
> 155 |   await expect(returnTarget).toBeFocused(); await expect(returnTarget).toBeVisible();
      |                              ^ Error: expect(locator).toBeFocused() failed
  156 |   expect(await page.evaluate(() => ({ tabIndex: document.body.getAttribute("tabindex"), x: scrollX, y: scrollY }))).toEqual(before);
  157 |   await page.screenshot({ animations: "disabled", path: info.outputPath("shortcut-meaningful-return.png") });
  158 | });
  159 | 
  160 | test("Show all reveals its focused category inside the scrolled strip", async ({ page }, info) => {
  161 |   await page.setViewportSize({ width: info.project.name === "mobile" ? 390 : 320, height: 844 });
  162 |   await open(page);
  163 |   const dialog = directory(page);
  164 |   const search = dialog.getByRole("searchbox");
  165 |   await search.fill("options");
  166 |   const before = await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")));
  167 |   await dialog.getByRole("button", { name: "About", exact: true }).click();
  168 |   const strip = dialog.locator(".shared-directory-filters");
  169 |   await strip.evaluate(element => { element.scrollLeft = element.scrollWidth; });
  170 |   const all = dialog.getByRole("button", { name: "All", exact: true });
  171 |   const geometry = () => all.evaluate(element => {
  172 |     const strip = element.closest(".shared-directory-filters")!;
  173 |     const outer = strip.getBoundingClientRect(); const target = element.getBoundingClientRect();
  174 |     return { scrollLeft: strip.scrollLeft, left: target.left, right: target.right,
  175 |       clipLeft: outer.left + strip.clientLeft, clipRight: outer.left + strip.clientLeft + strip.clientWidth };
  176 |   });
  177 |   const clipped = await geometry();
  178 |   expect(clipped.scrollLeft).toBeGreaterThan(0);
  179 |   expect(clipped.left < clipped.clipLeft - 1 || clipped.right > clipped.clipRight + 1).toBe(true);
  180 |   const scrollBefore = await page.evaluate(() => ({ x: scrollX, y: scrollY,
  181 |     main: [...document.querySelectorAll("main, .main2")].map(node => ({ x: node.scrollLeft, y: node.scrollTop })) }));
  182 |   await dialog.getByRole("button", { name: `Show all ${before.length} matches`, exact: true }).focus();
  183 |   await page.keyboard.press("Enter");
  184 |   await expect(all).toBeFocused(); await expect(all).toHaveAttribute("aria-pressed", "true");
  185 |   const revealed = await geometry();
  186 |   expect(revealed.left).toBeGreaterThanOrEqual(revealed.clipLeft - 1);
  187 |   expect(revealed.right).toBeLessThanOrEqual(revealed.clipRight + 1);
  188 |   expect(await page.evaluate(() => ({ x: scrollX, y: scrollY,
  189 |     main: [...document.querySelectorAll("main, .main2")].map(node => ({ x: node.scrollLeft, y: node.scrollTop })) }))).toEqual(scrollBefore);
  190 |   await expect(search).toHaveValue("options");
  191 |   expect(await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")))).toEqual(before);
  192 |   await page.screenshot({ animations: "disabled", path: info.outputPath("revealed-category-focus.png") });
  193 | });
  194 | 
  195 | test("directory transfers once to the real company picker and respects composing Escape", async ({ page }) => {
  196 |   await open(page); const input = directory(page).getByRole("searchbox");
  197 |   await input.dispatchEvent("compositionstart", { data: "期" });
  198 |   await input.dispatchEvent("keydown", { key: "Escape", isComposing: true, bubbles: true, cancelable: true });
  199 |   await expect(directory(page)).toBeVisible();
  200 |   await input.dispatchEvent("compositionend", { data: "期权" });
  201 |   await directory(page).locator(".shared-directory-footer button").click();
  202 |   await expect(directory(page)).toHaveCount(0); await expect(page.getByRole("dialog")).toHaveCount(1);
  203 |   await expect(page.getByRole("dialog")).toHaveAccessibleName("Search companies");
  204 |   await expect(page.getByRole("dialog").getByRole("combobox")).toBeFocused();
  205 |   await page.keyboard.press("Escape"); await expect(page.getByRole("dialog")).toHaveCount(0);
  206 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  207 | });
  208 | 
  209 | test("native dialog cancellation respects the captured Escape owner", async ({ page }) => {
  210 |   await open(page); const input = directory(page).getByRole("searchbox");
  211 |   // Native Escape after composition ends in a child listener must still belong
  212 |   // to that composition. This exercises native dialog cancellation in Chromium;
  213 |   // it does not establish an operating-system IME or assistive-technology pass.
  214 |   await input.dispatchEvent("compositionstart", { data: "期" });
  215 |   await input.evaluate(element => element.addEventListener("keydown", () => {
  216 |     element.dispatchEvent(new CompositionEvent("compositionend", { bubbles: true, data: "期权" }));
  217 |   }, { once: true }));
  218 |   await page.keyboard.press("Escape");
  219 |   await expect(directory(page)).toBeVisible(); await expect(input).toBeFocused();
  220 |   const guarded = await input.evaluate(element => {
  221 |     const modal = element.closest("dialog")!;
  222 |     for (const signal of [{ isComposing: true }, { keyCode: 229 }, { repeat: true }]) {
  223 |       element.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true, cancelable: true, ...signal }));
  224 |       modal.requestClose();
  225 |       if (!modal.open) return false;
  226 |     }
  227 |     // Consumed protection cannot block a second independent request, even
  228 |     // before a keyup or the expiry task has run.
  229 |     modal.requestClose();
  230 |     return true;
  231 |   });
  232 |   expect(guarded).toBe(true);
  233 |   await expect(directory(page)).toHaveCount(0);
  234 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  235 | });
  236 | 
  237 | test("real Next Link keeps the current directory on modified activation", async ({ page, context }, info) => {
  238 |   test.skip(info.project.name !== "desktop", "Single real new-tab browser case");
  239 |   await open(page); await directory(page).getByRole("searchbox").fill("options");
  240 |   const link = directory(page).locator('a[href="/options"]');
  241 |   const popupPromise = context.waitForEvent("page");
  242 |   await link.click({ modifiers: ["ControlOrMeta"] });
  243 |   const popup = await popupPromise; await popup.waitForURL(/\/options$/); await popup.close();
  244 |   await expect(directory(page)).toBeVisible();
  245 |   await expect(directory(page).getByRole("searchbox")).toHaveValue("options");
  246 |   await link.click(); await expect(page).toHaveURL(/\/options$/); await expect(directory(page)).toHaveCount(0);
  247 | });
  248 | 
```