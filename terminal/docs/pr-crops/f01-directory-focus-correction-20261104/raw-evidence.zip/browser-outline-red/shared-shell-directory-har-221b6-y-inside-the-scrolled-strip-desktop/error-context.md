# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: shared-shell-directory-hardening.spec.ts >> Show all reveals its focused category inside the scrolled strip
- Location: e2e/shared-shell-directory-hardening.spec.ts:160:5

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 205.96875
Received:    201.96875
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - link "Skip to content" [ref=e3] [cursor=pointer]:
      - /url: "#shared-shell-content"
    - generic [ref=e4]:
      - button "Open navigation" [ref=e5] [cursor=pointer]:
        - img [ref=e6]
      - generic:
        - img
        - generic: MASTERMIND
      - generic [ref=e8]:
        - button "Search companies" [ref=e9] [cursor=pointer]:
          - img [ref=e10]
        - group "Appearance and language" [ref=e13]:
          - button "Light theme" [ref=e14] [cursor=pointer]:
            - img [ref=e15]
          - button "Chinese language" [ref=e17] [cursor=pointer]:
            - generic [ref=e18]: EN
        - button "Settings" [ref=e20] [cursor=pointer]: U
    - dialog "All tools" [ref=e21]:
      - generic [ref=e22]:
        - banner [ref=e23]:
          - generic [ref=e24]:
            - text: Your workspace
            - heading "All tools" [level=2] [ref=e25]
            - paragraph [ref=e26]: Explore your workspaces, markets, research, and tools.
          - button "Close" [ref=e27] [cursor=pointer]: ×
        - generic [ref=e28]:
          - img [ref=e29]
          - searchbox "Find a page or tool…" [ref=e32]: options
          - button "Clear search" [ref=e33] [cursor=pointer]: ×
          - generic [ref=e34]: esc
        - group "Page categories" [ref=e35]:
          - button "All" [active] [pressed] [ref=e36] [cursor=pointer]
          - button "Workspaces" [ref=e37] [cursor=pointer]
          - button "Markets" [ref=e38] [cursor=pointer]
          - button "Research" [ref=e39] [cursor=pointer]
          - button "Learn" [ref=e40] [cursor=pointer]
          - button "Tools" [ref=e41] [cursor=pointer]
          - button "About" [ref=e42] [cursor=pointer]
        - generic [ref=e44]:
          - link "Futures Workspaces" [ref=e45] [cursor=pointer]:
            - /url: /options/futures
            - generic [ref=e46]:
              - strong [ref=e47]: Futures
              - generic [ref=e48]: Workspaces
          - link "Options Workspaces" [ref=e49] [cursor=pointer]:
            - /url: /options
            - generic [ref=e50]:
              - strong [ref=e51]: Options
              - generic [ref=e52]: Workspaces
          - link "Options & Market Structure Markets" [ref=e53] [cursor=pointer]:
            - /url: /options.html
            - generic [ref=e54]:
              - strong [ref=e55]: Options & Market Structure
              - generic [ref=e56]: Markets
          - link "Options Screener Markets" [ref=e57] [cursor=pointer]:
            - /url: /options_screener.html
            - generic [ref=e58]:
              - strong [ref=e59]: Options Screener
              - generic [ref=e60]: Markets
          - link "learn / options / charm and time drift Learn" [ref=e61] [cursor=pointer]:
            - /url: /learn/options/charm-and-time-drift.html
            - generic [ref=e62]:
              - strong [ref=e63]: learn / options / charm and time drift
              - generic [ref=e64]: Learn
          - link "learn / options / dealer hedging mechanics Learn" [ref=e65] [cursor=pointer]:
            - /url: /learn/options/dealer-hedging-mechanics.html
            - generic [ref=e66]:
              - strong [ref=e67]: learn / options / dealer hedging mechanics
              - generic [ref=e68]: Learn
          - link "learn / options / gamma flip levels Learn" [ref=e69] [cursor=pointer]:
            - /url: /learn/options/gamma-flip-levels.html
            - generic [ref=e70]:
              - strong [ref=e71]: learn / options / gamma flip levels
              - generic [ref=e72]: Learn
          - link "learn / options / gamma regimes Learn" [ref=e73] [cursor=pointer]:
            - /url: /learn/options/gamma-regimes.html
            - generic [ref=e74]:
              - strong [ref=e75]: learn / options / gamma regimes
              - generic [ref=e76]: Learn
          - link "learn / options / market makers middleman Learn" [ref=e77] [cursor=pointer]:
            - /url: /learn/options/market-makers-middleman.html
            - generic [ref=e78]:
              - strong [ref=e79]: learn / options / market makers middleman
              - generic [ref=e80]: Learn
          - link "learn / options / open interest limits Learn" [ref=e81] [cursor=pointer]:
            - /url: /learn/options/open-interest-limits.html
            - generic [ref=e82]:
              - strong [ref=e83]: learn / options / open interest limits
              - generic [ref=e84]: Learn
          - link "learn / options / zero dte regime Learn" [ref=e85] [cursor=pointer]:
            - /url: /learn/options/zero-dte-regime.html
            - generic [ref=e86]:
              - strong [ref=e87]: learn / options / zero dte regime
              - generic [ref=e88]: Learn
          - link "tools / calculators / options profit Tools" [ref=e89] [cursor=pointer]:
            - /url: /tools/calculators/options-profit.html
            - generic [ref=e90]:
              - strong [ref=e91]: tools / calculators / options profit
              - generic [ref=e92]: Tools
        - contentinfo [ref=e93]:
          - status [ref=e94]: 12 matches
          - button "Search companies" [ref=e95] [cursor=pointer]: Search companies ↗
    - status [ref=e96]
    - main [ref=e98]:
      - generic [ref=e99]:
        - generic [ref=e100]:
          - heading "Discover" [level=1] [ref=e101]
          - paragraph [ref=e102]: Choose a question. Open the right workspace.
        - button "Search companies" [ref=e103] [cursor=pointer]
      - generic [ref=e104]:
        - article [ref=e105]:
          - paragraph [ref=e106]: Screen companies
          - heading "Start with a universe. Narrow it with evidence." [level=2] [ref=e107]
          - paragraph [ref=e108]: Use technical, fundamental and classification filters. Check each field's coverage before comparing results.
          - button "Open Stock Screener" [ref=e110] [cursor=pointer]
        - article [ref=e111]:
          - paragraph [ref=e112]: Explore market structure
          - heading "See participation in context" [level=2] [ref=e113]
          - paragraph [ref=e114]: Move from the market map to the sectors and companies behind it.
          - generic [ref=e115]:
            - button "Open Heatmap" [ref=e116] [cursor=pointer]
            - button "Open Sectors" [ref=e117] [cursor=pointer]
        - article [ref=e118]:
          - heading "Follow market leadership" [level=2] [ref=e119]
          - paragraph [ref=e120]: Inspect the existing leader views and their underlying coverage.
          - generic [ref=e121]:
            - button "Leaders" [ref=e122] [cursor=pointer]
            - button "Leader Radar" [ref=e123] [cursor=pointer]
        - article [ref=e124]:
          - heading "RS · 30m Pivot" [level=2] [ref=e125]
          - paragraph [ref=e126]: Explore the study's conditions, timing and limitations.
          - button "Open study" [ref=e128] [cursor=pointer]
      - generic [ref=e129]:
        - heading "Go deeper with a focused workflow" [level=2] [ref=e130]
        - generic [ref=e131]:
          - generic [ref=e132]:
            - link "US stocks · Prophet" [ref=e133] [cursor=pointer]:
              - /url: /us_stocks.html
            - paragraph [ref=e134]: Open the US stock dashboard for Prophet, sectors and flows.
          - generic [ref=e135]:
            - link "Catalysts" [ref=e136] [cursor=pointer]:
              - /url: /biocatalyst.html
            - paragraph [ref=e137]: Company catalysts anchored in original disclosures.
          - generic [ref=e138]:
            - link "Confluence" [ref=e139] [cursor=pointer]:
              - /url: /confluence_screener.html
            - paragraph [ref=e140]: Adds evidence confluence on top of the existing screen.
  - alert [ref=e141]
```

# Test source

```ts
  93  |   await dialog.getByRole("searchbox").fill("no-such-directory-destination-20261104");
  94  |   await expect(dialog.getByRole("heading", { name: "No pages found", exact: true })).toBeVisible();
  95  |   await dialog.getByRole("button", { name: "Tools", exact: true }).click();
  96  |   await dialog.getByRole("button", { name: "Clear search", exact: true }).click();
  97  |   await expect(dialog.getByRole("searchbox")).toHaveValue("");
  98  |   await expect(dialog.getByRole("searchbox")).toBeFocused();
  99  |   await expect(dialog.getByRole("button", { name: "Tools", exact: true })).toHaveAttribute("aria-pressed", "true");
  100 |   await expect(dialog.locator(".shared-directory-results")).not.toHaveAttribute("aria-live", /.+/);
  101 |   await expect(dialog.getByRole("status")).toHaveAttribute("aria-atomic", "true");
  102 | });
  103 | 
  104 | test("actual locale/theme controls preserve a filtered directory across reopen", async ({ page }, info) => {
  105 |   await open(page); let dialog = directory(page);
  106 |   await dialog.getByRole("searchbox").fill("options");
  107 |   await dialog.getByRole("button", { name: "Workspaces", exact: true }).click();
  108 |   const identities = await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")));
  109 |   await page.keyboard.press("Escape");
  110 |   await page.getByRole("button", { name: "Light theme", exact: true }).click();
  111 |   await page.getByRole("button", { name: "Chinese language", exact: true }).click();
  112 |   await expect(page.locator("html")).toHaveAttribute("data-lang", "zh");
  113 |   await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
  114 |   // Keyboard invocation uses the existing shell listener after the old modal closed.
  115 |   await page.locator("main").first().click({ position: { x: 5, y: 5 } });
  116 |   await page.keyboard.press("ControlOrMeta+k"); dialog = directory(page);
  117 |   await expect(dialog).toBeVisible(); await expect(dialog.getByRole("searchbox")).toHaveValue("options");
  118 |   await expect(dialog.getByRole("button", { name: "工作区", exact: true })).toHaveAttribute("aria-pressed", "true");
  119 |   expect(await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")))).toEqual(identities);
  120 |   await expect(dialog.getByRole("button", { name: "查看全部 12 个匹配结果", exact: true })).toBeVisible();
  121 |   await contained(page);
  122 |   await page.screenshot({ animations: "disabled", path: info.outputPath("category-recovery-light-zh.png") });
  123 |   await page.setViewportSize({ width: 320, height: 420 });
  124 |   await contained(page); await expect(dialog.getByRole("button", { name: "关闭", exact: true })).toBeVisible();
  125 |   await expect(dialog.getByRole("searchbox")).toBeVisible();
  126 |   await page.screenshot({ animations: "disabled", path: info.outputPath("short-320-light-zh.png") });
  127 | });
  128 | 
  129 | test("drawer-to-directory and resize close return to a visible persistent control", async ({ page }, info) => {
  130 |   await open(page); await directory(page).getByRole("searchbox").fill("options");
  131 |   if (info.project.name === "desktop") await page.setViewportSize({ width: 320, height: 844 });
  132 |   await page.keyboard.press("Escape");
  133 |   await expect(page.getByRole("dialog")).toHaveCount(0);
  134 |   await expect(page.getByRole("button", { name: "Open navigation", exact: true })).toBeFocused();
  135 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  136 |   await page.screenshot({ animations: "disabled", path: info.outputPath("visible-focus-return.png") });
  137 | });
  138 | 
  139 | test("shortcut from BODY returns to a meaningful visible shell control", async ({ page }, info) => {
  140 |   // Establish the mounted shell through its actual UI before testing its global
  141 |   // listener; an SSR heading alone does not prove that listener is installed.
  142 |   await open(page); await page.keyboard.press("Escape");
  143 |   await expect(directory(page)).toHaveCount(0);
  144 |   await page.evaluate(() => { if (document.activeElement instanceof HTMLElement) document.activeElement.blur(); });
  145 |   expect(await page.evaluate(() => document.activeElement === document.body)).toBe(true);
  146 |   const before = await page.evaluate(() => ({ tabIndex: document.body.getAttribute("tabindex"), x: scrollX, y: scrollY }));
  147 |   await page.keyboard.press("ControlOrMeta+k");
  148 |   await expect(directory(page)).toBeVisible();
  149 |   await expect(directory(page).getByRole("searchbox")).toBeFocused();
  150 |   await page.keyboard.press("Escape");
  151 |   await expect(directory(page)).toHaveCount(0);
  152 |   const returnTarget = page.viewportSize()!.width <= 860
  153 |     ? page.getByRole("button", { name: "Open navigation", exact: true })
  154 |     : page.locator(".topbar .shared-shell-directory-trigger");
  155 |   await expect(returnTarget).toBeFocused(); await expect(returnTarget).toBeVisible();
  156 |   expect(await page.evaluate(() => ({ tabIndex: document.body.getAttribute("tabindex"), x: scrollX, y: scrollY }))).toEqual(before);
  157 |   await page.screenshot({ animations: "disabled", path: info.outputPath("shortcut-meaningful-return.png") });
  158 | });
  159 | 
  160 | test("Show all reveals its focused category inside the scrolled strip", async ({ page }, info) => {
  161 |   await page.setViewportSize({ width: info.project.name === "mobile" ? 390 : 320, height: 844 });
  162 |   await open(page);
  163 |   const dialog = directory(page);
  164 |   const search = dialog.getByRole("searchbox");
  165 |   await search.fill("options");
  166 |   const before = await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")));
  167 |   await dialog.getByRole("button", { name: "About", exact: true }).click();
  168 |   const strip = dialog.locator(".shared-directory-filters");
  169 |   await strip.evaluate(element => { element.scrollLeft = element.scrollWidth; });
  170 |   const all = dialog.getByRole("button", { name: "All", exact: true });
  171 |   const geometry = () => all.evaluate(element => {
  172 |     const strip = element.closest(".shared-directory-filters")!;
  173 |     const outer = strip.getBoundingClientRect(); const target = element.getBoundingClientRect();
  174 |     const style = getComputedStyle(element);
  175 |     return { scrollLeft: strip.scrollLeft, left: target.left, right: target.right,
  176 |       top: target.top, bottom: target.bottom,
  177 |       focusOutset: Math.max(0, parseFloat(style.outlineWidth) + parseFloat(style.outlineOffset)),
  178 |       clipLeft: outer.left + strip.clientLeft, clipRight: outer.left + strip.clientLeft + strip.clientWidth,
  179 |       clipTop: outer.top + strip.clientTop, clipBottom: outer.top + strip.clientTop + strip.clientHeight };
  180 |   });
  181 |   const clipped = await geometry();
  182 |   expect(clipped.scrollLeft).toBeGreaterThan(0);
  183 |   expect(clipped.left < clipped.clipLeft - 1 || clipped.right > clipped.clipRight + 1).toBe(true);
  184 |   const scrollBefore = await page.evaluate(() => ({ x: scrollX, y: scrollY,
  185 |     main: [...document.querySelectorAll("main, .main2")].map(node => ({ x: node.scrollLeft, y: node.scrollTop })) }));
  186 |   await dialog.getByRole("button", { name: `Show all ${before.length} matches`, exact: true }).focus();
  187 |   await page.keyboard.press("Enter");
  188 |   await expect(all).toBeFocused(); await expect(all).toHaveAttribute("aria-pressed", "true");
  189 |   const revealed = await geometry();
  190 |   expect(revealed.focusOutset).toBeGreaterThan(0);
  191 |   expect(revealed.left - revealed.focusOutset).toBeGreaterThanOrEqual(revealed.clipLeft - 1);
  192 |   expect(revealed.right + revealed.focusOutset).toBeLessThanOrEqual(revealed.clipRight + 1);
> 193 |   expect(revealed.top - revealed.focusOutset).toBeGreaterThanOrEqual(revealed.clipTop - 1);
      |                                               ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  194 |   expect(revealed.bottom + revealed.focusOutset).toBeLessThanOrEqual(revealed.clipBottom + 1);
  195 |   expect(await page.evaluate(() => ({ x: scrollX, y: scrollY,
  196 |     main: [...document.querySelectorAll("main, .main2")].map(node => ({ x: node.scrollLeft, y: node.scrollTop })) }))).toEqual(scrollBefore);
  197 |   await expect(search).toHaveValue("options");
  198 |   expect(await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")))).toEqual(before);
  199 |   await page.screenshot({ animations: "disabled", path: info.outputPath("revealed-category-focus.png") });
  200 | });
  201 | 
  202 | test("directory transfers once to the real company picker and respects composing Escape", async ({ page }) => {
  203 |   await open(page); const input = directory(page).getByRole("searchbox");
  204 |   await input.dispatchEvent("compositionstart", { data: "期" });
  205 |   await input.dispatchEvent("keydown", { key: "Escape", isComposing: true, bubbles: true, cancelable: true });
  206 |   await expect(directory(page)).toBeVisible();
  207 |   await input.dispatchEvent("compositionend", { data: "期权" });
  208 |   await directory(page).locator(".shared-directory-footer button").click();
  209 |   await expect(directory(page)).toHaveCount(0); await expect(page.getByRole("dialog")).toHaveCount(1);
  210 |   await expect(page.getByRole("dialog")).toHaveAccessibleName("Search companies");
  211 |   await expect(page.getByRole("dialog").getByRole("combobox")).toBeFocused();
  212 |   await page.keyboard.press("Escape"); await expect(page.getByRole("dialog")).toHaveCount(0);
  213 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  214 | });
  215 | 
  216 | test("native dialog cancellation respects the captured Escape owner", async ({ page }) => {
  217 |   await open(page); const input = directory(page).getByRole("searchbox");
  218 |   // Native Escape after composition ends in a child listener must still belong
  219 |   // to that composition. This exercises native dialog cancellation in Chromium;
  220 |   // it does not establish an operating-system IME or assistive-technology pass.
  221 |   await input.dispatchEvent("compositionstart", { data: "期" });
  222 |   await input.evaluate(element => element.addEventListener("keydown", () => {
  223 |     element.dispatchEvent(new CompositionEvent("compositionend", { bubbles: true, data: "期权" }));
  224 |   }, { once: true }));
  225 |   await page.keyboard.press("Escape");
  226 |   await expect(directory(page)).toBeVisible(); await expect(input).toBeFocused();
  227 |   const guarded = await input.evaluate(element => {
  228 |     const modal = element.closest("dialog")!;
  229 |     for (const signal of [{ isComposing: true }, { keyCode: 229 }, { repeat: true }]) {
  230 |       element.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true, cancelable: true, ...signal }));
  231 |       modal.requestClose();
  232 |       if (!modal.open) return false;
  233 |     }
  234 |     // Consumed protection cannot block a second independent request, even
  235 |     // before a keyup or the expiry task has run.
  236 |     modal.requestClose();
  237 |     return true;
  238 |   });
  239 |   expect(guarded).toBe(true);
  240 |   await expect(directory(page)).toHaveCount(0);
  241 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  242 | });
  243 | 
  244 | test("real Next Link keeps the current directory on modified activation", async ({ page, context }, info) => {
  245 |   test.skip(info.project.name !== "desktop", "Single real new-tab browser case");
  246 |   await open(page); await directory(page).getByRole("searchbox").fill("options");
  247 |   const link = directory(page).locator('a[href="/options"]');
  248 |   const popupPromise = context.waitForEvent("page");
  249 |   await link.click({ modifiers: ["ControlOrMeta"] });
  250 |   const popup = await popupPromise; await popup.waitForURL(/\/options$/); await popup.close();
  251 |   await expect(directory(page)).toBeVisible();
  252 |   await expect(directory(page).getByRole("searchbox")).toHaveValue("options");
  253 |   await link.click(); await expect(page).toHaveURL(/\/options$/); await expect(directory(page)).toHaveCount(0);
  254 | });
  255 | 
```