# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: sector-cycle-lens.spec.ts >> cycles tick precision survives fullscreen fractional zh light
- Location: e2e/sector-cycle-lens.spec.ts:110:9

# Error details

```
Error: SVG coordinates must follow the current measured content width

SVG coordinates must follow the current measured content width

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 1
Received:    70

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]:
      - strong [ref=e4]: DEV harness · SectorCycleLens
      - generic [ref=e5]: Fixture data — not live evidence
      - generic [ref=e6]:
        - radio "EN" [ref=e7]
        - text: EN
      - generic [ref=e8]:
        - radio "ZH" [checked] [ref=e9]
        - text: ZH
      - generic [ref=e10]:
        - radio "Dark" [ref=e11]
        - text: Dark
      - generic [ref=e12]:
        - radio "Light" [checked] [ref=e13]
        - text: Light
      - generic [ref=e14]:
        - text: Axis fixture
        - combobox "Axis fixture" [ref=e15]:
          - option "Standard history"
          - option "Tiny values (0 to 0.01)"
          - option "Fractional ticks (-4 to 4)" [selected]
      - generic [ref=e16]:
        - radio "Generation current" [checked] [ref=e17]
        - text: Generation current
      - generic [ref=e18]:
        - radio "Generation replaced" [ref=e19]
        - text: Generation replaced
      - generic [ref=e20]:
        - radio "Heads today" [checked] [ref=e21]
        - text: Heads today
      - generic [ref=e22]:
        - radio "One head withdrawn" [ref=e23]
        - text: One head withdrawn
      - generic [ref=e24]:
        - radio "Heads absent" [ref=e25]
        - text: Heads absent
    - generic [ref=e26]:
      - generic [ref=e28]:
        - heading "板块周期" [level=2] [ref=e29]
        - paragraph [ref=e30]: 科技 XLK · 截至 2026-10-30 · 板块 ETF 对比 SPY · 重构价格历史
      - generic [ref=e31]:
        - complementary "各板块周期阶段" [ref=e32]:
          - heading "各板块周期阶段" [level=3] [ref=e33]
          - paragraph [ref=e34]: 5/5 个有观测 · 板块 ETF 对比 SPY
          - tablist "各板块周期阶段" [ref=e35]:
            - tab "板块 ETF 对比 SPY" [selected] [ref=e36] [cursor=pointer]
            - tab "主题组合对比 SPY" [ref=e37] [cursor=pointer]
          - generic [ref=e38]:
            - generic [ref=e39]: 筛选序列
            - searchbox "筛选序列" [ref=e40]
          - generic [ref=e41]:
            - heading "筑底中 1" [level=4] [ref=e42]:
              - text: 筑底中
              - generic [ref=e43]: "1"
            - button "能源 XLE" [ref=e44] [cursor=pointer]:
              - generic [ref=e45]: 能源
              - generic [ref=e46]: XLE
          - generic [ref=e47]:
            - heading "入场良机 1" [level=4] [ref=e48]:
              - text: 入场良机
              - generic [ref=e49]: "1"
            - button "金融 XLF" [ref=e50] [cursor=pointer]:
              - generic [ref=e51]: 金融
              - generic [ref=e52]: XLF
          - generic [ref=e53]:
            - heading "上行中 1" [level=4] [ref=e54]:
              - text: 上行中
              - generic [ref=e55]: "1"
            - button "科技 XLK" [pressed] [ref=e56] [cursor=pointer]:
              - generic [ref=e57]: 科技
              - generic [ref=e58]: XLK
          - generic [ref=e59]:
            - heading "见顶 · 晚期 1" [level=4] [ref=e60]:
              - text: 见顶 · 晚期
              - generic [ref=e61]: "1"
            - button "医疗保健 XLV" [ref=e62] [cursor=pointer]:
              - generic [ref=e63]: 医疗保健
              - generic [ref=e64]: XLV
          - generic [ref=e65]:
            - heading "回落中 1" [level=4] [ref=e66]:
              - text: 回落中
              - generic [ref=e67]: "1"
            - button "可选消费 XLY" [ref=e68] [cursor=pointer]:
              - generic [ref=e69]: 可选消费
              - generic [ref=e70]: XLY
          - group [ref=e71]:
            - generic "计算方法" [ref=e72] [cursor=pointer]
        - generic [ref=e73]:
          - generic [ref=e74]:
            - generic [ref=e75]:
              - heading "科技 XLK" [level=3] [ref=e76]
              - generic [ref=e77]:
                - generic [ref=e78]: "周期阶段 · 本体框架: 扩张"
                - generic [ref=e79]: 位置 · 本体框架 72
                - generic [ref=e80]:
                  - text: 价格与200日均线
                  - generic [ref=e81]: 高于
              - paragraph [ref=e82]: 0–100刻度，并非概率。
            - button "查看板块档案" [ref=e84] [cursor=pointer]
          - generic [ref=e85]:
            - heading "时钟" [level=4] [ref=e86]
            - generic [ref=e87]:
              - generic [ref=e88]: 阶段时钟
              - generic [ref=e89]: 时序阶梯
              - generic [ref=e90]: 风险时钟
              - generic "各分歧时钟自身的数值保留于来源抽屉。" [ref=e91]: 节律时钟 ⚠
              - generic [ref=e92]: 周期读数
            - paragraph [ref=e93]: 各分歧时钟自身的数值保留于来源抽屉。
          - generic [ref=e94]:
            - heading "相对 SPY 强弱" [level=3] [ref=e96]
            - generic [ref=e97]:
              - button "序列（5）" [ref=e98] [cursor=pointer]: 序列（5）＋
              - generic [ref=e99]:
                - text: 图表范围
                - combobox "图表范围" [ref=e100]:
                  - option "21个交易日"
                  - option "63个交易日"
                  - option "252个交易日"
                  - option "全部" [selected]
              - generic [ref=e101]:
                - text: 刻度
                - combobox "刻度" [ref=e102]:
                  - option "线性" [selected]
                  - option "对数" [disabled]
              - group "相对 SPY 强弱" [ref=e103]:
                - button "图表" [pressed] [ref=e104] [cursor=pointer]
                - button "数据表" [ref=e105] [cursor=pointer]
              - button "全屏" [ref=e106] [cursor=pointer]: 全屏⤢
            - generic [ref=e107]:
              - generic [ref=e108]:
                - text: XLK · 21个交易日
                - generic [ref=e110]: 总回报
              - generic [ref=e111]:
                - text: XLK · 63个交易日
                - generic [ref=e113]: 总回报
            - generic [ref=e114]:
              - generic [ref=e115]:
                - generic [ref=e116]:
                  - text: XLK · 21个交易日
                  - strong [ref=e117]: "-3.3%"
                - generic [ref=e118]:
                  - text: XLK · 63个交易日
                  - strong [ref=e119]: "-3.3%"
                - time [ref=e120]: 2026-05-02
              - img "相对 SPY 强弱" [ref=e122]:
                - generic [ref=e124]: "-2.5"
                - generic [ref=e126]: "0.0"
                - generic [ref=e128]: "2.5"
                - generic "2025-09-13 · trough" [ref=e131]
                - generic "2025-11-12 · peak" [ref=e133]
                - generic "2026-01-21 · trough" [ref=e135]
                - generic "2026-03-12 · peak · 暂定" [ref=e137]
                - generic [ref=e139]: 底部 2025-09-13
                - generic [ref=e140]: 顶部 2026-03-12
                - generic [ref=e143]: 2025-08-24
                - generic [ref=e144]: 2025-10-25
                - generic [ref=e145]: 2025-12-26
                - generic [ref=e146]: 2026-02-26
                - generic [ref=e147]: 2026-05-02
              - slider "观测日期" [ref=e148]: "251"
              - generic [ref=e149]:
                - generic [ref=e150]: 2025-08-24
                - generic [ref=e151]: 2026-05-02
            - generic [ref=e152]:
              - heading "价格转折" [level=4] [ref=e153]
              - paragraph [ref=e154]: 转折日期为拐点日期。拐点仅在确认后才可知 — 两种日期严格区分。
              - generic [ref=e155]:
                - time [ref=e156]: 2026-03-12
                - generic [ref=e157]: 高点
                - emphasis [ref=e158]: 暂定
              - generic [ref=e159]:
                - time [ref=e160]: 2026-01-21
                - generic [ref=e161]: 低点
                - emphasis [ref=e162]: 已确认
                - emphasis [ref=e163]: · 最早可知 2026-01-24
              - generic [ref=e164]:
                - time [ref=e165]: 2025-11-12
                - generic [ref=e166]: 高点
                - emphasis [ref=e167]: 已确认
                - emphasis [ref=e168]: · 最早可知 2025-11-15
            - group [ref=e169]:
              - generic "精确数值" [ref=e170] [cursor=pointer]
            - group [ref=e171]:
              - generic "计算方法" [ref=e172]
          - generic [ref=e173]:
            - heading "周期段 timeline" [level=3] [ref=e174]
            - list [ref=e176]:
              - listitem [ref=e177]:
                - button "2025-09-13 → 2025-11-12" [ref=e178] [cursor=pointer]:
                  - generic [ref=e179]: 2025-09-13 → 2025-11-12
                  - generic [ref=e180]: ▲
              - listitem [ref=e181]:
                - button "2025-11-12 → 2026-01-21" [ref=e182] [cursor=pointer]:
                  - generic [ref=e183]: 2025-11-12 → 2026-01-21
                  - generic [ref=e184]: ▼
              - listitem [ref=e185]:
                - button "2026-01-21 → 2026-03-12 · 暂定" [ref=e186] [cursor=pointer]:
                  - generic [ref=e187]: 2026-01-21 → 2026-03-12 · 暂定
                  - generic [ref=e188]: ▲
              - listitem [ref=e189]:
                - button "2026-03-12 · 开放段 · 开放 · 51 个交易日" [ref=e190] [cursor=pointer]:
                  - generic [ref=e191]: 2026-03-12 · 开放段 · 开放 · 51 个交易日
                  - generic [ref=e192]: ▼
          - generic [ref=e193]:
            - generic [ref=e194]:
              - heading "解读" [level=3] [ref=e195]
              - paragraph [ref=e196]: 生产解读所指阶段族与阶段时钟不同；原文保留于来源抽屉，不作为当前读数显示。
            - generic [ref=e197]:
              - heading "轮动事件" [level=3] [ref=e198]
              - paragraph [ref=e199]: 该窗口内没有已结束的轮动事件
          - generic [ref=e200]:
            - generic [ref=e201]:
              - heading "拐点估计与先验" [level=3] [ref=e202]
              - group "转折风险（仅历史校验）" [ref=e203]:
                - heading "转折风险（仅历史校验）" [level=4] [ref=e204]
                - generic [ref=e205]:
                  - generic [ref=e206]: 转折≤1月
                  - generic [ref=e207]: ≤3月
                  - generic [ref=e208]: ≤6月
                  - generic [ref=e209]: 向上段 · 顶部
                  - generic [ref=e210]:
                    - generic [ref=e211]: 18%
                    - generic [ref=e212]: 模型
                  - generic [ref=e213]:
                    - generic [ref=e214]: 34%
                    - generic [ref=e215]: 先验
                  - generic [ref=e216]:
                    - generic [ref=e217]: 41%
                    - generic [ref=e218]: 模型
                - paragraph [ref=e219]: 先验：历史基准率，并非模型
            - generic [ref=e220]:
              - generic [ref=e221]:
                - heading "方法与限制" [level=3] [ref=e222]
                - list [ref=e223]:
                  - listitem [ref=e224]: 仓位规模：无。信念倍数固定为 1.0，并非仓位大小。
                  - listitem [ref=e225]: 自身节律，描述性，非模型。
                  - listitem [ref=e226]: 领先滞后：不作声明。领先滞后研究已停止；此处不对板块作时间排序。
                  - listitem [ref=e227]: 源数据一致性核验通过，模型资格仍需单独判断
                - group [ref=e228]:
                  - generic "证据详情" [ref=e229] [cursor=pointer]
              - generic [ref=e230]:
                - paragraph [ref=e231]: 判断评分器
                - heading "判断评分器：已衡量命中率" [level=3] [ref=e232]
                - paragraph [ref=e233]: 全部已结算判断（含中性）的条件命中率，并非胜率。
                - paragraph [ref=e234]: 按时间跨度衡量信念判断的已实现方向命中率、横截面秩相关与超越SPY的超额收益。数据累积前较稀疏；绝不回灌入实时评分。
                - paragraph [ref=e235]: 本生成版本暂无评分器
            - generic [ref=e236]:
              - heading "时机与推演" [level=3] [ref=e237]
              - paragraph [ref=e238]: ◷本阶段已持续 18 个交易日
              - paragraph [ref=e239]:
                - text: 价格与200日均线 高于
                - generic [ref=e240]: 上涨趋势
              - paragraph [ref=e241]: 阶段时长是已测量的历史事实 — 并非剩余上行空间，也不是时间限制。
              - generic [ref=e242]:
                - generic [ref=e243]:
                  - generic [ref=e244]: 描述性节律
                  - generic [ref=e245]: 时间窗尚未开启
                - paragraph [ref=e246]: 下次底部 ≈ 2027年2月
                - generic [ref=e247]:
                  - generic [ref=e248]:
                    - term [ref=e249]: 最早
                    - definition [ref=e250]: 2026年12月
                  - generic [ref=e251]:
                    - term [ref=e252]: 中位
                    - definition [ref=e253]: 2027年2月
                  - generic [ref=e254]:
                    - term [ref=e255]: 最晚
                    - definition [ref=e256]: 2027年4月
                - paragraph [ref=e257]: 预计下次底部约在 2027年2月（2026年12月–2027年4月），基于该板块自身的中位半周期：描述性节律而非模型，仅为时间窗口。
          - generic [ref=e258]:
            - heading "剩余机会预测" [level=3] [ref=e259]
            - list [ref=e260]:
              - listitem [ref=e261]:
                - generic [ref=e262]: 剩余回报
                - generic [ref=e263]: 暂缓显示
                - generic [ref=e264]: 暂缓：该预测在当前数据上的研究检验未通过
                - generic [ref=e265]: 时间跨度：20 个已完结交易日
                - group [ref=e266]:
                  - generic "证据" [ref=e267]
              - listitem [ref=e268]:
                - generic [ref=e269]: 不利尾部
                - generic [ref=e270]: 暂缓显示
                - generic [ref=e271]: 暂缓：实时周期状态与研究协议的转折口径不一致
                - generic [ref=e272]: 时间跨度：20 个已完结交易日
                - group [ref=e273]:
                  - generic "证据" [ref=e274]
              - listitem [ref=e275]:
                - generic [ref=e276]: 先达目标还是先失效
                - generic [ref=e277]: 暂缓显示
                - generic [ref=e278]: 暂缓：实时周期状态与研究协议的转折口径不一致
                - generic [ref=e279]: 时间跨度：20 个已完结交易日
                - generic [ref=e280]: 周期段方向事实：描述当前上行/下行段的倾向，并非周期择时边界。
                - group [ref=e281]:
                  - generic "证据" [ref=e282]
              - listitem [ref=e283]:
                - generic [ref=e284]: 转折确认时间
                - generic [ref=e285]: 暂缓显示
                - generic [ref=e286]: 暂缓：实时周期状态与研究协议的转折口径不一致
                - generic [ref=e287]: 时间跨度：20 个已完结交易日
                - group [ref=e288]:
                  - generic "证据" [ref=e289]
            - paragraph [ref=e290]: 暂缓显示的预测不展示任何数值。
            - paragraph [ref=e291]: 每项预测单独判断是否暂缓显示；上方已观测的周期事实不受影响。
          - paragraph [ref=e292]: 描述性证据，不构成个股建议、仓位建议或执行授权。
      - dialog "周期全屏" [active] [ref=e294]:
        - generic [ref=e295]:
          - paragraph [ref=e296]: 相对 SPY 强弱
          - generic [ref=e297]:
            - group "相对 SPY 强弱" [ref=e298]:
              - button "图表" [pressed] [ref=e299] [cursor=pointer]
              - button "数据表" [ref=e300] [cursor=pointer]
            - button "关闭全屏" [ref=e301] [cursor=pointer]: ✕
        - img "相对 SPY 强弱" [ref=e302]:
          - generic [ref=e304]: "-4"
          - generic [ref=e306]: "-2"
          - generic [ref=e308]: "0"
          - generic [ref=e310]: "2"
          - generic [ref=e312]: "4"
          - generic "2025-09-13 · trough · 最早可知 2025-09-16" [ref=e315]
          - generic "2025-11-12 · peak · 最早可知 2025-11-15" [ref=e316]
          - generic "2026-01-21 · trough · 最早可知 2026-01-24" [ref=e317]
          - generic "2026-03-12 · peak · 暂定" [ref=e318]
          - generic [ref=e319]: 底部 2025-09-13
          - generic [ref=e320]: 顶部 2026-03-12
        - generic [ref=e323]:
          - time [ref=e324]: 2026-05-02
          - generic [ref=e325]:
            - text: XLK · 21个交易日
            - strong [ref=e326]: "-3.3%"
          - generic [ref=e327]:
            - text: XLK · 63个交易日
            - strong [ref=e328]: "-3.3%"
  - alert [ref=e329]
```

# Test source

```ts
  1   | import { test, expect, type Locator } from "@playwright/test";
  2   | 
  3   | /* Cycles lane e2e — the /dev/sector-cycles harness (deterministic inline
  4   |  * fixtures, no network, clearly labelled as fixture data on the page itself).
  5   |  *
  6   |  * Charter gate 4: keyboard and touch through family/phase/range/scale/leg
  7   |  * selection, chart↔table equivalence, capture→navigate→apply return, at
  8   |  * 1440×900, 820×1180 and 390×844 (desktop/tablet/mobile), light+dark, EN+ZH.
  9   |  * The self-bound return router is exercised for real: leaving a subject
  10  |  * pushes its captured view onto the history entry being left; the browser
  11  |  * back button rebinds that subject (donor #10707 host contract) and the
  12  |  * two-phase codec restores the captured fields. */
  13  | 
  14  | const cases = [
  15  |   ["en", "dark"],
  16  |   ["zh", "light"],
  17  | ] as const;
  18  | 
  19  | const T = (lang: "en" | "zh") => ({
  20  |   chart: lang === "zh" ? "图表" : "Chart",
  21  |   table: lang === "zh" ? "数据表" : "Data table",
  22  |   range: lang === "zh" ? "图表范围" : "Chart range",
  23  |   log: lang === "zh" ? "对数" : "Log",
  24  |   series: lang === "zh" ? "序列" : "Series",
  25  |   obs: lang === "zh" ? "观测日期" : "Observation date",
  26  |   exact: lang === "zh" ? "精确数值" : "Exact values",
  27  |   baskets: lang === "zh" ? "主题组合对比 SPY" : "Thematic Baskets vs SPY",
  28  |   sectorsTab: lang === "zh" ? "板块 ETF 对比 SPY" : "Sector ETFs vs SPY",
  29  |   apply: lang === "zh" ? "应用" : "Apply",
  30  |   legDetails: lang === "zh" ? "周期段详情" : "Leg details",
  31  |   fullscreen: lang === "zh" ? "周期全屏" : "Cycles fullscreen",
  32  |   openFullscreen: lang === "zh" ? "打开全屏" : "Open fullscreen",
  33  |   fullscreenBtn: lang === "zh" ? "全屏" : "Full screen",
  34  |   changeSeries: lang === "zh" ? "更换序列" : "Change series",
  35  |   phaseAll: lang === "zh" ? "全部阶段" : "All phases",
  36  |   expansion: lang === "zh" ? "扩张" : "Expansion",
  37  |   selectedFoot: lang === "zh" ? "已选" : "Selected",
  38  |   troughWord: lang === "zh" ? "底部" : "trough",
  39  |   prov: lang === "zh" ? "暂定" : "Provisional",
  40  |   rs63: lang === "zh" ? "63个交易日" : "63 sessions",
  41  |   trough: lang === "zh" ? "底部" : "Trough",
  42  |   recovery: lang === "zh" ? "复苏" : "Recovery",
  43  |   energy: lang === "zh" ? "能源" : "Energy",
  44  |   financials: lang === "zh" ? "金融" : "Financials",
  45  |   aiInfra: lang === "zh" ? "AI 基础设施" : "AI Infrastructure",
  46  |   story: lang === "zh" ? "趋成熟" : "matured",
  47  |   mismatch: lang === "zh" ? "快照版本不一致" : "Snapshots do not match",
  48  |   /* v1.1 per-head forecast capabilities + SP11 dates + honest windows */
  49  |   range21: lang === "zh" ? "21个交易日" : "21 sessions",
  50  |   range252: lang === "zh" ? "252个交易日" : "252 sessions",
  51  |   range1mWord: lang === "zh" ? "1个月" : "1 month",
  52  |   durationWord: lang === "zh" ? "并非剩余上行空间" : "not remaining upside",
  53  |   firstKnown: lang === "zh" ? "最早可知" : "first known",
  54  |   pivotNote: lang === "zh" ? "转折日期为拐点日期" : "Turn dates are pivot dates",
  55  |   headWithheld: lang === "zh" ? "暂缓显示" : "Withheld",
  56  |   headWithdrawnWord: lang === "zh" ? "已撤回" : "Withdrawn",
  57  |   reasonUnknown: lang === "zh" ? "因未说明的原因暂缓显示" : "Withheld for an unstated reason",
  58  |   reasonFailed: lang === "zh" ? "研究检验未通过" : "research test failed",
  59  |   reasonEpoch: lang === "zh" ? "与研究协议的转折口径不一致" : "does not match the research protocol",
  60  |   horizon20: lang === "zh" ? "20 个已完结交易日" : "20 completed sessions",
  61  |   directional: lang === "zh" ? "周期段方向事实" : "Leg-direction fact",
  62  |   headsAbsent: lang === "zh" ? "未附带预测能力分块" : "No forecast capability block",
  63  | });
  64  | 
  65  | 
  66  | async function expectMeasuredPlot(svg: Locator) {
  67  |   await expect(svg).toBeVisible();
  68  |   const geometry = () => svg.evaluate((element) => {
  69  |     const chart = element as SVGSVGElement;
  70  |     return {
  71  |       container: chart.parentElement!.clientWidth,
  72  |       width: Number(chart.getAttribute("width")),
  73  |       viewBox: chart.viewBox.baseVal.width,
  74  |       rendered: chart.getBoundingClientRect().width,
  75  |     };
  76  |   });
  77  |   expect((await geometry()).container).toBeGreaterThanOrEqual(240);
  78  |   await expect.poll(async () => {
  79  |     const value = await geometry();
  80  |     return Math.max(
  81  |       Math.abs(value.width - value.container),
  82  |       Math.abs(value.viewBox - value.container),
  83  |       Math.abs(value.rendered - value.container),
  84  |     );
> 85  |   }, { message: "SVG coordinates must follow the current measured content width" }).toBeLessThanOrEqual(1);
      |                                                                                     ^ Error: SVG coordinates must follow the current measured content width
  86  |   return geometry();
  87  | }
  88  | 
  89  | async function expectAxisLabels(svg: Locator, expected: string[]) {
  90  |   await expectMeasuredPlot(svg);
  91  |   // Tick labels belong to grid groups; date/turn labels use other anchors.
  92  |   const ticks = svg.locator('g > text[text-anchor="end"]');
  93  |   await expect(ticks).toHaveText(expected);
  94  |   expect(new Set(await ticks.allTextContents()).size).toBe(expected.length);
  95  |   const bounds = await ticks.evaluateAll(elements => elements.map(element => {
  96  |     const label = element.getBoundingClientRect();
  97  |     const chart = (element as SVGElement).ownerSVGElement!.getBoundingClientRect();
  98  |     return { left: label.left - chart.left, right: chart.right - label.right };
  99  |   }));
  100 |   for (const bound of bounds) {
  101 |     expect(bound.left).toBeGreaterThanOrEqual(-1);
  102 |     expect(bound.right).toBeGreaterThanOrEqual(-1);
  103 |   }
  104 | }
  105 | 
  106 | for (const [lang, theme] of cases) {
  107 |   const L = T(lang);
  108 | 
  109 |   for (const axisFixture of ["tiny", "fractional"] as const) {
  110 |     test(`cycles tick precision survives fullscreen ${axisFixture} ${lang} ${theme}`, async ({ page }, info) => {
  111 |       await page.goto("/dev/sector-cycles");
  112 |       await page.getByRole("radio", { name: lang === "zh" ? "ZH" : "EN", exact: true }).check();
  113 |       await page.getByRole("radio", { name: theme === "light" ? "Light" : "Dark", exact: true }).check();
  114 |       await page.getByLabel("Axis fixture").selectOption(axisFixture);
  115 |       await expect(page.getByText("Fixture data — not live evidence")).toBeVisible();
  116 |       await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
  117 | 
  118 |       const panel = page.getByTestId("cycle-chart-panel");
  119 |       await panel.getByLabel(L.range).selectOption("0");
  120 |       const inlineLabels = axisFixture === "tiny"
  121 |         ? ["0.000", "0.005", "0.010"] : ["-2.5", "0.0", "2.5"];
  122 |       const fullscreenLabels = axisFixture === "tiny"
  123 |         ? ["0.0000", "0.0025", "0.0050", "0.0075", "0.0100"]
  124 |         : ["-4", "-2", "0", "2", "4"];
  125 |       await expectAxisLabels(panel.locator("svg"), inlineLabels);
  126 |       await panel.screenshot({
  127 |         path: info.outputPath(`cycles-precision-${axisFixture}-inline-${lang}-${info.project.name}.png`),
  128 |         animations: "disabled",
  129 |       });
  130 | 
  131 |       await panel.getByRole("button", { name: new RegExp(L.fullscreenBtn) }).click();
  132 |       const dialog = page.getByRole("dialog", { name: L.fullscreen });
  133 |       await expect(dialog).toBeVisible();
  134 |       await expectAxisLabels(dialog.locator("svg"), fullscreenLabels);
  135 |       await dialog.screenshot({
  136 |         path: info.outputPath(`cycles-precision-${axisFixture}-fullscreen-${lang}-${info.project.name}.png`),
  137 |         animations: "disabled",
  138 |       });
  139 |       await page.keyboard.press("Escape");
  140 |       await expect(dialog).toBeHidden();
  141 |       await expectAxisLabels(panel.locator("svg"), inlineLabels);
  142 |       expect(await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)).toBeLessThanOrEqual(1);
  143 |     });
  144 |   }
  145 | 
  146 |   for (const transition of ["table", "empty"] as const) {
  147 |     test(`cycles chart measurement survives ${transition} transitions ${lang} ${theme}`, async ({ page }, info) => {
  148 |       await page.goto("/dev/sector-cycles");
  149 |       await page.getByRole("radio", { name: lang === "zh" ? "ZH" : "EN", exact: true }).check();
  150 |       await page.getByRole("radio", { name: theme === "light" ? "Light" : "Dark", exact: true }).check();
  151 | 
  152 |       const initialViewport = page.viewportSize()!;
  153 |       // Remain in the same responsive band, so a remounted panel cannot hide
  154 |       // the lost observer. The final capture returns to the contract viewport.
  155 |       const widths = initialViewport.width >= 981 ? [1100, 1280]
  156 |         : initialViewport.width >= 641 ? [700, 900] : [510, 430];
  157 |       const panel = page.getByTestId("cycle-chart-panel");
  158 |       const svg = panel.locator("svg");
  159 |       const expectThemePaint = async (selected: "light" | "dark") => {
  160 |         await expect.poll(() => panel.evaluate(element => {
  161 |           const root = document.documentElement;
  162 |           const tokens = getComputedStyle(root);
  163 |           const paint = getComputedStyle(element);
  164 |           return {
  165 |             theme: root.dataset.theme,
  166 |             appearance: root.dataset.terminalAppearance,
  167 |             sharedShell: root.dataset.mmxSharedShell ?? null,
  168 |             backgroundToken: tokens.getPropertyValue("--bg").trim(),
  169 |             secondaryPanelToken: tokens.getPropertyValue("--panel-2").trim(),
  170 |             textToken: tokens.getPropertyValue("--text").trim(),
  171 |             background: paint.backgroundColor,
  172 |             foreground: paint.color,
  173 |           };
  174 |         })).toEqual({
  175 |           theme: selected, appearance: "1", sharedShell: null,
  176 |           backgroundToken: selected === "light" ? "#f7f8fa" : "#0a0b0e",
  177 |           secondaryPanelToken: selected === "light" ? "#eef1f6" : "#15171d",
  178 |           textToken: selected === "light" ? "#202632" : "#d6dae3",
  179 |           background: selected === "light" ? "rgb(255, 255, 255)" : "rgb(13, 15, 19)",
  180 |           foreground: selected === "light" ? "rgb(32, 38, 50)" : "rgb(214, 218, 227)",
  181 |         });
  182 |       };
  183 |       await expectThemePaint(theme);
  184 |       const otherTheme = theme === "light" ? "dark" : "light";
  185 |       await page.getByRole("radio", { name: otherTheme === "light" ? "Light" : "Dark", exact: true }).check();
```