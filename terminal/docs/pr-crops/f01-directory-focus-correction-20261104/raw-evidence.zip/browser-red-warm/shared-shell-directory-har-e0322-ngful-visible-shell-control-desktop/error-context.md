# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: shared-shell-directory-hardening.spec.ts >> shortcut from BODY returns to a meaningful visible shell control
- Location: e2e/shared-shell-directory-hardening.spec.ts:139:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.shared-shell-directory[open]')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('.shared-shell-directory[open]')

```

```yaml
- link "Skip to content":
  - /url: "#shared-shell-content"
- banner:
  - button "Compact"
  - text: MASTERMIND Beta
  - button "Search companies":
    - strong: Search any company…
  - button "All tools": All tools ⌘ K
  - group "Appearance and language":
    - button "Light theme"
    - button "Chinese language"
  - link "Open current chart":
    - /url: /terminal?from=macro&ret=http%3A%2F%2F127.0.0.1%3A3139%2Fdiscover
  - button "Settings": U
- navigation "Main navigation":
  - link "Today":
    - /url: /today
    - img
    - text: Today
  - link "Discover":
    - /url: /discover
    - img
    - text: Discover
  - link "Analysis":
    - /url: /analysis
    - img
    - text: Analysis
  - link "Monitor":
    - /url: /monitor
    - img
    - text: Monitor
  - link "Research":
    - /url: /research
    - img
    - text: Research
  - link "Portfolio":
    - /url: /portfolio
    - img
    - text: Portfolio
  - heading "Markets" [level=2]
  - link "United States":
    - /url: /us_stocks.html
  - link "China":
    - /url: /china.html
  - link "Hong Kong":
    - /url: /hk.html
  - link "Canada":
    - /url: /canada.html
  - link "International":
    - /url: /intl.html
  - button "All tools"
  - button "Mastermind AI":
    - img
    - text: Mastermind AI
- status
- main:
  - heading "Discover" [level=1]
  - paragraph: Choose a question. Open the right workspace.
  - button "Search companies"
  - article:
    - paragraph: Screen companies
    - heading "Start with a universe. Narrow it with evidence." [level=2]
    - paragraph: Use technical, fundamental and classification filters. Check each field's coverage before comparing results.
    - button "Open Stock Screener"
  - article:
    - paragraph: Explore market structure
    - heading "See participation in context" [level=2]
    - paragraph: Move from the market map to the sectors and companies behind it.
    - button "Open Heatmap"
    - button "Open Sectors"
  - article:
    - heading "Follow market leadership" [level=2]
    - paragraph: Inspect the existing leader views and their underlying coverage.
    - button "Leaders"
    - button "Leader Radar"
  - article:
    - heading "RS · 30m Pivot" [level=2]
    - paragraph: Explore the study's conditions, timing and limitations.
    - button "Open study"
  - heading "Go deeper with a focused workflow" [level=2]
  - link "US stocks · Prophet":
    - /url: /us_stocks.html
  - paragraph: Open the US stock dashboard for Prophet, sectors and flows.
  - link "Catalysts":
    - /url: /biocatalyst.html
  - paragraph: Company catalysts anchored in original disclosures.
  - link "Confluence":
    - /url: /confluence_screener.html
  - paragraph: Adds evidence confluence on top of the existing screen.
- alert
```

# Test source

```ts
  44  |     await page.locator(".m-drawer.open").getByRole("button", { name: "All tools", exact: true }).click();
  45  |   } else {
  46  |     await page.locator(".topbar .shared-shell-directory-trigger").click();
  47  |   }
  48  |   await expect(directory(page)).toBeVisible();
  49  |   await expect(directory(page).getByRole("searchbox")).toBeFocused();
  50  |   await expect(page.getByRole("dialog")).toHaveCount(1);
  51  | }
  52  | 
  53  | async function contained(page: Page) {
  54  |   const box = await directory(page).boundingBox();
  55  |   expect(box!.x).toBeGreaterThanOrEqual(0);
  56  |   expect(box!.x + box!.width).toBeLessThanOrEqual(page.viewportSize()!.width + 1);
  57  |   expect(box!.y).toBeGreaterThanOrEqual(0);
  58  |   expect(box!.y + box!.height).toBeLessThanOrEqual(page.viewportSize()!.height + 1);
  59  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  60  | }
  61  | 
  62  | test("query-wide recovery is distinct from category scope in the real catalogue", async ({ page }, info) => {
  63  |   await open(page);
  64  |   const dialog = directory(page);
  65  |   await dialog.getByRole("searchbox").fill("options");
  66  |   await expect(dialog.locator(".shared-directory-link")).toHaveCount(12);
  67  |   const before = await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")));
  68  |   expect(before).toEqual(expect.arrayContaining(["/options", "/options.html", "/options_screener.html", "/options/futures"]));
  69  |   await dialog.getByRole("button", { name: "Workspaces", exact: true }).click();
  70  |   await expect(dialog.getByRole("status")).toHaveText("2 in this category");
  71  |   await expect(dialog.locator(".shared-directory-link")).toHaveCount(2);
  72  |   const recovery = dialog.getByRole("button", { name: "Show all 12 matches", exact: true });
  73  |   expect((await recovery.boundingBox())!.height).toBeGreaterThanOrEqual(44);
  74  |   await contained(page);
  75  |   await page.screenshot({ animations: "disabled", path: info.outputPath("category-recovery-dark-en.png") });
  76  |   await recovery.focus(); await page.keyboard.press("Enter");
  77  |   await expect(dialog.getByRole("button", { name: "All", exact: true })).toBeFocused();
  78  |   await expect(dialog.getByRole("searchbox")).toHaveValue("options");
  79  |   expect(await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")))).toEqual(before);
  80  |   await dialog.getByRole("button", { name: "Research", exact: true }).click();
  81  |   await expect(dialog.getByRole("heading", { name: "No matches in this category", exact: true })).toBeVisible();
  82  |   await expect(dialog.getByRole("status")).toHaveText("0 in this category");
  83  |   await expect(dialog.getByRole("button", { name: "Show all 12 matches", exact: true })).toBeVisible();
  84  |   await page.screenshot({ animations: "disabled", path: info.outputPath("empty-category-dark-en.png") });
  85  | });
  86  | 
  87  | test("clear query, batching and same-instance reopen retain the correct state", async ({ page }) => {
  88  |   await open(page); const dialog = directory(page);
  89  |   await dialog.getByRole("button", { name: "Show more", exact: true }).click();
  90  |   await expect(dialog.locator(".shared-directory-link")).toHaveCount(96);
  91  |   await page.keyboard.press("Escape"); await open(page);
  92  |   await expect(dialog.locator(".shared-directory-link")).toHaveCount(96);
  93  |   await dialog.getByRole("searchbox").fill("no-such-directory-destination-20261104");
  94  |   await expect(dialog.getByRole("heading", { name: "No pages found", exact: true })).toBeVisible();
  95  |   await dialog.getByRole("button", { name: "Tools", exact: true }).click();
  96  |   await dialog.getByRole("button", { name: "Clear search", exact: true }).click();
  97  |   await expect(dialog.getByRole("searchbox")).toHaveValue("");
  98  |   await expect(dialog.getByRole("searchbox")).toBeFocused();
  99  |   await expect(dialog.getByRole("button", { name: "Tools", exact: true })).toHaveAttribute("aria-pressed", "true");
  100 |   await expect(dialog.locator(".shared-directory-results")).not.toHaveAttribute("aria-live", /.+/);
  101 |   await expect(dialog.getByRole("status")).toHaveAttribute("aria-atomic", "true");
  102 | });
  103 | 
  104 | test("actual locale/theme controls preserve a filtered directory across reopen", async ({ page }, info) => {
  105 |   await open(page); let dialog = directory(page);
  106 |   await dialog.getByRole("searchbox").fill("options");
  107 |   await dialog.getByRole("button", { name: "Workspaces", exact: true }).click();
  108 |   const identities = await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")));
  109 |   await page.keyboard.press("Escape");
  110 |   await page.getByRole("button", { name: "Light theme", exact: true }).click();
  111 |   await page.getByRole("button", { name: "Chinese language", exact: true }).click();
  112 |   await expect(page.locator("html")).toHaveAttribute("data-lang", "zh");
  113 |   await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
  114 |   // Keyboard invocation uses the existing shell listener after the old modal closed.
  115 |   await page.locator("main").first().click({ position: { x: 5, y: 5 } });
  116 |   await page.keyboard.press("ControlOrMeta+k"); dialog = directory(page);
  117 |   await expect(dialog).toBeVisible(); await expect(dialog.getByRole("searchbox")).toHaveValue("options");
  118 |   await expect(dialog.getByRole("button", { name: "工作区", exact: true })).toHaveAttribute("aria-pressed", "true");
  119 |   expect(await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")))).toEqual(identities);
  120 |   await expect(dialog.getByRole("button", { name: "查看全部 12 个匹配结果", exact: true })).toBeVisible();
  121 |   await contained(page);
  122 |   await page.screenshot({ animations: "disabled", path: info.outputPath("category-recovery-light-zh.png") });
  123 |   await page.setViewportSize({ width: 320, height: 420 });
  124 |   await contained(page); await expect(dialog.getByRole("button", { name: "关闭", exact: true })).toBeVisible();
  125 |   await expect(dialog.getByRole("searchbox")).toBeVisible();
  126 |   await page.screenshot({ animations: "disabled", path: info.outputPath("short-320-light-zh.png") });
  127 | });
  128 | 
  129 | test("drawer-to-directory and resize close return to a visible persistent control", async ({ page }, info) => {
  130 |   await open(page); await directory(page).getByRole("searchbox").fill("options");
  131 |   if (info.project.name === "desktop") await page.setViewportSize({ width: 320, height: 844 });
  132 |   await page.keyboard.press("Escape");
  133 |   await expect(page.getByRole("dialog")).toHaveCount(0);
  134 |   await expect(page.getByRole("button", { name: "Open navigation", exact: true })).toBeFocused();
  135 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  136 |   await page.screenshot({ animations: "disabled", path: info.outputPath("visible-focus-return.png") });
  137 | });
  138 | 
  139 | test("shortcut from BODY returns to a meaningful visible shell control", async ({ page }, info) => {
  140 |   await page.evaluate(() => { if (document.activeElement instanceof HTMLElement) document.activeElement.blur(); });
  141 |   expect(await page.evaluate(() => document.activeElement === document.body)).toBe(true);
  142 |   const before = await page.evaluate(() => ({ tabIndex: document.body.getAttribute("tabindex"), x: scrollX, y: scrollY }));
  143 |   await page.keyboard.press("ControlOrMeta+k");
> 144 |   await expect(directory(page)).toBeVisible();
      |                                 ^ Error: expect(locator).toBeVisible() failed
  145 |   await expect(directory(page).getByRole("searchbox")).toBeFocused();
  146 |   await page.keyboard.press("Escape");
  147 |   await expect(directory(page)).toHaveCount(0);
  148 |   const returnTarget = page.viewportSize()!.width <= 860
  149 |     ? page.getByRole("button", { name: "Open navigation", exact: true })
  150 |     : page.locator(".topbar .shared-shell-directory-trigger");
  151 |   await expect(returnTarget).toBeFocused(); await expect(returnTarget).toBeVisible();
  152 |   expect(await page.evaluate(() => ({ tabIndex: document.body.getAttribute("tabindex"), x: scrollX, y: scrollY }))).toEqual(before);
  153 |   await page.screenshot({ animations: "disabled", path: info.outputPath("shortcut-meaningful-return.png") });
  154 | });
  155 | 
  156 | test("Show all reveals its focused category inside the scrolled strip", async ({ page }, info) => {
  157 |   await page.setViewportSize({ width: info.project.name === "mobile" ? 390 : 320, height: 844 });
  158 |   await open(page);
  159 |   const dialog = directory(page);
  160 |   const search = dialog.getByRole("searchbox");
  161 |   await search.fill("options");
  162 |   const before = await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")));
  163 |   await dialog.getByRole("button", { name: "About", exact: true }).click();
  164 |   const strip = dialog.locator(".shared-directory-filters");
  165 |   await strip.evaluate(element => { element.scrollLeft = element.scrollWidth; });
  166 |   const all = dialog.getByRole("button", { name: "All", exact: true });
  167 |   const geometry = () => all.evaluate(element => {
  168 |     const strip = element.closest(".shared-directory-filters")!;
  169 |     const outer = strip.getBoundingClientRect(); const target = element.getBoundingClientRect();
  170 |     return { scrollLeft: strip.scrollLeft, left: target.left, right: target.right,
  171 |       clipLeft: outer.left + strip.clientLeft, clipRight: outer.left + strip.clientLeft + strip.clientWidth };
  172 |   });
  173 |   const clipped = await geometry();
  174 |   expect(clipped.scrollLeft).toBeGreaterThan(0);
  175 |   expect(clipped.left < clipped.clipLeft - 1 || clipped.right > clipped.clipRight + 1).toBe(true);
  176 |   const scrollBefore = await page.evaluate(() => ({ x: scrollX, y: scrollY,
  177 |     main: [...document.querySelectorAll("main, .main2")].map(node => ({ x: node.scrollLeft, y: node.scrollTop })) }));
  178 |   await dialog.getByRole("button", { name: `Show all ${before.length} matches`, exact: true }).focus();
  179 |   await page.keyboard.press("Enter");
  180 |   await expect(all).toBeFocused(); await expect(all).toHaveAttribute("aria-pressed", "true");
  181 |   const revealed = await geometry();
  182 |   expect(revealed.left).toBeGreaterThanOrEqual(revealed.clipLeft - 1);
  183 |   expect(revealed.right).toBeLessThanOrEqual(revealed.clipRight + 1);
  184 |   expect(await page.evaluate(() => ({ x: scrollX, y: scrollY,
  185 |     main: [...document.querySelectorAll("main, .main2")].map(node => ({ x: node.scrollLeft, y: node.scrollTop })) }))).toEqual(scrollBefore);
  186 |   await expect(search).toHaveValue("options");
  187 |   expect(await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")))).toEqual(before);
  188 |   await page.screenshot({ animations: "disabled", path: info.outputPath("revealed-category-focus.png") });
  189 | });
  190 | 
  191 | test("directory transfers once to the real company picker and respects composing Escape", async ({ page }) => {
  192 |   await open(page); const input = directory(page).getByRole("searchbox");
  193 |   await input.dispatchEvent("compositionstart", { data: "期" });
  194 |   await input.dispatchEvent("keydown", { key: "Escape", isComposing: true, bubbles: true, cancelable: true });
  195 |   await expect(directory(page)).toBeVisible();
  196 |   await input.dispatchEvent("compositionend", { data: "期权" });
  197 |   await directory(page).locator(".shared-directory-footer button").click();
  198 |   await expect(directory(page)).toHaveCount(0); await expect(page.getByRole("dialog")).toHaveCount(1);
  199 |   await expect(page.getByRole("dialog")).toHaveAccessibleName("Search companies");
  200 |   await expect(page.getByRole("dialog").getByRole("combobox")).toBeFocused();
  201 |   await page.keyboard.press("Escape"); await expect(page.getByRole("dialog")).toHaveCount(0);
  202 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  203 | });
  204 | 
  205 | test("native dialog cancellation respects the captured Escape owner", async ({ page }) => {
  206 |   await open(page); const input = directory(page).getByRole("searchbox");
  207 |   // Native Escape after composition ends in a child listener must still belong
  208 |   // to that composition. This exercises native dialog cancellation in Chromium;
  209 |   // it does not establish an operating-system IME or assistive-technology pass.
  210 |   await input.dispatchEvent("compositionstart", { data: "期" });
  211 |   await input.evaluate(element => element.addEventListener("keydown", () => {
  212 |     element.dispatchEvent(new CompositionEvent("compositionend", { bubbles: true, data: "期权" }));
  213 |   }, { once: true }));
  214 |   await page.keyboard.press("Escape");
  215 |   await expect(directory(page)).toBeVisible(); await expect(input).toBeFocused();
  216 |   const guarded = await input.evaluate(element => {
  217 |     const modal = element.closest("dialog")!;
  218 |     for (const signal of [{ isComposing: true }, { keyCode: 229 }, { repeat: true }]) {
  219 |       element.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true, cancelable: true, ...signal }));
  220 |       modal.requestClose();
  221 |       if (!modal.open) return false;
  222 |     }
  223 |     // Consumed protection cannot block a second independent request, even
  224 |     // before a keyup or the expiry task has run.
  225 |     modal.requestClose();
  226 |     return true;
  227 |   });
  228 |   expect(guarded).toBe(true);
  229 |   await expect(directory(page)).toHaveCount(0);
  230 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  231 | });
  232 | 
  233 | test("real Next Link keeps the current directory on modified activation", async ({ page, context }, info) => {
  234 |   test.skip(info.project.name !== "desktop", "Single real new-tab browser case");
  235 |   await open(page); await directory(page).getByRole("searchbox").fill("options");
  236 |   const link = directory(page).locator('a[href="/options"]');
  237 |   const popupPromise = context.waitForEvent("page");
  238 |   await link.click({ modifiers: ["ControlOrMeta"] });
  239 |   const popup = await popupPromise; await popup.waitForURL(/\/options$/); await popup.close();
  240 |   await expect(directory(page)).toBeVisible();
  241 |   await expect(directory(page).getByRole("searchbox")).toHaveValue("options");
  242 |   await link.click(); await expect(page).toHaveURL(/\/options$/); await expect(directory(page)).toHaveCount(0);
  243 | });
  244 | 
```