"""Queue ownership is earned from exact native identities, never a PR hint."""
from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

from scripts import migration_merge_group as group
from scripts.check_supabase_migration_namespace import collect_for_event

REPO = "example/terminal"
BASE, HEAD, SOURCE, TREE = (letter * 40 for letter in "abcd")
NAME = "0099_example.sql"
RAW = b"-- Ledger row: fixture\n-- Rollback: drop table if exists fixture;\ncreate table if not exists fixture(id int);\n"
ROW = {"state": "taken", "file": NAME, "packet": "test", "pr": 582,
       "pr_state": "open", "note": "fixture", "applied_in_production": False, "applied_date": None}


def fixture():
    env = {"GITHUB_EVENT_NAME": "merge_group", "GITHUB_REPOSITORY": REPO,
           "GITHUB_SHA": HEAD, "GITHUB_REF": "refs/heads/gh-readonly-queue/master/opaque"}
    event = {"action": "checks_requested", "repository": {"full_name": REPO},
             "merge_group": {"head_sha": HEAD, "base_sha": BASE,
                             "head_ref": env["GITHUB_REF"], "base_ref": "refs/heads/master"}}
    entry = {"id": "MQE-1", "position": 1, "baseCommit": {"oid": BASE},
             "headCommit": {"oid": HEAD, "tree": {"oid": TREE}, "parents": {"nodes": [{"oid": BASE}]}},
             "pullRequest": {"number": 582, "state": "OPEN", "baseRefName": "master", "headRefOid": SOURCE,
                             "baseRepository": {"nameWithOwner": REPO}, "headRepository": {"nameWithOwner": REPO},
                             "potentialMergeCommit": {"tree": {"oid": TREE}, "parents": {"nodes": [{"oid": BASE}, {"oid": SOURCE}]}}}}
    data = {"repository": {"nameWithOwner": REPO, "defaultBranchRef": {"name": "master", "target": {"oid": BASE}},
             "mergeQueue": {"configuration": {"mergeMethod": "SQUASH", "maximumEntriesToBuild": 1, "maximumEntriesToMerge": 1},
                            "entries": {"pageInfo": {"hasNextPage": False}, "nodes": [entry]}}}}
    return data, event, env


def set_path(obj, path, value):
    keys = path.split(".")
    for key in keys[:-1]:
        obj = obj[int(key)] if isinstance(obj, list) else obj[key]
    obj[int(keys[-1]) if isinstance(obj, list) else keys[-1]] = value


def test_exact_native_single_entry_is_qualified():
    data, event, env = fixture()
    env["PR_NUMBER"] = "9999"  # ignored, not an alternate source of ownership
    assert group.validate_snapshot(data, event, env, HEAD) == (582, SOURCE, BASE)


@pytest.mark.parametrize("path,value", [
    ("nameWithOwner", "foreign/repo"),
    ("defaultBranchRef.target.oid", "e" * 40),
    ("mergeQueue.configuration.mergeMethod", "MERGE"),
    ("mergeQueue.configuration.maximumEntriesToBuild", 4),
    ("mergeQueue.configuration.maximumEntriesToMerge", 2),
    ("mergeQueue.configuration.maximumEntriesToBuild", True),
    ("mergeQueue.entries.pageInfo.hasNextPage", True),
    ("mergeQueue.entries.nodes.0.position", 2),
    ("mergeQueue.entries.nodes.0.baseCommit.oid", "e" * 40),
    ("mergeQueue.entries.nodes.0.headCommit.oid", "e" * 40),
    ("mergeQueue.entries.nodes.0.headCommit.parents.nodes", []),
    ("mergeQueue.entries.nodes.0.pullRequest.number", True),
    ("mergeQueue.entries.nodes.0.pullRequest.state", "MERGED"),
    ("mergeQueue.entries.nodes.0.pullRequest.baseRefName", "other"),
    ("mergeQueue.entries.nodes.0.pullRequest.headRepository.nameWithOwner", "foreign/repo"),
    ("mergeQueue.entries.nodes.0.pullRequest.potentialMergeCommit", None),
    ("mergeQueue.entries.nodes.0.pullRequest.potentialMergeCommit.parents.nodes.1.oid", "e" * 40),
    ("mergeQueue.entries.nodes.0.pullRequest.potentialMergeCommit.tree.oid", "e" * 40),
])
def test_stale_foreign_multi_entry_or_unbound_snapshot_refuses(path, value):
    data, event, env = fixture()
    set_path(data["repository"], path, value)
    with pytest.raises(group.OwnershipUnqualified):
        group.validate_snapshot(data, event, env, HEAD)


@pytest.mark.parametrize("field,value", [("GITHUB_EVENT_NAME", "pull_request"), ("GITHUB_SHA", "e" * 40),
                                        ("GITHUB_REF", "refs/heads/other"), ("GITHUB_REPOSITORY", "foreign/repo")])
def test_environment_must_match_the_actual_event(field, value):
    data, event, env = fixture()
    env[field] = value
    with pytest.raises(group.OwnershipUnqualified):
        group.validate_snapshot(data, event, env, HEAD)


def test_wrong_checkout_and_duplicate_candidate_refuse():
    data, event, env = fixture()
    with pytest.raises(group.OwnershipUnqualified):
        group.validate_snapshot(data, event, env, "e" * 40)
    nodes = data["repository"]["mergeQueue"]["entries"]["nodes"]
    nodes.append(copy.deepcopy(nodes[0]))
    with pytest.raises(group.OwnershipUnqualified):
        group.validate_snapshot(data, event, env, HEAD)


def migration_fixture():
    doc = {"prefixes": {"0099": copy.deepcopy(ROW)}}
    source = {"ledger": {"__typename": "Blob", "text": json.dumps(doc)},
              "base_tree": {"__typename": "Tree", "entries": []},
              "file0": {"__typename": "Blob", "oid": group.git_blob(RAW)}, "base0": None}
    return doc, source


def test_only_exact_new_owner_migration_bytes_qualify():
    doc, source = migration_fixture()
    source["base_tree"]["entries"] = [
        {"name": "0032_existing.sql", "type": "blob"},
        {"name": "RESERVATIONS.json", "type": "blob"},
    ]
    group.validate_migrations(582, doc, {NAME: RAW}, source)


def test_renamed_existing_prefix_cannot_become_a_new_migration():
    name = "0032_renamed_existing.sql"
    row = dict(ROW, file=name)
    doc = {"prefixes": {"0032": row}}
    source = {
        "ledger": {"__typename": "Blob", "text": json.dumps(doc)},
        "file0": {"__typename": "Blob", "oid": group.git_blob(RAW)}, "base0": None,
        "base_tree": {"__typename": "Tree", "entries": [
            {"name": "0032_thesis_proposal_state_qualification.sql", "type": "blob"}
        ]},
    }
    with pytest.raises(group.OwnershipUnqualified, match="prefix already exists"):
        group.validate_migrations(582, doc, {name: RAW}, source)


@pytest.mark.parametrize("tree", [None, {"__typename": "Blob"}, {"__typename": "Tree"},
                                   {"__typename": "Tree", "entries": [None]}])
def test_missing_or_malformed_base_directory_cannot_prove_prefix_absence(tree):
    doc, source = migration_fixture()
    source["base_tree"] = tree
    with pytest.raises(group.OwnershipUnqualified):
        group.validate_migrations(582, doc, {NAME: RAW}, source)


@pytest.mark.parametrize("change", ["owner", "ledger", "bytes", "base", "missing_base", "not_blob"])
def test_foreign_changed_inherited_or_missing_migration_proof_refuses(change):
    doc, source = migration_fixture()
    if change == "owner":
        doc["prefixes"]["0099"]["pr"] = 9999
    elif change == "ledger":
        source["ledger"]["text"] = '{"prefixes":{}}'
    elif change == "bytes":
        source["file0"]["oid"] = "e" * 40
    elif change == "base":
        source["base0"] = {"__typename": "Blob", "oid": group.git_blob(RAW)}
    elif change == "missing_base":
        del source["base0"]
    else:
        source["file0"]["__typename"] = "Tree"
    with pytest.raises(group.OwnershipUnqualified):
        group.validate_migrations(582, doc, {NAME: RAW}, source)


def repo_fixture(tmp_path):
    directory = tmp_path / "migrations"
    directory.mkdir()
    (directory / NAME).write_bytes(RAW)
    doc = {"header_required_from": "0015", "header_required_note": "test", "project_ref": "zzzzsyntheticref00000",
           "prefixes": {"0099": copy.deepcopy(ROW)}}
    ledger = tmp_path / "RESERVATIONS.json"
    ledger.write_text(json.dumps(doc))
    return directory, ledger


def test_actual_guard_uses_verified_owner_but_preserves_failed_and_force_strict_barriers(tmp_path, monkeypatch):
    directory, ledger = repo_fixture(tmp_path)
    env = {"GITHUB_EVENT_NAME": "merge_group", "PR_NUMBER": "9999"}
    monkeypatch.setattr(group, "qualify_owner", lambda *args: 582)
    findings, _, mode = collect_for_event(env, migrations_dir=directory, reservations=ledger)
    assert not any(f.code.startswith("OPEN_PR_STATE") for f in findings)
    assert "MERGE_GROUP_SINGLE_PR (#582" in mode
    findings, _, mode = collect_for_event(env, force_strict=True, migrations_dir=directory, reservations=ledger)
    assert any(f.code == "OPEN_PR_STATE_WITH_FILE_PRESENT" for f in findings)

    def unavailable(*args):
        raise group.OwnershipUnqualified("native membership unavailable")
    monkeypatch.setattr(group, "qualify_owner", unavailable)
    findings, _, mode = collect_for_event(env, migrations_dir=directory, reservations=ledger)
    assert {"MERGE_GROUP_OWNERSHIP_UNQUALIFIED", "OPEN_PR_STATE_WITH_FILE_PRESENT"} <= {f.code for f in findings}


def test_no_api_read_for_group_without_open_files_or_ordinary_pr(tmp_path, monkeypatch):
    directory, ledger = repo_fixture(tmp_path)
    def unexpected(*args):
        raise AssertionError("unexpected API read")
    monkeypatch.setattr(group, "qualify_owner", unexpected)
    collect_for_event({"GITHUB_EVENT_NAME": "pull_request", "PR_NUMBER": "582"}, migrations_dir=directory, reservations=ledger)
    doc = json.loads(ledger.read_text())
    doc["prefixes"]["0099"]["pr_state"] = "merged"
    ledger.write_text(json.dumps(doc))
    collect_for_event({"GITHUB_EVENT_NAME": "merge_group"}, migrations_dir=directory, reservations=ledger)


def test_missing_token_is_not_anonymous_or_alternate_authentication():
    with pytest.raises(group.OwnershipUnqualified, match="token is unavailable"):
        group.graphql_reader("")


def test_native_reader_pins_source_queries_and_never_uses_pr_hint(tmp_path, monkeypatch):
    data, event, env = fixture()
    doc, source = migration_fixture()
    event_path = tmp_path / "event.json"
    event_path.write_text(json.dumps(event))
    env.update(GITHUB_EVENT_PATH=str(event_path), GH_TOKEN="synthetic-token", PR_NUMBER="9999")
    calls = []
    def read(query, variables):
        calls.append((query, variables))
        return data if len(calls) == 1 else {"repository": source}
    monkeypatch.setattr(group, "graphql_reader", lambda token: read)
    monkeypatch.setattr(group.subprocess, "check_output", lambda *args, **kwargs: HEAD + "\n")
    assert group.qualify_owner(tmp_path, env, doc, {NAME: RAW}) == 582
    assert len(calls) == 2
    assert calls[0][1] == {"owner": "example", "name": "terminal"}
    expressions = calls[1][1]
    assert expressions["ledger"] == SOURCE + ":supabase/migrations/RESERVATIONS.json"
    assert expressions["base_tree"] == BASE + ":supabase/migrations"
    assert "... on Tree { entries { name type } }" in calls[1][0]
    assert expressions["file0"] == SOURCE + ":supabase/migrations/" + NAME
    assert expressions["base0"] == BASE + ":supabase/migrations/" + NAME
    assert "9999" not in str(calls) and "synthetic-token" not in str(calls)


def test_api_failure_keeps_credentials_out_of_guard_error(monkeypatch):
    def failure(*args, **kwargs):
        raise RuntimeError("sensitive synthetic-token request details")
    monkeypatch.setattr(group.urllib.request, "urlopen", failure)
    with pytest.raises(group.OwnershipUnqualified) as result:
        group.graphql_reader("synthetic-token")("query {}", {})
    assert str(result.value) == "GitHub ownership read failed"


# Parallel native queue profile: the live ruleset builds eight candidates and
# permits four to merge. It still emits single-parent candidate commits chained
# through GitHub's authenticated entry sequence, not a PR_NUMBER supplied to CI.
SECOND_HEAD, SECOND_SOURCE, SECOND_TREE = ("e" * 40, "f" * 40, "1" * 40)
SECOND_NAME = "0100_parallel.sql"
SECOND_RAW = b"-- Ledger row: second\n-- Rollback: drop table if exists parallel;\ncreate table if not exists parallel(id int);\n"


def parallel_fixture():
    data, event, env = fixture()
    config = data["repository"]["mergeQueue"]["configuration"]
    config.update(
        mergingStrategy="ALLGREEN", maximumEntriesToBuild=8, maximumEntriesToMerge=4
    )
    first = data["repository"]["mergeQueue"]["entries"]["nodes"][0]
    second = copy.deepcopy(first)
    second["id"] = "MQE-2"
    second["position"] = 2
    second["baseCommit"]["oid"] = HEAD
    second["headCommit"] = {
        "oid": SECOND_HEAD, "tree": {"oid": SECOND_TREE},
        "parents": {"nodes": [{"oid": HEAD}]},
    }
    second["pullRequest"].update(number=583, headRefOid=SECOND_SOURCE)
    second["pullRequest"]["potentialMergeCommit"] = {
        "tree": {"oid": SECOND_TREE},
        "parents": {"nodes": [{"oid": HEAD}, {"oid": SECOND_SOURCE}]},
    }
    data["repository"]["mergeQueue"]["entries"]["nodes"].append(second)
    event["merge_group"]["head_sha"] = SECOND_HEAD
    # GitHub's event base_sha points at protected master (BASE); the
    # predictive predecessor is HEAD and is proved by the queue entry itself.
    event["merge_group"]["base_sha"] = BASE
    env["GITHUB_SHA"] = SECOND_HEAD
    return data, event, env


def parallel_migration_fixture():
    doc = {"prefixes": {
        "0099": copy.deepcopy(ROW),
        "0100": dict(ROW, pr=583, file=SECOND_NAME),
    }}
    files = {NAME: RAW, SECOND_NAME: SECOND_RAW}
    owners = {582: SOURCE, 583: SECOND_SOURCE}
    reads = []

    def read(query, variables):
        reads.append((query, variables))
        owner = 582 if variables["ledger"].startswith(SOURCE + ":") else 583
        file_raw = RAW if owner == 582 else SECOND_RAW
        return {"repository": {
            "ledger": {"__typename": "Blob", "text": json.dumps(doc)},
            "base_tree": {"__typename": "Tree", "entries": [
                {"name": "0030_prior.sql", "type": "blob"},
            ]},
            "file0": {"__typename": "Blob", "oid": group.git_blob(file_raw)},
            "base0": None,
        }}
    return owners, doc, files, read, reads


def test_event_base_is_protected_tip_not_predictive_predecessor():
    data, event, env = parallel_fixture()
    assert event["merge_group"]["base_sha"] == BASE
    assert data["repository"]["mergeQueue"]["entries"]["nodes"][1]["baseCommit"]["oid"] == HEAD
    assert group.validate_parallel_snapshot(data, event, env, SECOND_HEAD)[0] == {
        582: SOURCE, 583: SECOND_SOURCE
    }
    event["merge_group"]["base_sha"] = HEAD
    with pytest.raises(group.OwnershipUnqualified):
        group.validate_parallel_snapshot(data, event, env, SECOND_HEAD)


def test_parallel_candidate_is_bound_to_all_native_predecessor_owners():
    data, event, env = parallel_fixture()
    env["PR_NUMBER"] = "9999"  # never an independent membership proof
    owners, protected_tip = group.validate_parallel_snapshot(
        data, event, env, SECOND_HEAD
    )
    assert owners == {582: SOURCE, 583: SECOND_SOURCE}
    assert protected_tip == BASE


@pytest.mark.parametrize("path,value", [
    ("mergeQueue.configuration.maximumEntriesToBuild", 9),
    ("mergeQueue.configuration.maximumEntriesToMerge", 5),
    ("mergeQueue.configuration.mergingStrategy", "HEADGREEN"),
    ("mergeQueue.configuration.mergeMethod", "MERGE"),
    ("mergeQueue.entries.pageInfo.hasNextPage", True),
    ("mergeQueue.entries.nodes.0.headCommit.parents.nodes", []),
    ("mergeQueue.entries.nodes.1.position", 3),
    ("mergeQueue.entries.nodes.1.baseCommit.oid", BASE),
    ("mergeQueue.entries.nodes.1.headCommit.parents.nodes", [{"oid": BASE}]),
    ("mergeQueue.entries.nodes.1.pullRequest.number", 582),
    ("mergeQueue.entries.nodes.1.pullRequest.headRepository.nameWithOwner", "other/repo"),
    ("mergeQueue.entries.nodes.1.pullRequest.state", "MERGED"),
    ("mergeQueue.entries.nodes.1.headCommit.tree.oid", "bogus"),
    ("defaultBranchRef.target.oid", "0" * 40),
    ("mergeQueue.entries.nodes.1.headCommit.oid", "8" * 40),
])
def test_parallel_group_refuses_non_native_or_incomplete_membership(path, value):
    data, event, env = parallel_fixture()
    set_path(data["repository"], path, value)
    with pytest.raises(group.OwnershipUnqualified):
        group.validate_parallel_snapshot(data, event, env, SECOND_HEAD)


@pytest.mark.parametrize("change", ["missing-owner", "foreign-owner", "ledger-row", "file-bytes", "base-present"])
def test_parallel_migrations_require_each_original_source_head_and_base_absence(change):
    owners, doc, files, read, calls = parallel_migration_fixture()
    if change == "missing-owner":
        del owners[583]
    elif change == "foreign-owner":
        doc["prefixes"]["0100"]["pr"] = 999
    original_read = read

    def modified_reader(query, variables):
        result = original_read(query, variables)
        if variables["ledger"].startswith(SECOND_SOURCE + ":"):
            if change == "ledger-row":
                result["repository"]["ledger"]["text"] = '{"prefixes":{}}'
            elif change == "file-bytes":
                result["repository"]["file0"]["oid"] = "0" * 40
            elif change == "base-present":
                result["repository"]["base0"] = {"__typename": "Blob", "oid": "0" * 40}
        return result

    if change:
        with pytest.raises(group.OwnershipUnqualified):
            group.validate_parallel_migrations(
                owners, BASE, doc, files, modified_reader,
                {"owner": "example", "name": "terminal"},
            )


def test_a_later_queue_candidate_may_include_only_predecessors_open_migration():
    """The #970-type group retains the earlier #1084 SQL, but its own source
    PR has none. The native predecessor must be authenticated, not discarded."""
    data, event, env = parallel_fixture()
    owners, tip = group.validate_parallel_snapshot(data, event, env, SECOND_HEAD)
    doc, source = migration_fixture()
    calls = []

    def reader(query, variables):
        calls.append((query, variables))
        return {"repository": source}

    qualified = group.validate_parallel_migrations(
        owners, tip, doc, {NAME: RAW}, reader,
        {"owner": "example", "name": "terminal"},
    )
    assert qualified == frozenset({582})
    assert len(calls) == 1
    assert calls[0][1]["ledger"] == SOURCE + ":supabase/migrations/RESERVATIONS.json"


def test_parallel_migration_attestation_reuses_existing_provenance_for_each_owner():
    owners, doc, files, read, calls = parallel_migration_fixture()
    proven = group.validate_parallel_migrations(
        owners, BASE, doc, files, read, {"owner": "example", "name": "terminal"}
    )
    assert proven == frozenset({582, 583})
    assert len(calls) == 2
    assert {v["ledger"] for _, v in calls} == {
        SOURCE + ":supabase/migrations/RESERVATIONS.json",
        SECOND_SOURCE + ":supabase/migrations/RESERVATIONS.json",
    }
    assert all(v["base_tree"] == BASE + ":supabase/migrations" for _, v in calls)
    assert all("... on Tree { entries { name type } }" in query for query, _ in calls)


def test_parallel_source_query_uses_immutable_membership_not_environment_hint(tmp_path, monkeypatch):
    data, event, env = parallel_fixture()
    owners, doc, files, read, source_calls = parallel_migration_fixture()
    event_path = tmp_path / "event.json"
    event_path.write_text(json.dumps(event))
    env.update(
        GITHUB_EVENT_PATH=str(event_path), GH_TOKEN="synthetic-token", PR_NUMBER="9999"
    )
    calls = []

    def reader(query, variables):
        calls.append((query, variables))
        if len(calls) == 1:
            return data
        return read(query, variables)

    monkeypatch.setattr(group, "graphql_reader", lambda token: reader)
    monkeypatch.setattr(
        group.subprocess, "check_output", lambda *args, **kwargs: SECOND_HEAD + "\n"
    )
    assert group.qualify_owner(tmp_path, env, doc, files) == frozenset({582, 583})
    assert len(calls) == 3
    assert "9999" not in str(calls) and "synthetic-token" not in str(calls)


def test_ingest_merge_group_membership_reads_are_minimal_privilege():
    """The denied candidate-token read is withheld, not retried or widened.
    Missing ownership still keeps strict namespace enforcement."""
    import yaml

    workflow = yaml.safe_load(
        (Path(__file__).resolve().parents[1] / ".github/workflows/ci.yml").read_text()
    )
    ingest = workflow["jobs"]["python"]
    assert ingest["name"] == "Ingest + signal-layer tests"
    assert ingest["permissions"] == {"contents": "read", "pull-requests": "read"}
    step = next(
        s for s in ingest["steps"]
        if s.get("run") == "python -m pytest tests/ -q"
    )
    assert step["env"]["GH_TOKEN"] == ""


def test_withheld_candidate_inlet_closed_tree_passes_open_prefix_refuses_before_network(tmp_path, monkeypatch):
    from test_supabase_migration_namespace import reservations_doc
    directory = tmp_path / "migrations"
    directory.mkdir()
    (directory / NAME).write_bytes(RAW)
    doc = reservations_doc(prefixes={"0099": copy.deepcopy(ROW)})
    ledger = tmp_path / "RESERVATIONS.json"
    ledger.write_text(json.dumps(doc))
    _, event, env = fixture()
    event_file = tmp_path / "original-event.json"
    event_file.write_text(json.dumps(event))
    env.update(GITHUB_EVENT_PATH=str(event_file), GH_TOKEN="", GITHUB_TOKEN="inert-no-fallback")
    # Disposable Git identity seam only; real qualifier/token inlet/namespace
    # owner run. The HTTP spy also catches accidental fallback/auth probing.
    monkeypatch.setattr(group.subprocess, "check_output", lambda *a, **k: HEAD)
    network = []
    def forbidden_network(*args, **kwargs):
        network.append(1)
        raise AssertionError("candidate must not attempt the denied read")
    monkeypatch.setattr(group.urllib.request, "urlopen", forbidden_network)
    findings, _, mode = collect_for_event(env, migrations_dir=directory, reservations=ledger)
    assert {f.code for f in findings} == {"MERGE_GROUP_OWNERSHIP_UNQUALIFIED", "OPEN_PR_STATE_WITH_FILE_PRESENT"}
    assert mode.startswith("STRICT") and network == []
    doc["prefixes"]["0099"]["pr_state"] = "merged"
    ledger.write_text(json.dumps(doc))
    findings, _, mode = collect_for_event(env, migrations_dir=directory, reservations=ledger)
    assert findings == [] and mode.startswith("STRICT") and network == []


def test_namespace_accepts_only_verified_parallel_owner_set(tmp_path, monkeypatch):
    directory, ledger = repo_fixture(tmp_path)
    (directory / SECOND_NAME).write_bytes(SECOND_RAW)
    doc = json.loads(ledger.read_text())
    doc["prefixes"]["0100"] = dict(ROW, pr=583, file=SECOND_NAME)
    ledger.write_text(json.dumps(doc))
    env = {"GITHUB_EVENT_NAME": "merge_group", "PR_NUMBER": "9999"}
    monkeypatch.setattr(group, "qualify_owner", lambda *args: frozenset({582, 583}))
    findings, _, mode = collect_for_event(
        env, migrations_dir=directory, reservations=ledger
    )
    assert not any(f.code.startswith("OPEN_PR_STATE") for f in findings)
    assert "MERGE_GROUP_PARALLEL" in mode
    monkeypatch.setattr(group, "qualify_owner", lambda *args: frozenset({582}))
    findings, _, _ = collect_for_event(env, migrations_dir=directory, reservations=ledger)
    assert any(f.code == "OPEN_PR_STATE_STALE" and f.prefix == "0100" for f in findings)
    findings, _, _ = collect_for_event(
        env, force_strict=True, migrations_dir=directory, reservations=ledger
    )
    assert sum(f.code == "OPEN_PR_STATE_WITH_FILE_PRESENT" for f in findings) == 2

