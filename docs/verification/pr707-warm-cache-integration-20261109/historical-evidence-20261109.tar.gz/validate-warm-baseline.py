from pathlib import Path
import subprocess,json,hashlib,datetime,time
repo=Path(__file__).resolve().parents[3];t=repo/'terminal';proof=Path(__file__).resolve().parent;out=proof/'warm-baseline-r1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def sources():return json.loads(subprocess.run(['node','-e',"console.log(JSON.stringify(require('./terminal/e2e/tools/visualEvidence.cjs').sourceSnapshot(process.cwd())))"],cwd=repo,capture_output=True,text=True,check=True).stdout)
assert not out.exists();out.mkdir()
assert sha(t/'lib/dataCache.ts')=='ce28db3a3bcb3425320ac7e6845df02be5d21daebfa084756830c631623c7a3a'
before=sources();put(out/'source-before.json',before)
command=['node','node_modules/vitest/vitest.mjs','run','lib/__tests__/dataCacheWarmRefresh.test.ts','--pool=forks','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(out/'unit-report.json')]
start=time.monotonic()
with (out/'units.log').open('x') as log:r=subprocess.run(command,cwd=t,stdout=log,stderr=subprocess.STDOUT)
after=sources();put(out/'source-after.json',after);assert before==after
report=json.loads((out/'unit-report.json').read_text())
failed=[{'name':a['fullName'],'messages':a.get('failureMessages',[])} for suite in report['testResults'] for a in suite.get('assertionResults',[]) if a['status']=='failed']
record={'schema':'terminal_pr707_current_cache_baseline.v1','state':'BASELINE_FAILED_REVIEW_REQUIRED' if failed else 'BASELINE_PASSED','command':command,'exit':r.returncode,'seconds':round(time.monotonic()-start,2),'sourceEntries':len(before),'sourceStable':True,'cacheSha256':sha(t/'lib/dataCache.ts'),'testSha256':sha(t/'lib/__tests__/dataCacheWarmRefresh.test.ts'),'stats':{k:report.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']},'failed':failed,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
put(out/'execution.json',record);print(json.dumps(record),flush=True)
