# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portfolio-targets.spec.ts >> target feedback is actionable and accessible on settings (zh)
- Location: e2e/portfolio-targets.spec.ts:242:9

# Error details

```
Error: locator.click: Test ended.
Call log:
  - waiting for locator('button[aria-label="设置"]:visible').first()
    - locator resolved to <button title="设置" class="avatar" aria-label="设置" aria-haspopup="dialog">U</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - element is outside of the viewport
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - element is outside of the viewport
    - retrying click action
      - waiting 100ms
    123 × waiting for element to be visible, enabled and stable
        - element is visible, enabled and stable
        - scrolling into view if needed
        - done scrolling
        - element is outside of the viewport
      - retrying click action
        - waiting 500ms

```

# Test source

```ts
  154 |   for (const lang of ["en", "zh"] as const) {
  155 |     test("orphan clear from " + surface + " persists after reload (" + lang + ")", async ({ page, baseURL }, testInfo) => {
  156 |       await prepare(page, testInfo, baseURL, lang === "zh");
  157 |       const errors: string[] = [];
  158 |       page.on("pageerror", error => errors.push(error.message));
  159 |       const nvda = await seedPosition(page, { ticker: "NVDA", shares: "100", entryPrice: "200" });
  160 |       const saved = await page.request.post("/api/portfolio/targets", {
  161 |         data: { action: "set", ticker: "NVDA", targetWeightPct: 80, bandPct: 5 },
  162 |       });
  163 |       expect(saved.ok()).toBe(true);
  164 |       // Exercise both ways a target loses its holding, without changing the retention contract.
  165 |       const ended = await page.request.post("/api/portfolio", {
  166 |         data: { action: surface === "portfolio" ? "close" : "delete", id: nvda.id },
  167 |       });
  168 |       expect(ended.ok()).toBe(true);
  169 |       const beforeTargets = await page.request.get("/api/portfolio/targets");
  170 |       expect(beforeTargets.ok()).toBe(true);
  171 |       expect((await beforeTargets.json()).summary.orphaned).toEqual([
  172 |         expect.objectContaining({ ticker: "NVDA", targetWeightPct: 80, bandPct: 5 }),
  173 |       ]);
  174 |       const beforePositions = await page.request.get("/api/portfolio?view=positions");
  175 |       expect(beforePositions.ok()).toBe(true);
  176 |       const positions = (await beforePositions.json()).positions;
  177 | 
  178 |       const enterSurface = async () => {
  179 |         if (surface === "portfolio") {
  180 |           await page.locator("#portfolio-tab-targets").click();
  181 |         } else {
  182 |           await page.locator('button[aria-label="' + (lang === "en" ? "Settings" : "设置") + '"]:visible').first().click();
  183 |           await page.getByRole("tab", {
  184 |             name: lang === "en" ? "Portfolio targets" : "组合目标权重", exact: true,
  185 |           }).click();
  186 |         }
  187 |       };
  188 |       await page.goto(surface === "portfolio" ? "/portfolio" : "/terminal?symbol=NVDA");
  189 |       await enterSurface();
  190 |       const orphaned = page.getByTestId("targets-orphaned");
  191 |       const row = orphaned.locator('[data-ticker="NVDA"][data-status="orphaned"]');
  192 |       await expect(row).toBeVisible();
  193 |       await expect(row).toContainText("80%");
  194 |       await expect(row).toContainText(lang === "en" ? "±5 pts" : "±5 个百分点");
  195 |       await expect(row.locator("input")).toHaveCount(0);
  196 |       const clear = row.getByRole("button", { name: (lang === "en" ? "Clear target" : "清除目标") + ": NVDA", exact: true });
  197 |       await expect(clear).toBeEnabled();
  198 |       await clear.scrollIntoViewIfNeeded();
  199 |       const rect = await clear.boundingBox();
  200 |       expect(rect).not.toBeNull();
  201 |       expect(rect!.x).toBeGreaterThanOrEqual(0);
  202 |       expect(rect!.x + rect!.width).toBeLessThanOrEqual(page.viewportSize()!.width + 1);
  203 |       expect(rect!.height).toBeGreaterThanOrEqual(testInfo.project.name === "mobile" ? 44 : 32);
  204 |       const captureDirectory = process.env.PORTFOLIO_ORPHAN_CAPTURE_DIRECTORY;
  205 |       if (captureDirectory) {
  206 |         await mkdir(captureDirectory, { recursive: true });
  207 |         await section(page).screenshot({
  208 |           path: join(captureDirectory, testInfo.project.name + "-" + surface + "-" + lang + ".png"),
  209 |           animations: "disabled",
  210 |         });
  211 |       }
  212 | 
  213 |       const clearing = page.waitForResponse(response =>
  214 |         new URL(response.url()).pathname === "/api/portfolio/targets" && response.request().method() === "POST");
  215 |       await clear.click();
  216 |       const cleared = await clearing;
  217 |       expect(cleared.request().postDataJSON()).toMatchObject({ action: "clear", ticker: "NVDA" });
  218 |       expect(cleared.ok()).toBe(true);
  219 |       expect(await cleared.json()).toMatchObject({ ok: true, clearedTicker: "NVDA" });
  220 |       await expect(row).toHaveCount(0);
  221 |       const empty = page.getByTestId(surface === "portfolio" ? "targets-empty" : "portfolio-targets-empty");
  222 |       await expect(empty).toBeVisible();
  223 |       const afterTargets = await page.request.get("/api/portfolio/targets");
  224 |       expect(afterTargets.ok()).toBe(true);
  225 |       expect((await afterTargets.json()).summary).toMatchObject({ orphaned: [], drifts: [], untargeted: [] });
  226 | 
  227 |       await page.reload();
  228 |       await enterSurface();
  229 |       await expect(empty).toBeVisible();
  230 |       await expect(page.getByTestId("targets-orphaned")).toHaveCount(0);
  231 |       const afterPositions = await page.request.get("/api/portfolio?view=positions");
  232 |       expect(afterPositions.ok()).toBe(true);
  233 |       expect((await afterPositions.json()).positions).toEqual(positions);
  234 |       expect(errors).toEqual([]);
  235 |       await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  236 |     });
  237 |   }
  238 | }
  239 | 
  240 | for (const surface of ["portfolio", "settings"] as const) {
  241 |   for (const lang of ["en", "zh"] as const) {
  242 |     test("target feedback is actionable and accessible on " + surface + " (" + lang + ")", async ({ page, baseURL }, testInfo) => {
  243 |       await prepare(page, testInfo, baseURL, lang === "zh");
  244 |       const errors: string[] = [];
  245 |       page.on("pageerror", error => errors.push(error.message));
  246 |       await seedPosition(page, { ticker: "NVDA", shares: "100", entryPrice: "200" });
  247 |       const saved = await page.request.post("/api/portfolio/targets", {
  248 |         data: { action: "set", ticker: "NVDA", targetWeightPct: 80, bandPct: 5 },
  249 |       });
  250 |       expect(saved.ok()).toBe(true);
  251 |       await page.goto("/portfolio");
  252 |       await page.locator("#portfolio-tab-targets").click();
  253 |       if (surface === "settings") {
> 254 |         await page.locator('button[aria-label="' + (lang === "en" ? "Settings" : "设置") + '"]:visible').first().click();
      |                                                                                                                ^ Error: locator.click: Test ended.
  255 |         await page.getByRole("tab", {
  256 |           name: lang === "en" ? "Portfolio targets" : "组合目标权重", exact: true,
  257 |         }).click();
  258 |       }
  259 |       const scope = surface === "settings" ? page.getByRole("dialog") : page.getByRole("main");
  260 |       const row = scope.locator('article[data-ticker="NVDA"]');
  261 |       const target = row.getByLabel(lang === "en" ? "Target weight for NVDA, percent" : "NVDA 的目标权重，百分比");
  262 |       const band = row.getByLabel(lang === "en" ? "Band for NVDA, percentage points" : "NVDA 的容忍区间，百分点");
  263 |       await expect(target).toHaveValue("80");
  264 |       const refusal = page.waitForResponse(response =>
  265 |         new URL(response.url()).pathname === "/api/portfolio/targets" && response.request().method() === "POST");
  266 |       await target.fill("101");
  267 |       expect((await refusal).status()).toBe(400);
  268 |       const alert = row.getByRole("alert");
  269 |       await expect(alert).toHaveText(lang === "en"
  270 |         ? "A target has to be a number from 0 to 100."
  271 |         : "目标权重必须是 0 到 100 之间的数字。");
  272 |       await expect(target).toHaveValue("80");
  273 |       await expect(target).not.toHaveAttribute("aria-invalid", "true");
  274 |       const errorId = await alert.getAttribute("id");
  275 |       expect(errorId).toBeTruthy();
  276 |       await expect(target).toHaveAttribute("aria-describedby", errorId!);
  277 |       await expect(band).not.toHaveAttribute("aria-invalid", "true");
  278 | 
  279 |       const captureDirectory = process.env.PORTFOLIO_TARGET_FEEDBACK_CAPTURE_DIRECTORY;
  280 |       if (captureDirectory) {
  281 |         await mkdir(captureDirectory, { recursive: true });
  282 |         const originalTheme = await page.locator("html").getAttribute("data-theme");
  283 |         for (const theme of ["dark", "light"]) {
  284 |           await page.evaluate(value => document.documentElement.setAttribute("data-theme", value), theme);
  285 |           await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  286 |           await row.screenshot({
  287 |             path: join(captureDirectory, testInfo.project.name + "-" + surface + "-" + lang + "-" + theme + ".png"),
  288 |             animations: "disabled",
  289 |           });
  290 |         }
  291 |         await page.evaluate(value => {
  292 |           if (value === null) document.documentElement.removeAttribute("data-theme");
  293 |           else document.documentElement.setAttribute("data-theme", value);
  294 |         }, originalTheme);
  295 |       }
  296 | 
  297 |       await band.fill("abc");
  298 |       await expect(alert).toHaveText(lang === "en"
  299 |         ? "Your band has to be a number from 0 to 50 points."
  300 |         : "容忍区间必须是 0 到 50 个百分点之间的数字。");
  301 |       await expect(band).toHaveAttribute("aria-invalid", "true");
  302 |       await expect(band).toHaveAttribute("aria-describedby", errorId!);
  303 |       await expect(band).toBeFocused();
  304 |       await expect(target).not.toHaveAttribute("aria-describedby", errorId!);
  305 |       await band.fill("7");
  306 |       await expect(alert).toHaveCount(0);
  307 |       await expect(band).not.toHaveAttribute("aria-invalid", "true");
  308 |       await expect(band).not.toHaveAttribute("aria-describedby", errorId!);
  309 |       await expect(row).toContainText(lang === "en" ? "Saved" : "已保存");
  310 |       await expect(band).toHaveValue("7");
  311 |       const canonical = await page.request.get("/api/portfolio/targets");
  312 |       expect(canonical.ok()).toBe(true);
  313 |       expect((await canonical.json()).summary.drifts).toEqual([
  314 |         expect.objectContaining({ ticker: "NVDA", targetWeightPct: 80, bandPct: 7 }),
  315 |       ]);
  316 |       expect(errors).toEqual([]);
  317 |       await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  318 |     });
  319 |   }
  320 | }
  321 | 
```