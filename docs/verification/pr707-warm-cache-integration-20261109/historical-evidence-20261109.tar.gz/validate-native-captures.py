from pathlib import Path
import subprocess,json,hashlib,os,time,datetime,shutil,stat
repo=Path(__file__).resolve().parents[3];t=repo/'terminal';proof=Path(__file__).resolve().parent;out=proof;port=3908
head='0b48ac7f699b99fce10fd76d64d7c278cd23e9d2';base='156c4b3ecfa27b9137c64068b3ed969e07efbe49';dependency='0fd27ff1dfb7e031457a4ffe4c05458587c4eb81'
def git(*a):return subprocess.run(['git','-C',str(repo),*a],capture_output=True,text=True,check=True).stdout.strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def inspect(args):
 r=subprocess.run(args,capture_output=True,text=True);return {'command':args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'observedAt':now()}
def port_closed(port):
 r=inspect(['lsof','-nP','-iTCP:'+str(port),'-sTCP:LISTEN']);assert r['exit'] in [0,1] and not r['stderr'].strip();return r['exit']==1
def reconcile_lock(port,label,extraPids=[]):
 lock=t/'.next/dev/lock'
 for _ in range(40):
  if port_closed(port):break
  time.sleep(.25)
 assert port_closed(port),'Owned listener remains live'
 if not lock.exists():return {'initialLockPresent':False,'serverAbsenceVerifiedAt':now()}
 def identity():
  st=lock.lstat();assert stat.S_ISREG(st.st_mode) and st.st_uid==501
  return {'dev':st.st_dev,'ino':st.st_ino,'size':st.st_size,'mtimeNs':st.st_mtime_ns,'sha256':sha(lock),'content':json.loads(lock.read_text())}
 initial=identity();assert initial['content']['port']==port
 pids=[initial['content']['pid'],*extraPids]
 def observations(withFd):
  checks={}
  for name,args in [('listener',['lsof','-nP','-iTCP:'+str(port),'-sTCP:LISTEN']),('recordedProcesses',['ps','-p',','.join(str(x) for x in pids),'-o','pid=,ppid=,comm='])]:
   r=inspect(args);checks[name]=r;assert r['exit']==1 and not r['stdout'].strip() and not r['stderr'].strip(),checks
  if withFd:
   r=inspect(['lsof',str(lock)]);checks['lockDescriptors']=r;assert r['exit']==1 and not r['stdout'].strip() and not r['stderr'].strip()
  else:assert not lock.exists();checks['lockDescriptors']={'state':'fileAbsent','observedAt':now()}
  r=inspect(['lsof','-a','-u','chriswong','-d','cwd','-F','pcn']);cur=[];records=[]
  for line in r['stdout'].splitlines():
   if line.startswith('p'):
    if any(x.startswith('n'+str(repo)) for x in cur):records.append(cur)
    cur=[line]
   else:cur.append(line)
  if any(x.startswith('n'+str(repo)) for x in cur):records.append(cur)
  checks['ownedWorkspaceCwds']={k:v for k,v in r.items() if k!='stdout'};checks['ownedWorkspaceCwds']['records']=records
  assert r['exit']==0 and not r['stderr'].strip() and not records
  return checks
 receipt={'schema':'terminal_pr707_browser_lifecycle_reconciliation.v1','label':label,'startedAt':now(),'initialLockPresent':True,'initialLock':initial,'before':observations(True),'state':'ABSENCE_VERIFIED_PENDING_UNLINK'}
 file=out/(label+'-lifecycle.json');assert not file.exists();put(file,receipt)
 assert identity()==initial;receipt['immediatelyBeforeUnlink']=observations(True);assert identity()==initial;put(file,receipt)
 lock.unlink();assert not lock.exists();receipt['after']=observations(False);receipt['state']='STALE_OWNED_LOCK_REMOVED_SERVER_ABSENCE_VERIFIED';receipt['completedAt']=now();put(file,receipt)
 return {'initialLockPresent':True,'reconciliation':str(file.relative_to(repo)),'sha256':sha(file),'serverAbsenceVerifiedAt':receipt['completedAt']}



assert git('rev-parse','HEAD')==head and git('rev-parse','MERGE_HEAD')==dependency
assert json.loads((proof/'current-browser-r2/execution.json').read_text())['state']=='QUALIFIED'
assert json.loads((proof/'type-lint-r1/execution.json').read_text())['state']=='QUALIFIED'
assert all(port_closed(p) for p in [3564,3566,3543,3546]) and not(t/'.next/dev/lock').exists()
out=proof/'native-captures-r1';assert not out.exists();out.mkdir()
def sources():return json.loads(subprocess.run(['node','-e',"console.log(JSON.stringify(require('./terminal/e2e/tools/visualEvidence.cjs').sourceSnapshot(process.cwd())))"],cwd=repo,capture_output=True,text=True,check=True).stdout)
before=sources();put(out/'source-before.json',before)
env=os.environ.copy();env.update({'MMX_SHARED_SHELL':'0','MMX_INVESTOR_SHELL_PREVIEW':'0','PLAYWRIGHT_BROWSERS_PATH':str(t/'node_modules/.cache/pr1268-playwright')})
record={'schema':'terminal_pr707_native_packet_qualification.v1','state':'RUNNING','startedAt':now(),'head':head,'dependency':dependency,'protectedMaster':base,'sourceEntries':len(before),'packets':{},'fixture':True,'productionProof':False}
def save():put(out/'execution.json',record)
save()
for name,port,count in [('gex',3564,114),('eod',3566,126),('b5',3543,32),('w9t',3546,8)]:
 assert port_closed(port) and not(t/'.next/dev/lock').exists()
 assert sources()==before
 command=['node',str(proof/'capture-native-packet.cjs'),name];start=time.monotonic()
 print(json.dumps({'startingNative':name,'expectedImages':count,'port':port}),flush=True)
 with (out/(name+'-wrapper.log')).open('x') as log:r=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 d=json.loads((out/name/'execution.json').read_text());packet={'exit':r.returncode,'seconds':round(time.monotonic()-start,2),'state':d['state'],'expectedImages':count,'sourceStable':sources()==before,'record':str((out/name/'execution.json').relative_to(repo))}
 record['packets'][name]=packet;save()
 result=d.get('result',{})
 if result.get('closed') and result.get('serverSettled') and (name!='w9t' or d.get('callerServer',{}).get('state')=='SETTLED'):
  extra=[x for x in [result.get('pid'),result.get('serverPid'),d.get('callerServer',{}).get('pid')] if x]
  packet['lifecycle']=reconcile_lock(port,'native-'+name,extra);packet['portClosed']=port_closed(port);packet['nextLockAbsent']=not(t/'.next/dev/lock').exists();save()
 good=r.returncode==0 and d['state']=='CAPTURED_CURRENT_COMPLETE_PENDING_NATIVE_READER' and packet['sourceStable'] and packet.get('portClosed') and packet.get('nextLockAbsent') and len(d.get('crops',[]))==count
 print(json.dumps({'nativeResult':name,**packet}),flush=True)
 if not good:
  record['state']='FAILED_OR_UNSETTLED';record['completedAt']=now();save();print((out/(name+'-wrapper.log')).read_text()[-10000:],flush=True);raise SystemExit(1)
after=sources();put(out/'source-after.json',after);assert before==after
tests=['lib/__tests__/gexLevelsHeatmapLoadFailureEvidence.test.ts','lib/__tests__/eodHeatmapFlowdeskLoadFailureEvidence.test.ts','lib/__tests__/b_f08_b5_1TargetsEvidence.test.ts','lib/__tests__/w9t_f08_13TargetsReadoutEvidence.test.ts']
cmd=['node','node_modules/vitest/vitest.mjs','run',*tests,'--pool=forks','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(out/'native-reader-report.json')];start=time.monotonic()
with (out/'native-readers.log').open('x') as log:r=subprocess.run(cmd,cwd=t,env=env,stdout=log,stderr=subprocess.STDOUT)
report=json.loads((out/'native-reader-report.json').read_text());record['nativeReaders']={'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-start,2),'stats':{k:report.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']}}
record['state']='ALL_280_NATIVE_CAPTURES_AND_READERS_QUALIFIED' if r.returncode==0 and sources()==before else 'NATIVE_READER_FAILED';record['completedAt']=now();save();print(json.dumps(record),flush=True)
if r.returncode:print((out/'native-readers.log').read_text()[-10000:],flush=True)
raise SystemExit(0 if record['state']=='ALL_280_NATIVE_CAPTURES_AND_READERS_QUALIFIED' else 1)
