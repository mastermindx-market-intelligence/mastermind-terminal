# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: sector-cycle-lens.spec.ts >> cycles tick precision survives fullscreen tiny en dark
- Location: e2e/sector-cycle-lens.spec.ts:110:9

# Error details

```
Error: SVG coordinates must follow the current measured content width

SVG coordinates must follow the current measured content width

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 1
Received:    500

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e3]:
      - strong [ref=e4]: DEV harness · SectorCycleLens
      - generic [ref=e5]: Fixture data — not live evidence
      - generic [ref=e6]:
        - radio "EN" [checked] [ref=e7]
        - text: EN
      - generic [ref=e8]:
        - radio "ZH" [ref=e9]
        - text: ZH
      - generic [ref=e10]:
        - radio "Dark" [checked] [ref=e11]
        - text: Dark
      - generic [ref=e12]:
        - radio "Light" [ref=e13]
        - text: Light
      - generic [ref=e14]:
        - text: Axis fixture
        - combobox "Axis fixture" [ref=e15]:
          - option "Standard history"
          - option "Tiny values (0 to 0.01)" [selected]
          - option "Fractional ticks (-4 to 4)"
      - generic [ref=e16]:
        - radio "Generation current" [checked] [ref=e17]
        - text: Generation current
      - generic [ref=e18]:
        - radio "Generation replaced" [ref=e19]
        - text: Generation replaced
      - generic [ref=e20]:
        - radio "Heads today" [checked] [ref=e21]
        - text: Heads today
      - generic [ref=e22]:
        - radio "One head withdrawn" [ref=e23]
        - text: One head withdrawn
      - generic [ref=e24]:
        - radio "Heads absent" [ref=e25]
        - text: Heads absent
    - generic [ref=e26]:
      - generic [ref=e28]:
        - heading "Sector cycles" [level=2] [ref=e29]
        - paragraph [ref=e30]: Technology XLK · As of 2026-10-30 · Sector ETFs vs SPY · reconstructed price history
      - generic [ref=e32]:
        - generic [ref=e33]:
          - generic [ref=e34]:
            - heading "Technology XLK" [level=3] [ref=e35]
            - generic [ref=e36]:
              - generic [ref=e37]: "Cycle phase · ontology: Expansion"
              - generic [ref=e38]: Position · ontology 72
              - generic [ref=e39]:
                - text: Price vs 200-session average
                - generic [ref=e40]: Above
            - paragraph [ref=e41]: 0–100 scale. Not a probability.
          - generic [ref=e42]:
            - button "Change series" [ref=e43] [cursor=pointer]
            - button "Open sector dossier" [ref=e44] [cursor=pointer]
        - generic [ref=e45]:
          - heading "Clocks" [level=4] [ref=e46]
          - generic [ref=e47]:
            - generic [ref=e48]: phase clock
            - generic [ref=e49]: timing ladder
            - generic [ref=e50]: hazard clock
            - generic "Each disagreeing clock's own values are kept in the provenance drawer." [ref=e51]: rhythm clock ⚠
            - generic [ref=e52]: cycle read
          - paragraph [ref=e53]: Each disagreeing clock's own values are kept in the provenance drawer.
        - generic [ref=e54]:
          - heading "Strength vs SPY" [level=3] [ref=e56]
          - generic [ref=e57]:
            - button "Series (5)" [ref=e58] [cursor=pointer]: Series (5)＋
            - generic [ref=e59]:
              - text: Chart range
              - combobox "Chart range" [ref=e60]:
                - option "21 sessions"
                - option "63 sessions"
                - option "252 sessions"
                - option "All" [selected]
            - generic [ref=e61]:
              - text: Scale
              - combobox "Scale" [ref=e62]:
                - option "Linear" [selected]
                - option "Log" [disabled]
            - group "Strength vs SPY" [ref=e63]:
              - button "Chart" [pressed] [ref=e64] [cursor=pointer]
              - button "Data table" [ref=e65] [cursor=pointer]
            - button "Full screen" [ref=e66] [cursor=pointer]: Full screen⤢
          - generic [ref=e67]:
            - generic [ref=e68]:
              - text: XLK · 21 sessions
              - generic [ref=e70]: total return
            - generic [ref=e71]:
              - text: XLK · 63 sessions
              - generic [ref=e73]: total return
          - generic [ref=e74]:
            - generic [ref=e75]:
              - generic [ref=e76]:
                - text: XLK · 21 sessions
                - strong [ref=e77]: +0.0%
              - generic [ref=e78]:
                - text: XLK · 63 sessions
                - strong [ref=e79]: +0.0%
              - time [ref=e80]: 2026-05-02
            - img "Strength vs SPY" [ref=e82]:
              - generic [ref=e84]: "0.000"
              - generic [ref=e86]: "0.005"
              - generic [ref=e88]: "0.010"
              - generic "2025-09-13 · trough" [ref=e91]
              - generic "2025-11-12 · peak" [ref=e93]
              - generic "2026-01-21 · trough" [ref=e95]
              - generic "2026-03-12 · peak · Provisional" [ref=e97]
              - generic [ref=e99]: trough 2025-09-13
              - generic [ref=e100]: peak 2025-11-12
              - generic [ref=e101]: trough 2026-01-21
              - generic [ref=e102]: peak 2026-03-12
              - generic [ref=e105]: 2025-08-24
              - generic [ref=e106]: 2025-09-17
              - generic [ref=e107]: 2025-10-11
              - generic [ref=e108]: 2025-11-04
              - generic [ref=e109]: 2025-11-28
              - generic [ref=e110]: 2025-12-22
              - generic [ref=e111]: 2026-01-15
              - generic [ref=e112]: 2026-02-08
              - generic [ref=e113]: 2026-03-04
              - generic [ref=e114]: 2026-03-28
              - generic [ref=e115]: 2026-05-02
            - slider "Observation date" [ref=e116]: "251"
            - generic [ref=e117]:
              - generic [ref=e118]: 2025-08-24
              - generic [ref=e119]: 2026-05-02
          - generic [ref=e120]:
            - heading "Price turns" [level=4] [ref=e121]
            - paragraph [ref=e122]: Turn dates are pivot dates. A turn becomes known only at confirmation — the two dates are kept distinct.
            - generic [ref=e123]:
              - time [ref=e124]: 2026-03-12
              - generic [ref=e125]: Peak
              - emphasis [ref=e126]: Provisional
            - generic [ref=e127]:
              - time [ref=e128]: 2026-01-21
              - generic [ref=e129]: Trough
              - emphasis [ref=e130]: Confirmed
              - emphasis [ref=e131]: · first known 2026-01-24
            - generic [ref=e132]:
              - time [ref=e133]: 2025-11-12
              - generic [ref=e134]: Peak
              - emphasis [ref=e135]: Confirmed
              - emphasis [ref=e136]: · first known 2025-11-15
          - group [ref=e137]:
            - generic "Exact values" [ref=e138] [cursor=pointer]
          - group [ref=e139]:
            - generic "Method" [ref=e140]
        - generic [ref=e141]:
          - heading "Leg timeline" [level=3] [ref=e142]
          - list [ref=e144]:
            - listitem [ref=e145]:
              - button "2025-09-13 → 2025-11-12" [ref=e146] [cursor=pointer]:
                - generic [ref=e147]: 2025-09-13 → 2025-11-12
                - generic [ref=e148]: ▲
            - listitem [ref=e149]:
              - button "2025-11-12 → 2026-01-21" [ref=e150] [cursor=pointer]:
                - generic [ref=e151]: 2025-11-12 → 2026-01-21
                - generic [ref=e152]: ▼
            - listitem [ref=e153]:
              - button "2026-01-21 → 2026-03-12 · Provisional" [ref=e154] [cursor=pointer]:
                - generic [ref=e155]: 2026-01-21 → 2026-03-12 · Provisional
                - generic [ref=e156]: ▲
            - listitem [ref=e157]:
              - button "2026-03-12 · Open leg · Open · 51 sessions" [ref=e158] [cursor=pointer]:
                - generic [ref=e159]: 2026-03-12 · Open leg · Open · 51 sessions
                - generic [ref=e160]: ▼
        - generic [ref=e161]:
          - generic [ref=e162]:
            - heading "The read" [level=3] [ref=e163]
            - paragraph [ref=e164]: The production read names a different phase family than the phase clock; it is kept verbatim in the provenance drawer and is not drawn as the current read.
          - generic [ref=e165]:
            - heading "Rotation events" [level=3] [ref=e166]
            - paragraph [ref=e167]: No closed rotation episodes in this window
        - generic [ref=e168]:
          - generic [ref=e169]:
            - heading "Turn estimate & priors" [level=3] [ref=e170]
            - group "Turn hazard (historical qualification only)" [ref=e171]:
              - heading "Turn hazard (historical qualification only)" [level=4] [ref=e172]
              - generic [ref=e173]:
                - generic [ref=e174]: P(turn ≤ 1m)
                - generic [ref=e175]: ≤3m
                - generic [ref=e176]: ≤6m
                - generic [ref=e177]: an up leg · peak
                - generic [ref=e178]:
                  - generic [ref=e179]: 18%
                  - generic [ref=e180]: MODEL
                - generic [ref=e181]:
                  - generic [ref=e182]: 34%
                  - generic [ref=e183]: PRIOR
                - generic [ref=e184]:
                  - generic [ref=e185]: 41%
                  - generic [ref=e186]: MODEL
              - paragraph [ref=e187]: "PRIOR: historical base rate, not a model"
          - generic [ref=e188]:
            - generic [ref=e189]:
              - heading "Methods and limits" [level=3] [ref=e190]
              - list [ref=e191]:
                - listitem [ref=e192]: "Position sizing: none. The conviction multiplier is held at 1.0 and is not a size."
                - listitem [ref=e193]: Own rhythm, descriptive. Not a model.
                - listitem [ref=e194]: "Lead-lag: no claim. The lead-lag study stopped; nothing here orders sectors in time."
                - listitem [ref=e195]: Source parity holds; model qualifications remain separate
              - group [ref=e196]:
                - generic "Evidence details" [ref=e197] [cursor=pointer]
            - generic [ref=e198]:
              - paragraph [ref=e199]: Conviction-call grader
              - 'heading "Conviction-call grader: measured hit rate" [level=3] [ref=e200]'
              - paragraph [ref=e201]: Conviction-call hit rate over all resolved calls, Neutral included. Not a win rate.
              - paragraph [ref=e202]: Realized directional hit-rate, cross-sectional rank-IC and excess-vs-SPY of the conviction calls, by horizon. Sparse until it accrues; never fed back into the live score.
              - paragraph [ref=e203]: Grader unavailable in this generation
          - generic [ref=e204]:
            - heading "Timing & projection" [level=3] [ref=e205]
            - paragraph [ref=e206]: ◷18 sessions in this phase
            - paragraph [ref=e207]:
              - text: Price vs 200-session average Above
              - generic [ref=e208]: UPTREND
            - paragraph [ref=e209]: Time in phase is a measured historical fact — not remaining upside, and not a time limit.
            - generic [ref=e210]:
              - generic [ref=e211]:
                - generic [ref=e212]: Descriptive rhythm
                - generic [ref=e213]: Window has not opened
              - paragraph [ref=e214]: Next trough ≈ Feb ’27
              - generic [ref=e215]:
                - generic [ref=e216]:
                  - term [ref=e217]: earliest
                  - definition [ref=e218]: Dec ’26
                - generic [ref=e219]:
                  - term [ref=e220]: central
                  - definition [ref=e221]: Feb ’27
                - generic [ref=e222]:
                  - term [ref=e223]: latest
                  - definition [ref=e224]: Apr ’27
              - paragraph [ref=e225]: "Projected next trough ≈ Feb ’27 (Dec ’26–Apr ’27), from this sector's own median half-cycle: a descriptive rhythm, not a model, and a timing window, not a guarantee."
        - generic [ref=e226]:
          - heading "Remaining-opportunity forecasts" [level=3] [ref=e227]
          - list [ref=e228]:
            - listitem [ref=e229]:
              - generic [ref=e230]: Remaining return
              - generic [ref=e231]: Withheld
              - generic [ref=e232]: "Withheld: the research test failed this forecast on current data"
              - generic [ref=e233]: "Horizon: 20 completed sessions"
              - group [ref=e234]:
                - generic "Evidence" [ref=e235]
            - listitem [ref=e236]:
              - generic [ref=e237]: Adverse tail
              - generic [ref=e238]: Withheld
              - generic [ref=e239]: "Withheld: live cycle state does not match the research protocol's turn epoch"
              - generic [ref=e240]: "Horizon: 20 completed sessions"
              - group [ref=e241]:
                - generic "Evidence" [ref=e242]
            - listitem [ref=e243]:
              - generic [ref=e244]: Target before invalidation
              - generic [ref=e245]: Withheld
              - generic [ref=e246]: "Withheld: live cycle state does not match the research protocol's turn epoch"
              - generic [ref=e247]: "Horizon: 20 completed sessions"
              - generic [ref=e248]: "Leg-direction fact: what the current up/down leg tends to reach, not a cycle-timing edge."
              - group [ref=e249]:
                - generic "Evidence" [ref=e250]
            - listitem [ref=e251]:
              - generic [ref=e252]: Transition time
              - generic [ref=e253]: Withheld
              - generic [ref=e254]: "Withheld: live cycle state does not match the research protocol's turn epoch"
              - generic [ref=e255]: "Horizon: 20 completed sessions"
              - group [ref=e256]:
                - generic "Evidence" [ref=e257]
          - paragraph [ref=e258]: No estimate is shown for a withheld forecast.
          - paragraph [ref=e259]: Each forecast is withheld on its own; the observed cycle facts above are unaffected.
        - paragraph [ref=e260]: Descriptive evidence. No stock recommendation, sizing or execution authority.
      - dialog "Cycles fullscreen" [active] [ref=e262]:
        - generic [ref=e263]:
          - paragraph [ref=e264]: Strength vs SPY
          - generic [ref=e265]:
            - group "Strength vs SPY" [ref=e266]:
              - button "Chart" [pressed] [ref=e267] [cursor=pointer]
              - button "Data table" [ref=e268] [cursor=pointer]
            - button "Close fullscreen" [ref=e269] [cursor=pointer]: ✕
        - img "Strength vs SPY" [ref=e270]:
          - generic [ref=e272]: "0.0000"
          - generic [ref=e274]: "0.0025"
          - generic [ref=e276]: "0.0050"
          - generic [ref=e278]: "0.0075"
          - generic [ref=e280]: "0.0100"
          - generic "2025-09-13 · trough · first known 2025-09-16" [ref=e283]
          - generic "2025-11-12 · peak · first known 2025-11-15" [ref=e284]
          - generic "2026-01-21 · trough · first known 2026-01-24" [ref=e285]
          - generic "2026-03-12 · peak · Provisional" [ref=e286]
          - generic [ref=e287]: trough 2025-09-13
          - generic [ref=e288]: peak 2026-03-12
        - generic [ref=e291]:
          - time [ref=e292]: 2026-05-02
          - generic [ref=e293]:
            - text: XLK · 21 sessions
            - strong [ref=e294]: +0.0%
          - generic [ref=e295]:
            - text: XLK · 63 sessions
            - strong [ref=e296]: +0.0%
  - alert [ref=e297]
```

# Test source

```ts
  1   | import { test, expect, type Locator } from "@playwright/test";
  2   | 
  3   | /* Cycles lane e2e — the /dev/sector-cycles harness (deterministic inline
  4   |  * fixtures, no network, clearly labelled as fixture data on the page itself).
  5   |  *
  6   |  * Charter gate 4: keyboard and touch through family/phase/range/scale/leg
  7   |  * selection, chart↔table equivalence, capture→navigate→apply return, at
  8   |  * 1440×900, 820×1180 and 390×844 (desktop/tablet/mobile), light+dark, EN+ZH.
  9   |  * The self-bound return router is exercised for real: leaving a subject
  10  |  * pushes its captured view onto the history entry being left; the browser
  11  |  * back button rebinds that subject (donor #10707 host contract) and the
  12  |  * two-phase codec restores the captured fields. */
  13  | 
  14  | const cases = [
  15  |   ["en", "dark"],
  16  |   ["zh", "light"],
  17  | ] as const;
  18  | 
  19  | const T = (lang: "en" | "zh") => ({
  20  |   chart: lang === "zh" ? "图表" : "Chart",
  21  |   table: lang === "zh" ? "数据表" : "Data table",
  22  |   range: lang === "zh" ? "图表范围" : "Chart range",
  23  |   log: lang === "zh" ? "对数" : "Log",
  24  |   series: lang === "zh" ? "序列" : "Series",
  25  |   obs: lang === "zh" ? "观测日期" : "Observation date",
  26  |   exact: lang === "zh" ? "精确数值" : "Exact values",
  27  |   baskets: lang === "zh" ? "主题组合对比 SPY" : "Thematic Baskets vs SPY",
  28  |   sectorsTab: lang === "zh" ? "板块 ETF 对比 SPY" : "Sector ETFs vs SPY",
  29  |   apply: lang === "zh" ? "应用" : "Apply",
  30  |   legDetails: lang === "zh" ? "周期段详情" : "Leg details",
  31  |   fullscreen: lang === "zh" ? "周期全屏" : "Cycles fullscreen",
  32  |   openFullscreen: lang === "zh" ? "打开全屏" : "Open fullscreen",
  33  |   fullscreenBtn: lang === "zh" ? "全屏" : "Full screen",
  34  |   changeSeries: lang === "zh" ? "更换序列" : "Change series",
  35  |   phaseAll: lang === "zh" ? "全部阶段" : "All phases",
  36  |   expansion: lang === "zh" ? "扩张" : "Expansion",
  37  |   selectedFoot: lang === "zh" ? "已选" : "Selected",
  38  |   troughWord: lang === "zh" ? "底部" : "trough",
  39  |   prov: lang === "zh" ? "暂定" : "Provisional",
  40  |   rs63: lang === "zh" ? "63个交易日" : "63 sessions",
  41  |   trough: lang === "zh" ? "底部" : "Trough",
  42  |   recovery: lang === "zh" ? "复苏" : "Recovery",
  43  |   energy: lang === "zh" ? "能源" : "Energy",
  44  |   financials: lang === "zh" ? "金融" : "Financials",
  45  |   aiInfra: lang === "zh" ? "AI 基础设施" : "AI Infrastructure",
  46  |   story: lang === "zh" ? "趋成熟" : "matured",
  47  |   mismatch: lang === "zh" ? "快照版本不一致" : "Snapshots do not match",
  48  |   /* v1.1 per-head forecast capabilities + SP11 dates + honest windows */
  49  |   range21: lang === "zh" ? "21个交易日" : "21 sessions",
  50  |   range252: lang === "zh" ? "252个交易日" : "252 sessions",
  51  |   range1mWord: lang === "zh" ? "1个月" : "1 month",
  52  |   durationWord: lang === "zh" ? "并非剩余上行空间" : "not remaining upside",
  53  |   firstKnown: lang === "zh" ? "最早可知" : "first known",
  54  |   pivotNote: lang === "zh" ? "转折日期为拐点日期" : "Turn dates are pivot dates",
  55  |   headWithheld: lang === "zh" ? "暂缓显示" : "Withheld",
  56  |   headWithdrawnWord: lang === "zh" ? "已撤回" : "Withdrawn",
  57  |   reasonUnknown: lang === "zh" ? "因未说明的原因暂缓显示" : "Withheld for an unstated reason",
  58  |   reasonFailed: lang === "zh" ? "研究检验未通过" : "research test failed",
  59  |   reasonEpoch: lang === "zh" ? "与研究协议的转折口径不一致" : "does not match the research protocol",
  60  |   horizon20: lang === "zh" ? "20 个已完结交易日" : "20 completed sessions",
  61  |   directional: lang === "zh" ? "周期段方向事实" : "Leg-direction fact",
  62  |   headsAbsent: lang === "zh" ? "未附带预测能力分块" : "No forecast capability block",
  63  | });
  64  | 
  65  | 
  66  | async function expectMeasuredPlot(svg: Locator) {
  67  |   await expect(svg).toBeVisible();
  68  |   const geometry = () => svg.evaluate((element) => {
  69  |     const chart = element as SVGSVGElement;
  70  |     return {
  71  |       container: chart.parentElement!.clientWidth,
  72  |       width: Number(chart.getAttribute("width")),
  73  |       viewBox: chart.viewBox.baseVal.width,
  74  |       rendered: chart.getBoundingClientRect().width,
  75  |     };
  76  |   });
  77  |   expect((await geometry()).container).toBeGreaterThanOrEqual(240);
  78  |   await expect.poll(async () => {
  79  |     const value = await geometry();
  80  |     return Math.max(
  81  |       Math.abs(value.width - value.container),
  82  |       Math.abs(value.viewBox - value.container),
  83  |       Math.abs(value.rendered - value.container),
  84  |     );
> 85  |   }, { message: "SVG coordinates must follow the current measured content width" }).toBeLessThanOrEqual(1);
      |                                                                                     ^ Error: SVG coordinates must follow the current measured content width
  86  |   return geometry();
  87  | }
  88  | 
  89  | async function expectAxisLabels(svg: Locator, expected: string[]) {
  90  |   await expectMeasuredPlot(svg);
  91  |   // Tick labels belong to grid groups; date/turn labels use other anchors.
  92  |   const ticks = svg.locator('g > text[text-anchor="end"]');
  93  |   await expect(ticks).toHaveText(expected);
  94  |   expect(new Set(await ticks.allTextContents()).size).toBe(expected.length);
  95  |   const bounds = await ticks.evaluateAll(elements => elements.map(element => {
  96  |     const label = element.getBoundingClientRect();
  97  |     const chart = (element as SVGElement).ownerSVGElement!.getBoundingClientRect();
  98  |     return { left: label.left - chart.left, right: chart.right - label.right };
  99  |   }));
  100 |   for (const bound of bounds) {
  101 |     expect(bound.left).toBeGreaterThanOrEqual(-1);
  102 |     expect(bound.right).toBeGreaterThanOrEqual(-1);
  103 |   }
  104 | }
  105 | 
  106 | for (const [lang, theme] of cases) {
  107 |   const L = T(lang);
  108 | 
  109 |   for (const axisFixture of ["tiny", "fractional"] as const) {
  110 |     test(`cycles tick precision survives fullscreen ${axisFixture} ${lang} ${theme}`, async ({ page }, info) => {
  111 |       await page.goto("/dev/sector-cycles");
  112 |       await page.getByRole("radio", { name: lang === "zh" ? "ZH" : "EN", exact: true }).check();
  113 |       await page.getByRole("radio", { name: theme === "light" ? "Light" : "Dark", exact: true }).check();
  114 |       await page.getByLabel("Axis fixture").selectOption(axisFixture);
  115 |       await expect(page.getByText("Fixture data — not live evidence")).toBeVisible();
  116 |       await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
  117 | 
  118 |       const panel = page.getByTestId("cycle-chart-panel");
  119 |       await panel.getByLabel(L.range).selectOption("0");
  120 |       const inlineLabels = axisFixture === "tiny"
  121 |         ? ["0.000", "0.005", "0.010"] : ["-2.5", "0.0", "2.5"];
  122 |       const fullscreenLabels = axisFixture === "tiny"
  123 |         ? ["0.0000", "0.0025", "0.0050", "0.0075", "0.0100"]
  124 |         : ["-4", "-2", "0", "2", "4"];
  125 |       await expectAxisLabels(panel.locator("svg"), inlineLabels);
  126 |       await panel.screenshot({
  127 |         path: info.outputPath(`cycles-precision-${axisFixture}-inline-${lang}-${info.project.name}.png`),
  128 |         animations: "disabled",
  129 |       });
  130 | 
  131 |       await panel.getByRole("button", { name: new RegExp(L.fullscreenBtn) }).click();
  132 |       const dialog = page.getByRole("dialog", { name: L.fullscreen });
  133 |       await expect(dialog).toBeVisible();
  134 |       await expectAxisLabels(dialog.locator("svg"), fullscreenLabels);
  135 |       await dialog.screenshot({
  136 |         path: info.outputPath(`cycles-precision-${axisFixture}-fullscreen-${lang}-${info.project.name}.png`),
  137 |         animations: "disabled",
  138 |       });
  139 |       await page.keyboard.press("Escape");
  140 |       await expect(dialog).toBeHidden();
  141 |       await expectAxisLabels(panel.locator("svg"), inlineLabels);
  142 |       expect(await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)).toBeLessThanOrEqual(1);
  143 |     });
  144 |   }
  145 | 
  146 |   for (const transition of ["table", "empty"] as const) {
  147 |     test(`cycles chart measurement survives ${transition} transitions ${lang} ${theme}`, async ({ page }, info) => {
  148 |       await page.goto("/dev/sector-cycles");
  149 |       await page.getByRole("radio", { name: lang === "zh" ? "ZH" : "EN", exact: true }).check();
  150 |       await page.getByRole("radio", { name: theme === "light" ? "Light" : "Dark", exact: true }).check();
  151 | 
  152 |       const initialViewport = page.viewportSize()!;
  153 |       // Remain in the same responsive band, so a remounted panel cannot hide
  154 |       // the lost observer. The final capture returns to the contract viewport.
  155 |       const widths = initialViewport.width >= 981 ? [1100, 1280]
  156 |         : initialViewport.width >= 641 ? [700, 900] : [510, 430];
  157 |       const panel = page.getByTestId("cycle-chart-panel");
  158 |       const svg = panel.locator("svg");
  159 |       const expectThemePaint = async (selected: "light" | "dark") => {
  160 |         await expect.poll(() => panel.evaluate(element => {
  161 |           const root = document.documentElement;
  162 |           const tokens = getComputedStyle(root);
  163 |           const paint = getComputedStyle(element);
  164 |           return {
  165 |             theme: root.dataset.theme,
  166 |             appearance: root.dataset.terminalAppearance,
  167 |             sharedShell: root.dataset.mmxSharedShell ?? null,
  168 |             backgroundToken: tokens.getPropertyValue("--bg").trim(),
  169 |             secondaryPanelToken: tokens.getPropertyValue("--panel-2").trim(),
  170 |             textToken: tokens.getPropertyValue("--text").trim(),
  171 |             background: paint.backgroundColor,
  172 |             foreground: paint.color,
  173 |           };
  174 |         })).toEqual({
  175 |           theme: selected, appearance: "1", sharedShell: null,
  176 |           backgroundToken: selected === "light" ? "#f7f8fa" : "#0a0b0e",
  177 |           secondaryPanelToken: selected === "light" ? "#eef1f6" : "#15171d",
  178 |           textToken: selected === "light" ? "#202632" : "#d6dae3",
  179 |           background: selected === "light" ? "rgb(255, 255, 255)" : "rgb(13, 15, 19)",
  180 |           foreground: selected === "light" ? "rgb(32, 38, 50)" : "rgb(214, 218, 227)",
  181 |         });
  182 |       };
  183 |       await expectThemePaint(theme);
  184 |       const otherTheme = theme === "light" ? "dark" : "light";
  185 |       await page.getByRole("radio", { name: otherTheme === "light" ? "Light" : "Dark", exact: true }).check();
```