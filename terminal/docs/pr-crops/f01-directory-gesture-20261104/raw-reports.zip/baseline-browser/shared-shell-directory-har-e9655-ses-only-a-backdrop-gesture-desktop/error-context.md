# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: shared-shell-directory-hardening.spec.ts >> directory retains the task after cross-boundary drags and dismisses only a backdrop gesture
- Location: e2e/shared-shell-directory-hardening.spec.ts:358:5

# Error details

```
Error: Dragging from the task onto backdrop must preserve it

expect(locator).toBeVisible() failed

Locator: locator('.shared-shell-directory[open]')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Dragging from the task onto backdrop must preserve it with timeout 5000ms
  - waiting for locator('.shared-shell-directory[open]')

```

```yaml
- link "Skip to content":
  - /url: "#shared-shell-content"
- banner:
  - button "Compact"
  - text: MASTERMIND Beta
  - button "Search companies":
    - strong: Search any company…
  - button "All tools": All tools ⌘ K
  - group "Appearance and language":
    - button "Light theme"
    - button "Chinese language"
  - link "Open current chart":
    - /url: /terminal?from=macro&ret=http%3A%2F%2F127.0.0.1%3A3658%2Fdiscover
  - button "Settings": U
- navigation "Main navigation":
  - link "Today":
    - /url: /today
    - img
    - text: Today
  - link "Discover":
    - /url: /discover
    - img
    - text: Discover
  - link "Analysis":
    - /url: /analysis
    - img
    - text: Analysis
  - link "Monitor":
    - /url: /monitor
    - img
    - text: Monitor
  - link "Research":
    - /url: /research
    - img
    - text: Research
  - link "Portfolio":
    - /url: /portfolio
    - img
    - text: Portfolio
  - heading "Markets" [level=2]
  - link "United States":
    - /url: /us_stocks.html
  - link "China":
    - /url: /china.html
  - link "Hong Kong":
    - /url: /hk.html
  - link "Canada":
    - /url: /canada.html
  - link "International":
    - /url: /intl.html
  - button "All tools"
  - button "Mastermind AI":
    - img
    - text: Mastermind AI
- status
- main:
  - heading "Discover" [level=1]
  - paragraph: Choose a question. Open the right workspace.
  - button "Search companies"
  - article:
    - paragraph: Screen companies
    - heading "Start with a universe. Narrow it with evidence." [level=2]
    - paragraph: Use technical, fundamental and classification filters. Check each field's coverage before comparing results.
    - button "Open Stock Screener"
  - article:
    - paragraph: Explore market structure
    - heading "See participation in context" [level=2]
    - paragraph: Move from the market map to the sectors and companies behind it.
    - button "Open Heatmap"
    - button "Open Sectors"
  - article:
    - heading "Follow market leadership" [level=2]
    - paragraph: Inspect the existing leader views and their underlying coverage.
    - button "Leaders"
    - button "Leader Radar"
  - article:
    - heading "RS · 30m Pivot" [level=2]
    - paragraph: Explore the study's conditions, timing and limitations.
    - button "Open study"
  - heading "Go deeper with a focused workflow" [level=2]
  - link "US stocks · Prophet":
    - /url: /us_stocks.html
  - paragraph: Open the US stock dashboard for Prophet, sectors and flows.
  - link "Catalysts":
    - /url: /biocatalyst.html
  - paragraph: Company catalysts anchored in original disclosures.
  - link "Confluence":
    - /url: /confluence_screener.html
  - paragraph: Adds evidence confluence on top of the existing screen.
- alert
```

# Test source

```ts
  276 |     return { scrollLeft: strip.scrollLeft, left: target.left, right: target.right,
  277 |       top: target.top, bottom: target.bottom,
  278 |       focusOutset: Math.max(0, parseFloat(style.outlineWidth) + parseFloat(style.outlineOffset)),
  279 |       clipLeft: outer.left + strip.clientLeft, clipRight: outer.left + strip.clientLeft + strip.clientWidth,
  280 |       clipTop: outer.top + strip.clientTop, clipBottom: outer.top + strip.clientTop + strip.clientHeight };
  281 |   });
  282 |   const clipped = await geometry();
  283 |   expect(clipped.scrollLeft).toBeGreaterThan(0);
  284 |   expect(clipped.left < clipped.clipLeft - 1 || clipped.right > clipped.clipRight + 1).toBe(true);
  285 |   const scrollBefore = await page.evaluate(() => ({ x: scrollX, y: scrollY,
  286 |     main: [...document.querySelectorAll("main, .main2")].map(node => ({ x: node.scrollLeft, y: node.scrollTop })) }));
  287 |   await dialog.getByRole("button", { name: `Show all ${before.length} matches`, exact: true }).focus();
  288 |   await page.keyboard.press("Enter");
  289 |   await expect(all).toBeFocused(); await expect(all).toHaveAttribute("aria-pressed", "true");
  290 |   const revealed = await geometry();
  291 |   expect(revealed.focusOutset).toBeGreaterThan(0);
  292 |   expect(revealed.left - revealed.focusOutset).toBeGreaterThanOrEqual(revealed.clipLeft - 1);
  293 |   expect(revealed.right + revealed.focusOutset).toBeLessThanOrEqual(revealed.clipRight + 1);
  294 |   expect(revealed.top - revealed.focusOutset).toBeGreaterThanOrEqual(revealed.clipTop - 1);
  295 |   expect(revealed.bottom + revealed.focusOutset).toBeLessThanOrEqual(revealed.clipBottom + 1);
  296 |   expect(await page.evaluate(() => ({ x: scrollX, y: scrollY,
  297 |     main: [...document.querySelectorAll("main, .main2")].map(node => ({ x: node.scrollLeft, y: node.scrollTop })) }))).toEqual(scrollBefore);
  298 |   await expect(search).toHaveValue("options");
  299 |   expect(await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")))).toEqual(before);
  300 |   await page.screenshot({ animations: "disabled", path: info.outputPath("revealed-category-focus.png") });
  301 | });
  302 | 
  303 | test("directory transfers once to the real company picker and respects composing Escape", async ({ page }) => {
  304 |   await open(page); const input = directory(page).getByRole("searchbox");
  305 |   await input.dispatchEvent("compositionstart", { data: "期" });
  306 |   await input.dispatchEvent("keydown", { key: "Escape", isComposing: true, bubbles: true, cancelable: true });
  307 |   await expect(directory(page)).toBeVisible();
  308 |   await input.dispatchEvent("compositionend", { data: "期权" });
  309 |   await directory(page).locator(".shared-directory-footer button").click();
  310 |   await expect(directory(page)).toHaveCount(0); await expect(page.getByRole("dialog")).toHaveCount(1);
  311 |   await expect(page.getByRole("dialog")).toHaveAccessibleName("Search companies");
  312 |   await expect(page.getByRole("dialog").getByRole("combobox")).toBeFocused();
  313 |   await page.keyboard.press("Escape"); await expect(page.getByRole("dialog")).toHaveCount(0);
  314 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  315 | });
  316 | 
  317 | test("native dialog cancellation respects the captured Escape owner", async ({ page }) => {
  318 |   await open(page); const input = directory(page).getByRole("searchbox");
  319 |   // Native Escape after composition ends in a child listener must still belong
  320 |   // to that composition. This exercises native dialog cancellation in Chromium;
  321 |   // it does not establish an operating-system IME or assistive-technology pass.
  322 |   await input.dispatchEvent("compositionstart", { data: "期" });
  323 |   await input.evaluate(element => element.addEventListener("keydown", () => {
  324 |     element.dispatchEvent(new CompositionEvent("compositionend", { bubbles: true, data: "期权" }));
  325 |   }, { once: true }));
  326 |   await page.keyboard.press("Escape");
  327 |   await expect(directory(page)).toBeVisible(); await expect(input).toBeFocused();
  328 |   const guarded = await input.evaluate(element => {
  329 |     const modal = element.closest("dialog")!;
  330 |     for (const signal of [{ isComposing: true }, { keyCode: 229 }, { repeat: true }]) {
  331 |       element.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true, cancelable: true, ...signal }));
  332 |       modal.requestClose();
  333 |       if (!modal.open) return false;
  334 |     }
  335 |     // Consumed protection cannot block a second independent request, even
  336 |     // before a keyup or the expiry task has run.
  337 |     modal.requestClose();
  338 |     return true;
  339 |   });
  340 |   expect(guarded).toBe(true);
  341 |   await expect(directory(page)).toHaveCount(0);
  342 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  343 | });
  344 | 
  345 | test("real Next Link keeps the current directory on modified activation", async ({ page, context }, info) => {
  346 |   test.skip(info.project.name !== "desktop", "Single real new-tab browser case");
  347 |   await open(page); await directory(page).getByRole("searchbox").fill("options");
  348 |   const link = directory(page).locator('a[href="/options"]');
  349 |   const popupPromise = context.waitForEvent("page");
  350 |   await link.click({ modifiers: ["ControlOrMeta"] });
  351 |   const popup = await popupPromise; await popup.waitForURL(/\/options$/); await popup.close();
  352 |   await expect(directory(page)).toBeVisible();
  353 |   await expect(directory(page).getByRole("searchbox")).toHaveValue("options");
  354 |   await link.click(); await expect(page).toHaveURL(/\/options$/); await expect(directory(page)).toHaveCount(0);
  355 | });
  356 | 
  357 | 
  358 | test("directory retains the task after cross-boundary drags and dismisses only a backdrop gesture", async ({ page }, info) => {
  359 |   await open(page);
  360 |   const dialog = directory(page);
  361 |   const search = dialog.getByRole("searchbox");
  362 |   await search.fill("options");
  363 |   await dialog.getByRole("button", { name: "Options & futures", exact: true }).click();
  364 |   const href = page.url();
  365 |   const box = (await dialog.boundingBox())!;
  366 |   const field = (await search.boundingBox())!;
  367 |   const outside = { x: Math.max(1, box.x / 2), y: field.y + field.height / 2 };
  368 |   const inside = { x: field.x + field.width / 2, y: outside.y };
  369 | 
  370 |   // A real text-selection drag can end on ::backdrop. Native click retargeting
  371 |   // then names the dialog; that alone is not an intentional dismiss gesture.
  372 |   await page.mouse.move(inside.x, inside.y);
  373 |   await page.mouse.down();
  374 |   await page.mouse.move(outside.x, outside.y, { steps: 8 });
  375 |   await page.mouse.up();
> 376 |   await expect(dialog, "Dragging from the task onto backdrop must preserve it").toBeVisible();
      |                                                                                 ^ Error: Dragging from the task onto backdrop must preserve it
  377 |   await expect(search).toHaveValue("options");
  378 |   await expect(dialog.getByRole("button", { name: "Options & futures", exact: true })).toHaveAttribute("aria-pressed", "true");
  379 |   expect(page.url()).toBe(href);
  380 | 
  381 |   // The opposite direction also has the dialog as the common click ancestor.
  382 |   await page.mouse.move(outside.x, outside.y);
  383 |   await page.mouse.down();
  384 |   await page.mouse.move(inside.x, inside.y, { steps: 8 });
  385 |   await page.mouse.up();
  386 |   await expect(dialog, "A gesture ending inside the task must not dismiss it").toBeVisible();
  387 |   await expect(search).toHaveValue("options");
  388 |   await info.attach("gesture-retained", { body: await page.screenshot(), contentType: "image/png" });
  389 | 
  390 |   // Deliberate backdrop activation remains available for pointer and touch.
  391 |   if (info.project.use.hasTouch) await page.touchscreen.tap(outside.x, outside.y);
  392 |   else await page.mouse.click(outside.x, outside.y);
  393 |   await expect(directory(page)).toHaveCount(0);
  394 |   const returnTarget = page.viewportSize()!.width <= 860
  395 |     ? page.getByRole("button", { name: "Open navigation", exact: true })
  396 |     : page.locator(".topbar .shared-shell-directory-trigger");
  397 |   await expect(returnTarget).toBeFocused();
  398 |   await open(page);
  399 |   await expect(directory(page).getByRole("searchbox")).toHaveValue("options");
  400 |   await expect(directory(page).getByRole("button", { name: "Options & futures", exact: true })).toHaveAttribute("aria-pressed", "true");
  401 | });
  402 | 
```