# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: shared-shell-directory-hardening.spec.ts >> Show all reveals its focused category inside the scrolled strip
- Location: e2e/shared-shell-directory-hardening.spec.ts:156:5

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 10
Received:    -168
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - link "Skip to content" [ref=e3] [cursor=pointer]:
      - /url: "#shared-shell-content"
    - generic [ref=e4]:
      - button "Open navigation" [ref=e5] [cursor=pointer]:
        - img [ref=e6]
      - generic:
        - img
        - generic: MASTERMIND
      - generic [ref=e8]:
        - button "Search companies" [ref=e9] [cursor=pointer]:
          - img [ref=e10]
        - group "Appearance and language" [ref=e13]:
          - button "Light theme" [ref=e14] [cursor=pointer]:
            - img [ref=e15]
          - button "Chinese language" [ref=e17] [cursor=pointer]:
            - generic [ref=e18]: EN
        - button "Settings" [ref=e20] [cursor=pointer]: U
    - dialog "All tools" [ref=e21]:
      - generic [ref=e22]:
        - banner [ref=e23]:
          - generic [ref=e24]:
            - text: Your workspace
            - heading "All tools" [level=2] [ref=e25]
            - paragraph [ref=e26]: Explore your workspaces, markets, research, and tools.
          - button "Close" [ref=e27] [cursor=pointer]: ×
        - generic [ref=e28]:
          - img [ref=e29]
          - searchbox "Find a page or tool…" [ref=e32]: options
          - button "Clear search" [ref=e33] [cursor=pointer]: ×
          - generic [ref=e34]: esc
        - group "Page categories" [ref=e35]:
          - button "All" [active] [pressed] [ref=e36] [cursor=pointer]
          - button "Workspaces" [ref=e37] [cursor=pointer]
          - button "Markets" [ref=e38] [cursor=pointer]
          - button "Research" [ref=e39] [cursor=pointer]
          - button "Learn" [ref=e40] [cursor=pointer]
          - button "Tools" [ref=e41] [cursor=pointer]
          - button "About" [ref=e42] [cursor=pointer]
        - generic [ref=e44]:
          - link "Futures Workspaces" [ref=e45] [cursor=pointer]:
            - /url: /options/futures
            - generic [ref=e46]:
              - strong [ref=e47]: Futures
              - generic [ref=e48]: Workspaces
          - link "Options Workspaces" [ref=e49] [cursor=pointer]:
            - /url: /options
            - generic [ref=e50]:
              - strong [ref=e51]: Options
              - generic [ref=e52]: Workspaces
          - link "Options & Market Structure Markets" [ref=e53] [cursor=pointer]:
            - /url: /options.html
            - generic [ref=e54]:
              - strong [ref=e55]: Options & Market Structure
              - generic [ref=e56]: Markets
          - link "Options Screener Markets" [ref=e57] [cursor=pointer]:
            - /url: /options_screener.html
            - generic [ref=e58]:
              - strong [ref=e59]: Options Screener
              - generic [ref=e60]: Markets
          - link "learn / options / charm and time drift Learn" [ref=e61] [cursor=pointer]:
            - /url: /learn/options/charm-and-time-drift.html
            - generic [ref=e62]:
              - strong [ref=e63]: learn / options / charm and time drift
              - generic [ref=e64]: Learn
          - link "learn / options / dealer hedging mechanics Learn" [ref=e65] [cursor=pointer]:
            - /url: /learn/options/dealer-hedging-mechanics.html
            - generic [ref=e66]:
              - strong [ref=e67]: learn / options / dealer hedging mechanics
              - generic [ref=e68]: Learn
          - link "learn / options / gamma flip levels Learn" [ref=e69] [cursor=pointer]:
            - /url: /learn/options/gamma-flip-levels.html
            - generic [ref=e70]:
              - strong [ref=e71]: learn / options / gamma flip levels
              - generic [ref=e72]: Learn
          - link "learn / options / gamma regimes Learn" [ref=e73] [cursor=pointer]:
            - /url: /learn/options/gamma-regimes.html
            - generic [ref=e74]:
              - strong [ref=e75]: learn / options / gamma regimes
              - generic [ref=e76]: Learn
          - link "learn / options / market makers middleman Learn" [ref=e77] [cursor=pointer]:
            - /url: /learn/options/market-makers-middleman.html
            - generic [ref=e78]:
              - strong [ref=e79]: learn / options / market makers middleman
              - generic [ref=e80]: Learn
          - link "learn / options / open interest limits Learn" [ref=e81] [cursor=pointer]:
            - /url: /learn/options/open-interest-limits.html
            - generic [ref=e82]:
              - strong [ref=e83]: learn / options / open interest limits
              - generic [ref=e84]: Learn
          - link "learn / options / zero dte regime Learn" [ref=e85] [cursor=pointer]:
            - /url: /learn/options/zero-dte-regime.html
            - generic [ref=e86]:
              - strong [ref=e87]: learn / options / zero dte regime
              - generic [ref=e88]: Learn
          - link "tools / calculators / options profit Tools" [ref=e89] [cursor=pointer]:
            - /url: /tools/calculators/options-profit.html
            - generic [ref=e90]:
              - strong [ref=e91]: tools / calculators / options profit
              - generic [ref=e92]: Tools
        - contentinfo [ref=e93]:
          - status [ref=e94]: 12 matches
          - button "Search companies" [ref=e95] [cursor=pointer]: Search companies ↗
    - status [ref=e96]
    - main [ref=e98]:
      - generic [ref=e99]:
        - generic [ref=e100]:
          - heading "Discover" [level=1] [ref=e101]
          - paragraph [ref=e102]: Choose a question. Open the right workspace.
        - button "Search companies" [ref=e103] [cursor=pointer]
      - generic [ref=e104]:
        - article [ref=e105]:
          - paragraph [ref=e106]: Screen companies
          - heading "Start with a universe. Narrow it with evidence." [level=2] [ref=e107]
          - paragraph [ref=e108]: Use technical, fundamental and classification filters. Check each field's coverage before comparing results.
          - button "Open Stock Screener" [ref=e110] [cursor=pointer]
        - article [ref=e111]:
          - paragraph [ref=e112]: Explore market structure
          - heading "See participation in context" [level=2] [ref=e113]
          - paragraph [ref=e114]: Move from the market map to the sectors and companies behind it.
          - generic [ref=e115]:
            - button "Open Heatmap" [ref=e116] [cursor=pointer]
            - button "Open Sectors" [ref=e117] [cursor=pointer]
        - article [ref=e118]:
          - heading "Follow market leadership" [level=2] [ref=e119]
          - paragraph [ref=e120]: Inspect the existing leader views and their underlying coverage.
          - generic [ref=e121]:
            - button "Leaders" [ref=e122] [cursor=pointer]
            - button "Leader Radar" [ref=e123] [cursor=pointer]
        - article [ref=e124]:
          - heading "RS · 30m Pivot" [level=2] [ref=e125]
          - paragraph [ref=e126]: Explore the study's conditions, timing and limitations.
          - button "Open study" [ref=e128] [cursor=pointer]
      - generic [ref=e129]:
        - heading "Go deeper with a focused workflow" [level=2] [ref=e130]
        - generic [ref=e131]:
          - generic [ref=e132]:
            - link "US stocks · Prophet" [ref=e133] [cursor=pointer]:
              - /url: /us_stocks.html
            - paragraph [ref=e134]: Open the US stock dashboard for Prophet, sectors and flows.
          - generic [ref=e135]:
            - link "Catalysts" [ref=e136] [cursor=pointer]:
              - /url: /biocatalyst.html
            - paragraph [ref=e137]: Company catalysts anchored in original disclosures.
          - generic [ref=e138]:
            - link "Confluence" [ref=e139] [cursor=pointer]:
              - /url: /confluence_screener.html
            - paragraph [ref=e140]: Adds evidence confluence on top of the existing screen.
  - alert [ref=e141]
```

# Test source

```ts
  82  |   await expect(dialog.getByRole("status")).toHaveText("0 in this category");
  83  |   await expect(dialog.getByRole("button", { name: "Show all 12 matches", exact: true })).toBeVisible();
  84  |   await page.screenshot({ animations: "disabled", path: info.outputPath("empty-category-dark-en.png") });
  85  | });
  86  | 
  87  | test("clear query, batching and same-instance reopen retain the correct state", async ({ page }) => {
  88  |   await open(page); const dialog = directory(page);
  89  |   await dialog.getByRole("button", { name: "Show more", exact: true }).click();
  90  |   await expect(dialog.locator(".shared-directory-link")).toHaveCount(96);
  91  |   await page.keyboard.press("Escape"); await open(page);
  92  |   await expect(dialog.locator(".shared-directory-link")).toHaveCount(96);
  93  |   await dialog.getByRole("searchbox").fill("no-such-directory-destination-20261104");
  94  |   await expect(dialog.getByRole("heading", { name: "No pages found", exact: true })).toBeVisible();
  95  |   await dialog.getByRole("button", { name: "Tools", exact: true }).click();
  96  |   await dialog.getByRole("button", { name: "Clear search", exact: true }).click();
  97  |   await expect(dialog.getByRole("searchbox")).toHaveValue("");
  98  |   await expect(dialog.getByRole("searchbox")).toBeFocused();
  99  |   await expect(dialog.getByRole("button", { name: "Tools", exact: true })).toHaveAttribute("aria-pressed", "true");
  100 |   await expect(dialog.locator(".shared-directory-results")).not.toHaveAttribute("aria-live", /.+/);
  101 |   await expect(dialog.getByRole("status")).toHaveAttribute("aria-atomic", "true");
  102 | });
  103 | 
  104 | test("actual locale/theme controls preserve a filtered directory across reopen", async ({ page }, info) => {
  105 |   await open(page); let dialog = directory(page);
  106 |   await dialog.getByRole("searchbox").fill("options");
  107 |   await dialog.getByRole("button", { name: "Workspaces", exact: true }).click();
  108 |   const identities = await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")));
  109 |   await page.keyboard.press("Escape");
  110 |   await page.getByRole("button", { name: "Light theme", exact: true }).click();
  111 |   await page.getByRole("button", { name: "Chinese language", exact: true }).click();
  112 |   await expect(page.locator("html")).toHaveAttribute("data-lang", "zh");
  113 |   await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
  114 |   // Keyboard invocation uses the existing shell listener after the old modal closed.
  115 |   await page.locator("main").first().click({ position: { x: 5, y: 5 } });
  116 |   await page.keyboard.press("ControlOrMeta+k"); dialog = directory(page);
  117 |   await expect(dialog).toBeVisible(); await expect(dialog.getByRole("searchbox")).toHaveValue("options");
  118 |   await expect(dialog.getByRole("button", { name: "工作区", exact: true })).toHaveAttribute("aria-pressed", "true");
  119 |   expect(await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")))).toEqual(identities);
  120 |   await expect(dialog.getByRole("button", { name: "查看全部 12 个匹配结果", exact: true })).toBeVisible();
  121 |   await contained(page);
  122 |   await page.screenshot({ animations: "disabled", path: info.outputPath("category-recovery-light-zh.png") });
  123 |   await page.setViewportSize({ width: 320, height: 420 });
  124 |   await contained(page); await expect(dialog.getByRole("button", { name: "关闭", exact: true })).toBeVisible();
  125 |   await expect(dialog.getByRole("searchbox")).toBeVisible();
  126 |   await page.screenshot({ animations: "disabled", path: info.outputPath("short-320-light-zh.png") });
  127 | });
  128 | 
  129 | test("drawer-to-directory and resize close return to a visible persistent control", async ({ page }, info) => {
  130 |   await open(page); await directory(page).getByRole("searchbox").fill("options");
  131 |   if (info.project.name === "desktop") await page.setViewportSize({ width: 320, height: 844 });
  132 |   await page.keyboard.press("Escape");
  133 |   await expect(page.getByRole("dialog")).toHaveCount(0);
  134 |   await expect(page.getByRole("button", { name: "Open navigation", exact: true })).toBeFocused();
  135 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  136 |   await page.screenshot({ animations: "disabled", path: info.outputPath("visible-focus-return.png") });
  137 | });
  138 | 
  139 | test("shortcut from BODY returns to a meaningful visible shell control", async ({ page }, info) => {
  140 |   await page.evaluate(() => { if (document.activeElement instanceof HTMLElement) document.activeElement.blur(); });
  141 |   expect(await page.evaluate(() => document.activeElement === document.body)).toBe(true);
  142 |   const before = await page.evaluate(() => ({ tabIndex: document.body.getAttribute("tabindex"), x: scrollX, y: scrollY }));
  143 |   await page.keyboard.press("ControlOrMeta+k");
  144 |   await expect(directory(page)).toBeVisible();
  145 |   await expect(directory(page).getByRole("searchbox")).toBeFocused();
  146 |   await page.keyboard.press("Escape");
  147 |   await expect(directory(page)).toHaveCount(0);
  148 |   const returnTarget = page.viewportSize()!.width <= 860
  149 |     ? page.getByRole("button", { name: "Open navigation", exact: true })
  150 |     : page.locator(".topbar .shared-shell-directory-trigger");
  151 |   await expect(returnTarget).toBeFocused(); await expect(returnTarget).toBeVisible();
  152 |   expect(await page.evaluate(() => ({ tabIndex: document.body.getAttribute("tabindex"), x: scrollX, y: scrollY }))).toEqual(before);
  153 |   await page.screenshot({ animations: "disabled", path: info.outputPath("shortcut-meaningful-return.png") });
  154 | });
  155 | 
  156 | test("Show all reveals its focused category inside the scrolled strip", async ({ page }, info) => {
  157 |   await page.setViewportSize({ width: info.project.name === "mobile" ? 390 : 320, height: 844 });
  158 |   await open(page);
  159 |   const dialog = directory(page);
  160 |   const search = dialog.getByRole("searchbox");
  161 |   await search.fill("options");
  162 |   const before = await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")));
  163 |   await dialog.getByRole("button", { name: "About", exact: true }).click();
  164 |   const strip = dialog.locator(".shared-directory-filters");
  165 |   await strip.evaluate(element => { element.scrollLeft = element.scrollWidth; });
  166 |   const all = dialog.getByRole("button", { name: "All", exact: true });
  167 |   const geometry = () => all.evaluate(element => {
  168 |     const strip = element.closest(".shared-directory-filters")!;
  169 |     const outer = strip.getBoundingClientRect(); const target = element.getBoundingClientRect();
  170 |     return { scrollLeft: strip.scrollLeft, left: target.left, right: target.right,
  171 |       clipLeft: outer.left + strip.clientLeft, clipRight: outer.left + strip.clientLeft + strip.clientWidth };
  172 |   });
  173 |   const clipped = await geometry();
  174 |   expect(clipped.scrollLeft).toBeGreaterThan(0);
  175 |   expect(clipped.left < clipped.clipLeft - 1 || clipped.right > clipped.clipRight + 1).toBe(true);
  176 |   const scrollBefore = await page.evaluate(() => ({ x: scrollX, y: scrollY,
  177 |     main: [...document.querySelectorAll("main, .main2")].map(node => ({ x: node.scrollLeft, y: node.scrollTop })) }));
  178 |   await dialog.getByRole("button", { name: `Show all ${before.length} matches`, exact: true }).focus();
  179 |   await page.keyboard.press("Enter");
  180 |   await expect(all).toBeFocused(); await expect(all).toHaveAttribute("aria-pressed", "true");
  181 |   const revealed = await geometry();
> 182 |   expect(revealed.left).toBeGreaterThanOrEqual(revealed.clipLeft - 1);
      |                         ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  183 |   expect(revealed.right).toBeLessThanOrEqual(revealed.clipRight + 1);
  184 |   expect(await page.evaluate(() => ({ x: scrollX, y: scrollY,
  185 |     main: [...document.querySelectorAll("main, .main2")].map(node => ({ x: node.scrollLeft, y: node.scrollTop })) }))).toEqual(scrollBefore);
  186 |   await expect(search).toHaveValue("options");
  187 |   expect(await dialog.locator(".shared-directory-link").evaluateAll(nodes => nodes.map(n => n.getAttribute("href")))).toEqual(before);
  188 |   await page.screenshot({ animations: "disabled", path: info.outputPath("revealed-category-focus.png") });
  189 | });
  190 | 
  191 | test("directory transfers once to the real company picker and respects composing Escape", async ({ page }) => {
  192 |   await open(page); const input = directory(page).getByRole("searchbox");
  193 |   await input.dispatchEvent("compositionstart", { data: "期" });
  194 |   await input.dispatchEvent("keydown", { key: "Escape", isComposing: true, bubbles: true, cancelable: true });
  195 |   await expect(directory(page)).toBeVisible();
  196 |   await input.dispatchEvent("compositionend", { data: "期权" });
  197 |   await directory(page).locator(".shared-directory-footer button").click();
  198 |   await expect(directory(page)).toHaveCount(0); await expect(page.getByRole("dialog")).toHaveCount(1);
  199 |   await expect(page.getByRole("dialog")).toHaveAccessibleName("Search companies");
  200 |   await expect(page.getByRole("dialog").getByRole("combobox")).toBeFocused();
  201 |   await page.keyboard.press("Escape"); await expect(page.getByRole("dialog")).toHaveCount(0);
  202 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  203 | });
  204 | 
  205 | test("native dialog cancellation respects the captured Escape owner", async ({ page }) => {
  206 |   await open(page); const input = directory(page).getByRole("searchbox");
  207 |   // Native Escape after composition ends in a child listener must still belong
  208 |   // to that composition. This exercises native dialog cancellation in Chromium;
  209 |   // it does not establish an operating-system IME or assistive-technology pass.
  210 |   await input.dispatchEvent("compositionstart", { data: "期" });
  211 |   await input.evaluate(element => element.addEventListener("keydown", () => {
  212 |     element.dispatchEvent(new CompositionEvent("compositionend", { bubbles: true, data: "期权" }));
  213 |   }, { once: true }));
  214 |   await page.keyboard.press("Escape");
  215 |   await expect(directory(page)).toBeVisible(); await expect(input).toBeFocused();
  216 |   const guarded = await input.evaluate(element => {
  217 |     const modal = element.closest("dialog")!;
  218 |     for (const signal of [{ isComposing: true }, { keyCode: 229 }, { repeat: true }]) {
  219 |       element.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true, cancelable: true, ...signal }));
  220 |       modal.requestClose();
  221 |       if (!modal.open) return false;
  222 |     }
  223 |     // Consumed protection cannot block a second independent request, even
  224 |     // before a keyup or the expiry task has run.
  225 |     modal.requestClose();
  226 |     return true;
  227 |   });
  228 |   expect(guarded).toBe(true);
  229 |   await expect(directory(page)).toHaveCount(0);
  230 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe("hidden");
  231 | });
  232 | 
  233 | test("real Next Link keeps the current directory on modified activation", async ({ page, context }, info) => {
  234 |   test.skip(info.project.name !== "desktop", "Single real new-tab browser case");
  235 |   await open(page); await directory(page).getByRole("searchbox").fill("options");
  236 |   const link = directory(page).locator('a[href="/options"]');
  237 |   const popupPromise = context.waitForEvent("page");
  238 |   await link.click({ modifiers: ["ControlOrMeta"] });
  239 |   const popup = await popupPromise; await popup.waitForURL(/\/options$/); await popup.close();
  240 |   await expect(directory(page)).toBeVisible();
  241 |   await expect(directory(page).getByRole("searchbox")).toHaveValue("options");
  242 |   await link.click(); await expect(page).toHaveURL(/\/options$/); await expect(directory(page)).toHaveCount(0);
  243 | });
  244 | 
```