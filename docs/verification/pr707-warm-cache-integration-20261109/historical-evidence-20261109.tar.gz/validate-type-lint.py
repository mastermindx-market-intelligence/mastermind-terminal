from pathlib import Path
from collections import Counter
import subprocess,json,hashlib,time,datetime,concurrent.futures,os
repo=Path(__file__).resolve().parents[3];t=repo/'terminal';proof=Path(__file__).resolve().parent;out=proof/'type-lint-r1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.run(['git','-C',str(repo),*a],capture_output=True,text=True,check=True).stdout
def sources():return json.loads(subprocess.run(['node','-e',"console.log(JSON.stringify(require('./terminal/e2e/tools/visualEvidence.cjs').sourceSnapshot(process.cwd())))"],cwd=repo,capture_output=True,text=True,check=True).stdout)
assert not out.exists();out.mkdir();before=sources();put(out/'source-before.json',before)
paths=['lib/dataCache.ts','components/SymbolPicker.tsx','components/TerminalShell.tsx','components/ScreenerView.tsx','components/PortfolioView.tsx','components/AlertsView.tsx','components/heatmap/HeatmapView.tsx','lib/watchlistEventPlanner.ts','lib/__tests__/dataCacheWarmRefresh.test.ts','lib/__tests__/symbolPickerRecovery.test.tsx','lib/__tests__/watchlistEventPlanner.test.ts','lib/__tests__/screenerPresetPersistence.test.tsx','lib/__tests__/heatmapPersistedRefreshFailure.test.tsx','e2e/tools/capture_gex_levels_heatmap_load_failure.cjs','e2e/tools/capture_eod_heatmap_flowdesk_load_failure.cjs','e2e/tools/capture_b_f08_b5_1_targets.cjs']
def lint(path):
 base='0b48ac7f699b99fce10fd76d64d7c278cd23e9d2' if path.endswith('dataCacheWarmRefresh.test.ts') else '0fd27ff1dfb7e031457a4ffe4c05458587c4eb81'
 values={}
 for label,source in [('baseline',git('show',base+':terminal/'+path)),('current',(t/path).read_text())]:
  cmd=['node','node_modules/eslint/bin/eslint.js','--stdin','--stdin-filename',path,'--format=json'];r=subprocess.run(cmd,input=source,cwd=t,capture_output=True,text=True);assert r.returncode in [0,1],r.stderr
  entries=json.loads(r.stdout);assert len(entries)==1 and entries[0].get('fatalErrorCount',0)==0
  put(out/(Path(path).name+'.'+label+'.json'),entries);lines=source.splitlines();counter=Counter()
  for m in entries[0]['messages']:
   key=json.dumps([m.get('ruleId'),m.get('severity'),m.get('message'),m.get('nodeType'),lines[m['line']-1].strip() if m.get('line') else None]);counter[key]+=1
  values[label]=counter
 novel=values['current']-values['baseline'];return {'path':path,'baseline':base,'baselineCount':sum(values['baseline'].values()),'currentCount':sum(values['current'].values()),'novel':dict(novel),'state':'NO_NEW_DIAGNOSTICS' if not novel else 'NOVEL_DIAGNOSTICS'}
cmd=['node','node_modules/typescript/bin/tsc','--noEmit','--incremental','false'];start=time.monotonic()
with (out/'typecheck.log').open('x') as h:r=subprocess.run(cmd,cwd=t,stdout=h,stderr=subprocess.STDOUT)
typecheck={'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-start,2),'logSha256':sha(out/'typecheck.log')};print(json.dumps({'typecheck':typecheck}),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:lints=list(pool.map(lint,paths))
env=os.environ.copy();assert not env.get('NODE_OPTIONS');env['NODE_OPTIONS']='--no-experimental-webstorage'
cmd=['node','node_modules/vitest/vitest.mjs','run','lib/__tests__/heatmapScopedRecapture.test.ts','lib/__tests__/eodHeatmapScopedRecapture.test.ts','--pool=forks','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(out/'capture-helper-report.json')]
start=time.monotonic()
with (out/'capture-helpers.log').open('x') as h:helper=subprocess.run(cmd,cwd=t,env=env,stdout=h,stderr=subprocess.STDOUT)
hd=json.loads((out/'capture-helper-report.json').read_text());helpers={'exit':helper.returncode,'seconds':round(time.monotonic()-start,2),'command':cmd,'stats':{k:hd.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']}}
after=sources();put(out/'source-after.json',after);good=r.returncode==0 and helper.returncode==0 and all(x['state']=='NO_NEW_DIAGNOSTICS' for x in lints) and before==after
record={'schema':'terminal_pr707_current_type_and_affected_lint.v1','state':'QUALIFIED' if good else 'FAILED','sourceStable':before==after,'sourceEntries':len(before),'typecheck':typecheck,'lint':lints,'captureHelpers':helpers,'completedAt':now()}
put(out/'execution.json',record);print(json.dumps(record),flush=True)
if r.returncode:print((out/'typecheck.log').read_text()[-10000:],flush=True)
raise SystemExit(0 if good else 1)
